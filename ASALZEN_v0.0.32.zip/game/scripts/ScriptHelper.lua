local ScriptHelper = {}

ScriptHelper.getPlayer = function()
    local entities = fg.world.areas[fg.current_area]:getEntitiesWhere(function() return true end, {'Person'})
    local player = entities[1]
    if player then return player
    else error("Player not found, " .. fg.current_area) end
end

return ScriptHelper
