return function(object_types, radius)
    return Sequence('findAndMoveTo', {
        DontSucceedInARow(anyAround(object_types, radius)),
        moveToPoint(),
    })
end
