local Inverter = Decorator:extend('Inverter')

function Inverter:new(behavior)
    Inverter.super.new(self, 'Inverter', behavior)
end

function Inverter:update(dt, context)
    return Inverter.super.update(self, dt, context)
end

function Inverter:run(dt, context)
    local status = self.behavior:update(dt, context)
    if status == 'running' then return 'running'
    elseif status == 'success' then return 'failure'
    elseif status == 'failure' then return 'success' end
end

function Inverter:start(context)

end

function Inverter:finish(status, context)

end

return Inverter
