local DontSucceedInARow = Decorator:extend('DontSucceedInARow')

function DontSucceedInARow:new(behavior)
    DontSucceedInARow.super.new(self, 'DontSucceedInARow', behavior)
    
    self.past_status = 'invalid'
end

function DontSucceedInARow:update(dt, context)
    return DontSucceedInARow.super.update(self, dt, context)
end

function DontSucceedInARow:run(dt, context)
    local status = self.behavior:update(dt, context)
    if status == 'success' and self.past_status == 'success' then
        context.any_around_entity = nil
        self.past_status = 'failure'
        return 'failure'
    else 
        self.past_status = status
        return status 
    end
end

function DontSucceedInARow:start(context)

end

function DontSucceedInARow:finish(status, context)

end

return DontSucceedInARow
