local stall = Action:extend('stall')

function stall:new()
    stall.super.new(self, 'stall')
end

function stall:update(dt, context)
    return stall.super.update(self, dt, context)
end

function stall:run(dt, context)
    return 'running'
end

function stall:start(context)

end

function stall:finish(status, context)

end

return stall
