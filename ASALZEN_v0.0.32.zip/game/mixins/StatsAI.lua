local StatsAI = fg.Object:extend('StatsAI')

function StatsAI:statsAINew(settings)
    local settings = settings or {}

    self.max_hp = settings.settings.max_hp or 30
    self.current_hp = self.max_hp
end

function StatsAI:statsAIUpdate(dt)

end

function StatsAI:statsAIDraw()

end

function StatsAI:statsSetHP(hp)
    self.max_hp = hp
    self.current_hp = hp
end

function StatsAI:statsDecreaseHP(attacker)
    local hp = 10
    self.current_hp = self.current_hp - hp
    if self.current_hp <= 0 then self:die() end
end

function StatsAI:statsAISave()
    return {current_hp = self.current_hp, max_hp = self.max_hp}
end

return StatsAI
