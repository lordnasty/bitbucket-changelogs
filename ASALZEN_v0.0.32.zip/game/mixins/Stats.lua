local Stats = fg.Object:extend('Stats')

function Stats:statsNew(settings)
    local settings = settings or {}

    self.damage = settings.settings.damage or 10
end

function Stats:statsUpdate(dt)

end

function Stats:statsDraw()

end

function Stats:statsSave()
    return {damage = self.damage}
end

return Stats
