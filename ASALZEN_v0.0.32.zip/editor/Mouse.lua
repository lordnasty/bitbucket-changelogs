local Mouse = fg.Object:extend('Mouse')

function Mouse:mouseNew(settings)
    local settings = settings or {}
end

function Mouse:mouseUpdate(dt)

end

function Mouse:mouseDraw()
    local x, y = love.mouse.getPosition()
    love.graphics.setLineStyle('rough')
    if self.selecting and not self.selection_start then
        love.graphics.rectangle('line', x - 4.5, y - 4.5, 9, 9)
    elseif self.selecting and self.selection_start then
        love.graphics.rectangle('line', x - 2.5, y - 2.5, 5, 5)
    elseif self.moving_camera then
        love.graphics.circle('line', x, y, 4)
    elseif self.inside_tileset_display or self.cutting or self.pasting or self.copying or self.filling or self.object_cutting or self.object_pasting or self.object_copying then

    elseif self.object then

    else
        love.graphics.circle('line', x, y, 6)
    end
end

return Mouse
