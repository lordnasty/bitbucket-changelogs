local Class = require (fuccboi_path .. '/libraries/classic/classic')
local Entity = Class:extend('Entity') 

function Entity:new(area, x, y, settings)
    local settings = settings or {}
    self.dead = false
    self.area = area 
    self.world = self.area.world
    self.fg = area.fg
    local pool_add = 0
    if settings.pool_entity then pool_add = 100000 end
    if settings.id then self.id = self.area:getUID(settings.id + pool_add)
    else self.id = self.area:getUID(settings.id) end
    self.pool_active = false
    self.x = x
    self.y = y
    if settings then
        for k, v in pairs(settings) do self[k] = v end
    end
end

return Entity
