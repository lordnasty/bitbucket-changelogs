local WallPlant = fg.Class('WallPlant', 'Entity')

WallPlant.layer = 'Front_1'

function WallPlant:new(area, x, y, settings)
    local settings = settings or {}
    WallPlant.super.new(self, area, x, y, settings)
    local n = settings.n or math.random(1, 3)
    self.wall_plant_visual = self.fg.Assets['wall_plant_' .. n]
end

function WallPlant:update(dt)

end

function WallPlant:draw()
    local w, h = self.wall_plant_visual:getWidth(), self.wall_plant_visual:getHeight()
    love.graphics.draw(self.wall_plant_visual, self.x, self.y, self.r or 0, 1, 1, w/2, h/2)
end

function WallPlant:save()
    return {id = self.id, x = self.x, y = self.y, n = self.n, r = self.r}
end

return WallPlant
