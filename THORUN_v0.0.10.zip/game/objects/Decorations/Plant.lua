local Plant = fg.Class('Plant', 'Entity')

Plant.layer = 'Front_1'

function Plant:new(area, x, y, settings)
    local settings = settings or {}
    Plant.super.new(self, area, x, y, settings)
    local n = settings.n or math.random(0, 1)
    self.plant_visual = self.fg.Assets.high_plant
    self.plant_quad = love.graphics.newQuad(32*n, 0, 32, 64, 64, 64)
end

function Plant:update(dt)

end

function Plant:draw()
    love.graphics.draw(self.plant_visual, self.plant_quad, self.x, self.y, self.r or 0, 1, 1, 16, 32)
end

function Plant:save()
    return {id = self.id, x = self.x, y = self.y, n = self.n, r = self.r}
end

return Plant
