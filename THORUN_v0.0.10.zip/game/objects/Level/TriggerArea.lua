local TriggerArea = fg.Class('TriggerArea', 'Entity')
TriggerArea:implement(fg.PhysicsBody)

TriggerArea.ignores = {'All'}
TriggerArea.enter = {'Player'}

function TriggerArea:new(area, x, y, settings)
    local settings = settings or {}
    TriggerArea.super.new(self, area, x, y, settings)
    self:physicsBodyNew(area, x, y, settings)

    if settings.triggerables then
        self.triggerables = setmetatable({}, {__mode = 'v'})
        for _, id in ipairs(settings.triggerables) do
            local entity = self.area:getEntityById(id)
            table.insert(self.triggerables, entity)
        end
    else self.triggerables = setmetatable({}, {__mode = 'v'}) end
end

function TriggerArea:update(dt)
    self:physicsBodyUpdate(dt)
end

function TriggerArea:draw()
    self:physicsBodyDraw()
end

function TriggerArea:onCollisionEnter(other, contact)
    if other.tag == 'Player' then
        for _, t in ipairs(self.triggerables) do 
            if t.trigger then t:trigger() end
        end
    end
end

function TriggerArea:save()
    local save_data = {}
    save_data.triggerables = {}
    for _, e in ipairs(self.triggerables) do table.insert(save_data.triggerables, e.id) end
    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y
    save_data.w, save_data.h = self.w, self.h
    save_data.shape = 'Rectangle'
    return save_data
end

return TriggerArea
