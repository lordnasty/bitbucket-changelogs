local Interaction = fg.Object:extend('Interaction')

function Interaction:interactionNew(settings)
    local settings = settings or {}
    
    self.interactable_objects = settings.interactable_objects
    self.interact_radius = 50
    self.interact_entity = nil
end

function Interaction:interactionUpdate(dt)
    self.interact_entity = self.area:queryClosestAreaCircle({self.id}, self.x, self.y, self.interact_radius, self.interactable_objects)
end

function Interaction:interactionDraw()
    if self.interact_entity then
        love.graphics.circle('fill', self.x, self.y, 10)
    end
end

function Interaction:interactionSave()

end

return Interaction
