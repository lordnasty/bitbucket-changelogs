local PersonJump = fg.Object:extend('PersonJump')

function PersonJump:personJumpNew(settings)
    local settings = settings or {}
    self.jump_a = settings.settings.jump_a or 300
    self.max_jumps = settings.settings.max_jumps or 1
    self.jumps_left = settings.settings.jumpst_left or self.max_jumps
    self.on_ground = settings.settings.on_ground or false
    self.falling = settings.settings.falling or false
    self.wall_sliding = settings.settings.wall_sliding or false
    for _, key_action in ipairs(settings.keys) do 
        self.fg.input:bind(key_action[1], key_action[2]) 
    end
end

function PersonJump:personJumpUpdate(dt)
    local vx, vy = self.body:getLinearVelocity()
    if not self.melee_attack_movement_locked then
        if self.fg.input:pressed('jump') then self:jumpPressed() end
        if self.fg.input:released('jump') then self:jumpReleased() end
    end

    if not self.melee_attack_movement_locked then self.body:setGravityScale(1) end
    if self.wall_sliding then 
        self.body:setGravityScale(0) 
        self.body:setLinearVelocity(vx, 100)
        if self.wall_sliding == 'left' and self.fg.input:pressed('moveRight') then
            self.wall_sliding = false
            self.body:setGravityScale(1)
        end
        if self.wall_sliding == 'right' and self.fg.input:pressed('moveLeft') then
            self.wall_sliding = false
            self.body:setGravityScale(1)
        end
        if self.wall_sliding == 'left' and not self.fg.input:down('moveLeft') then
            self.wall_sliding = false
            self.body:setGravityScale(1)
        end
        if self.wall_sliding == 'right' and not self.fg.input:down('moveRight') then
            self.wall_sliding = false
            self.body:setGravityScale(1)
        end
    end
end

function PersonJump:personJumpDraw()

end

function PersonJump:jumpPressed()
    local vx, vy = self.body:getLinearVelocity()
    if self.jumps_left >= 1 then
        self.jumps_left = self.jumps_left - 1

        -- Wall sliding jump
        if self.wall_sliding then
            self.body:setLinearVelocity(vx, -self.jump_a)
            if self.wall_sliding == 'left' then
                if self.fg.input:down('moveLeft') then
                    self:push(200, 0, 0.5)
                end
            end
            if self.wall_sliding == 'right' then
                if self.fg.input:down('moveRight') then
                    self:push(-200, 0, 0.5)
                end
            end
            self.movement_locked = false
            self.wall_sliding = false
            self.body:setGravityScale(1)
        -- Normal jump
        else
            self.on_ground = false
            self.body:setLinearVelocity(vx, -self.jump_a)
        end
    end
end

function PersonJump:jumpReleased()
    self.v.y = 0
end

function PersonJump:jumpOnCollisionEnter(other, contact)
    if other.tag == 'Solid' then
        local x1, y1 = contact:getPositions()

        -- on_ground
        if y1 > self.y then
            self.on_ground = true
            self.jumps_left = self.max_jumps
        end

        -- Wall Sliding
        if x1 <= self.x - self.w/2 then
            self.wall_sliding = 'left' 
            self.jumps_left = self.max_jumps
        end
        if x1 >= self.x + self.w/2 then
            self.wall_sliding = 'right'
            self.jumps_left = self.max_jumps
        end
    end
end

function PersonJump:personJumpSave()
    return {jump_a = self.jump_a, max_jumps = self.max_jumps, jumps_left = self.jumps_left, on_ground = self.on_ground, falling = self.falling, wall_sliding = self.wall_sliding}
end

return PersonJump
