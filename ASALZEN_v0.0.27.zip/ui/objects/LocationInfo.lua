local LocationInfo = fg.Object:extend('LocationInfo')

LocationInfo.layer = 'UI_Info'

function LocationInfo:new(x, y, settings)
    self.fs = 24*fg.screen_scale/512 
    self.text = settings.text
    self.font = fg.Fonts.helsinki
    self.w = self.fs*self.font:getWidth(self.text) + 10*fg.screen_scale
    self.timer = fg.Timer()
    self.h = 0
    self.h_tween_up = tru 
    self.timer:tween(0.1, self, {h = self.fs*self.font:getHeight() + 10*fg.screen_scale}, 'linear', function() self.h_tween_up = false end)
    self.x, self.y = x, y + (self.fs*self.font:getHeight() + 10*fg.screen_scale)/2

    self.final_h = self.fs*self.font:getHeight() + 10*fg.screen_scale
    self.bg_x, self.bg_y = x - 300, y
    self.timer:tween(0.1, self, {bg_x = x - 10}, 'linear')

    self.text_x = x - 250
    self.timer:tween(0.2, self, {text_x = x}, 'linear')
end

function LocationInfo:update(dt)
    self.timer:update(dt)
    self.final_h = self.fs*self.font:getHeight() + 10*fg.screen_scale
    if not self.h_tween_up then self.h = self.fs*self.font:getHeight() + 10*fg.screen_scale end
    self.y = fg.screen_height - 35*fg.screen_scale + (self.fs*self.font:getHeight() + 10*fg.screen_scale)/2
    self.bg_y = fg.screen_height - 35*fg.screen_scale
    self.fs = 24*fg.screen_scale/512
    self.w = self.fs*self.font:getWidth(self.text) + 10*fg.screen_scale
end

function LocationInfo:draw()
    fg.utils.graphics.pushRotate(self.x + self.w/2, self.y, math.pi/32)
    love.graphics.setColor(unpack(UI.colors.yellow))
    fg.utils.graphics.roundedRectangle('fill', self.bg_x, self.bg_y, self.w - 10, self.final_h, 6*fg.screen_scale, 6*fg.screen_scale)
    love.graphics.pop()

    love.graphics.setScissor(self.x, self.y - self.h/2, self.w, self.h)
    love.graphics.setColor(unpack(UI.colors.bg))
    fg.utils.graphics.roundedRectangle('fill', self.x, self.y - self.h/2, self.w, self.h, 6*fg.screen_scale, 6*fg.screen_scale)
    love.graphics.setColor(unpack(UI.colors.white))
    love.graphics.setFont(self.font)
    love.graphics.print(self.text, self.text_x + 5*fg.screen_scale, self.y - self.final_h/2 + 5*fg.screen_scale, 0, self.fs, self.fs)
    love.graphics.setScissor()
end

return LocationInfo
