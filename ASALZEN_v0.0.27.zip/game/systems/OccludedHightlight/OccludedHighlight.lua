local OccludedHighlight = fg.Object:extend('OccludedHighlight')

function OccludedHighlight:new()
    self.highlightables = {}
    self.blockers = {}
    self.canvas_1 = love.graphics.newCanvas(fg.screen_width, fg.screen_height)
    self.canvas_1:setFilter('nearest', 'nearest')
    self.canvas_2 = love.graphics.newCanvas(fg.screen_width, fg.screen_height)
    self.canvas_2:setFilter('nearest', 'nearest')
    self.canvas_3 = love.graphics.newCanvas(fg.screen_width, fg.screen_height)
    self.canvas_3:setFilter('nearest', 'nearest')
    self.outline = love.graphics.newShader('resources/shaders/default.vert', 'resources/shaders/outline3.frag')
    self.highlight = love.graphics.newShader('resources/shaders/default.vert', 'resources/shaders/highlight.frag')
end

function OccludedHighlight:update(dt)
    self.highlightables = fg.world.areas[fg.current_area]:getEntitiesWhere(function() return true end, {'Person', 'PersonAI', 'Box', 'Bucket', 'Chair', 'Desk', 'Table', 'LevelTransition'})
    self.blockers = fg.world.areas[fg.current_area]:getEntitiesWhere(function() return true end, {'DownWall'})

    self.outline:send('outline_color', {1, 0, 1})
end

function OccludedHighlight:draw()
    self.canvas_1:clear()
    self.canvas_2:clear()
    self.canvas_3:clear()

    self.canvas_1:renderTo(function()
        fg.world:renderAttach()
        for _, hl in ipairs(self.highlightables) do hl:highlightDraw() end
        fg.world:renderDetach()
    end)

    self.canvas_2:renderTo(function()
        fg.world:renderAttach()
        love.graphics.setColor(255, 0, 255)
        for _, bl in ipairs(self.blockers) do love.graphics.rectangle('fill', bl.x - bl.w/2, bl.y - bl.h/2, bl.w, bl.h) end
        love.graphics.setColor(255, 255, 255)
        fg.world:renderDetach()
    end)

    self.canvas_3:renderTo(function()
        love.graphics.setShader(self.outline)
        love.graphics.draw(self.canvas_1, 0, 0)
        love.graphics.setShader()
    end)

    self.highlight:send('down_wall', self.canvas_2)
    love.graphics.setShader(self.highlight)
    love.graphics.draw(self.canvas_3, 0, 0, 0, fg.screen_scale, fg.screen_scale)
    love.graphics.setShader()
end

return OccludedHighlight
