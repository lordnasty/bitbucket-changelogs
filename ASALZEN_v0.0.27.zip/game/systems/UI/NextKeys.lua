local NextKeys = fg.Class('NextKeys', 'Entity')

NextKeys.layer = 'UI'

function NextKeys:new(area, x, y, settings)
    local settings = settings or {}
    NextKeys.super.new(self, area, x, y, settings)
    self.moves = {}
    self.visual = self.fg.Assets.triangle
end

function NextKeys:update(dt)
    local _ = self.fg.fn
    local player = game.player
    local entities = player.melee_attack_entity_queue
    self.moves = {}
    for k, e in ipairs(entities) do self.moves = _.select(_.append(self.moves, e.hp.sequence), function(k, v) return (v ~= 'gl' and v ~= 'gr') end) end
end

function NextKeys:draw()
    self.world:renderDetach()
    local y = 128
    local pad_w = 8
    local vw, vh = self.visual:getWidth(), self.visual:getHeight()
    local w = pad_w + #self.moves*(vw + pad_w) 
    for i, m in ipairs(self.moves) do
        if m == 'l' then
            if i == 1 then love.graphics.setColor(239, 140, 140, 255)
            else love.graphics.setColor(189, 90, 90, 255) end
            love.graphics.draw(self.visual, 192 + (i-1)*(vw + pad_w), y, 0, -1, 1, vw/2, vh/2)
        elseif m == 'r' then
            if i == 1 then love.graphics.setColor(140, 172, 239, 255)
            else love.graphics.setColor(90, 122, 189, 255) end
            love.graphics.draw(self.visual, 192 + (i-1)*(vw + pad_w), y, 0, 1, 1, vw/2, vh/2)
        end
    end
    love.graphics.setColor(255, 255, 255, 255)
    self.world:renderAttach()
end

return NextKeys


--[[
~~stand up head data~~
1 right 10, down 32
2 right 10, down 30
3 right 11, down 27
4 right 11, down 27
5 right 11, down 26
6 right 11, down 25
7 right  6, down 7
8 right  4, down 5
9 right -1, down -1
10 0,0
]]--
