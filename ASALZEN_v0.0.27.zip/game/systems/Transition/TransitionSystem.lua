local TransitionSystem = fg.Object:extend('TransitionSystem')

function TransitionSystem:new(type, delay, settings)
    local settings = settings or {}
    self.w, self.h = love.window.getWidth(), love.window.getHeight()
    self.tobjects = {}

    if fg.fn.any({'rectangle up', 'rectangle down', 'rotating rectangle up', 'rotating rectangle down', 'rectangle lr up', 'rectangle lr down'}, type) then
        local a = 30*fg.screen_scale/1.25
        local n, m = self.w/a, self.h/a
        local n_w, n_h = self.w/n, self.h/m
        local n = delay/(n_w*n_h)
        for i = 1, n_h do
            for j = 1, n_w do
                if type == 'rectangle up' then 
                    table.insert(self.tobjects, TransitionRectangle((j-1)*a + a/2, (i-1)*a + a/2, 0, nil, 0, 0, 1.05*a, 1.05*a, delay))
                elseif type == 'rectangle down' then 
                    table.insert(self.tobjects, TransitionRectangle((j-1)*a + a/2, (i-1)*a + a/2, 0, nil, 1, 1, 1.05*a, 1.05*a, delay))
                elseif type == 'rotating rectangle up' then 
                    table.insert(self.tobjects, TransitionRectangle((j-1)*a + a/2, (i-1)*a + a/2, 0, math.pi, 0, 0, 1.1*a, 1.1*a, delay))
                elseif type == 'rotating rectangle down' then
                    table.insert(self.tobjects, TransitionRectangle((j-1)*a + a/2, (i-1)*a + a/2, 0, math.pi, 1, 1, 1.1*a, 1.1*a, delay))
                elseif type == 'rectangle lr up' then
                    local sn = j + (i-1)*n_w
                    local r = fg.utils.math.random(0.01, 0.04)
                    table.insert(self.tobjects, TransitionRectangle((j-1)*a + a/2, (i-1)*a + a/2, 0, nil, 0, 0, 1.3*a, 1.3*a, math.max(0, delay-(1.5*sn*n))))
                elseif type == 'rectangle lr down' then
                    local sn = j + (i-1)*n_w
                    local r = fg.utils.math.random(0.01, 0.04)
                    table.insert(self.tobjects, TransitionRectangle((j-1)*a + a/2, (i-1)*a + a/2, 0, nil, 1, 1, 1.3*a, 1.3*a, math.max(0, delay-(1.5*sn*n))))
                end
            end
        end
    end
end

function TransitionSystem:update(dt)
    for _, tobject in ipairs(self.tobjects) do tobject:update(dt) end
end

function TransitionSystem:draw()
    for _, tobject in ipairs(self.tobjects) do tobject:draw() end
end

return TransitionSystem
