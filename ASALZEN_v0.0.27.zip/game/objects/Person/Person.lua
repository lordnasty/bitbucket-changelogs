local Person = fg.Class('Person', 'Entity')
Person:implement(fg.PhysicsBody)
Person:implement(Pseudo3D)
Person:implement(Shadow)
Person:implement(PersonMovement)
Person:implement(Animated)
Person:implement(SingleMeleeAttack)
Person:implement(DoorOpener)
Person:implement(PlayerHittable)
Person:implement(Stats)

local movement_keys = {
    {'left', 'moveLeft'}, {'right', 'moveRight'}, {'up', 'moveUp'}, {'down', 'moveDown'},
    {'dpleft', 'moveLeft'}, {'dpright', 'moveRight'}, {'dpup', 'moveUp'}, {'dpdown', 'moveDown'},
    {'leftx', 'moveHorizontal'}, {'lefty', 'moveVertical'},
}

local melee_attack_keys = {
    {'z', 'leftAttack'}, {'c', 'rightAttack'},
    {'a', 'leftSelect'}, {'d', 'rightSelect'},
    {'l1', 'leftAttack'}, {'r1', 'rightAttack'},
    {'l2', 'leftSelect'}, {'r2', 'rightSelect'},
}

local action_keys = {
    {'v', 'action'}, {'fdown', 'action'},
}

Person.ignores = {'Table'}

function Person:new(area, x, y, settings)
    local settings = settings or {}
    Person.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    self:physicsBodyNew(area, x, y, settings)
    self:pseudo3DNew({height_z = 50, settings = settings})

    for _, key_action in ipairs(action_keys) do self.fg.input:bind(key_action[1], key_action[2]) end
    self:personMovementNew({keys = movement_keys, settings = settings})
    self:animatedNew({animations = self.fg.person_animations, settings = settings})
    settings.hair_index = 8
    self.head = self.fg.world.areas[self.fg.current_area]:createEntityImmediate('PersonHead', self.x, self.y, {parent = self, no_layer = true, settings = settings})
    self:singleMeleeAttackNew({keys = melee_attack_keys, settings = settings})
    self:playerHittableNew({settings = settings})
    self:doorOpenerNew()
    self:statsNew({settings = settings})

    game.player = self
end

function Person:update(dt)
    self.timer:update(dt)
    self:physicsBodyUpdate(dt)
    self:pseudo3DUpdate(dt)

    self:personMovementUpdate(dt)
    self:animatedUpdate(dt)
    self.head:update(dt)
    self:singleMeleeAttackUpdate(dt)
    self:playerHittableUpdate(dt)
    self:doorOpenerUpdate(dt)
    self:statsUpdate(dt)
end

function Person:draw()
    self:shadowDraw()

    if self.animation_state == 'kick' or self.animation_state == 'block' then
        self.head:draw()
        self:animatedDraw()
    else
        self:animatedDraw()
        self.head:draw()
    end

    local animation = nil
    if self.animation_state == 'strong_punch_left' then animation = self.animations.strong_punch_left_arm 
    elseif self.animation_state == 'strong_punch_right' then animation = self.animations.strong_punch_right_arm end
    if animation then animation.animation:draw(self.x, self.y, 0, self.animation_flip*(self.sx or 1), (self.sy or 1), -animation.x_offset, self.z - animation.y_offset) end

    self:physicsBodyDraw()
    self:pseudo3DDraw()

    self:singleMeleeAttackDraw()
end

function Person:highlightDraw()
    if self.animation_state == 'kick' or self.animation_state == 'block' then
        self.head:highlightDraw()
        self:animatedHighlightDraw()
    else
        self:animatedHighlightDraw()
        self.head:highlightDraw()
    end

    local animation = nil
    if self.animation_state == 'strong_punch_left' then animation = self.animations.strong_punch_left_arm 
    elseif self.animation_state == 'strong_punch_right' then animation = self.animations.strong_punch_right_arm end
    if animation then animation.animation:draw(self.x, self.y, 0, self.animation_flip*(self.sx or 1), (self.sy or 1), -animation.x_offset, self.z - animation.y_offset) end
end

function Person:onCollisionEnter(other, contact)

end

function Person:save()
    local pseudo_3d = self:pseudo3DSave()
    local person_movement = self:personMovementSave()
    local animated = self:animatedSave()
    local single_melee_attack = self:singleMeleeAttackSave()
    local stats = self:statsSave()
    local head = self.head:save()
    local save_data = {}
    for k, v in pairs(pseudo_3d) do save_data[k] = v end
    for k, v in pairs(person_movement) do save_data[k] = v end
    for k, v in pairs(animated) do save_data[k] = v end
    for k, v in pairs(single_melee_attack) do save_data[k] = v end
    for k, v in pairs(stats) do save_data[k] = v end
    for k, v in pairs(head) do save_data[k] = v end
    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y
    save_data.w, save_data.h = self.w, self.h
    save_data.shape = 'BSGRectangle'
    save_data.s = self.s
    return save_data
end

return Person
