local AoEMeleeAttack = fg.Object:extend('AoEMeleeAttack')

local lock_targets = {'PersonAI'}

function AoEMeleeAttack:aoeMeleeAttackNew(settings)
    local settings = settings or {}

    for _, key_action in ipairs(settings.keys) do self.fg.input:bind(key_action[1], key_action[2]) end
    self.melee_attack_entity_queue = {}
    self.melee_attack_closest_entity = nil
    self.melee_attack_next_closest_entity = nil
    self.melee_attack_locked = false -- external, when the player is locked to an enemy radius-wise, not after it attempts a hit
    self.melee_attack_hit_locked = false
    self.melee_attack_movement_locked = false -- external, after the player starts actual combat with an enemy and he can't move until that enemy dies
    self.melee_attack_line_locked = false
    self.melee_attack_lock_radius = settings.settings.melee_attack_lock_radius or 300
    self.melee_attack_new_p = nil
    self.vulnerable_to_attack = false -- external, first miss vulnerability
    self.light_punch_left = settings.settings.light_punch_left or false
    self.light_punch_right = settings.settings.light_punch_right or false
    self.strong_punch_left = settings.settings.strong_punch_left or false
    self.strong_punch_right = settings.settings.strong_punch_right or false
    self.kick = settings.settings.kick or false
    self.low_dash = settings.settings.low_dash or false
    self.dash = settings.settings.dash or false
    self.backdash = settings.settings.backdash or false
    self.block = settings.settings.block or false

    self.attack_line = self.area:createEntityImmediate('AttackLineVisual', -10000, -10000)
    self.closest_attack_lock = self.area:createEntityImmediate('AttackLockVisual', -10000, -10000)
end

function AoEMeleeAttack:aoeMeleeAttackUpdate(dt)
    -- Lock logic
    local entities = self.fg.fn.select(self.fg.world.areas[self.fg.current_area]:queryAreaCircle(self.x, self.y, self.melee_attack_lock_radius, lock_targets),
                     function(k, v) if v.id ~= self.id and not v.dying then return true end end)

    -- Sort entities based on proximity to player
    table.sort(entities, function(a, b)
        local d1 = self.fg.mlib.line.getDistance(self.x, self.y, a.body:getPosition())
        local d2 = self.fg.mlib.line.getDistance(self.x, self.y, b.body:getPosition())
        if d1 < d2 then return true end
    end)

    -- Insert all entities if they're not already in the array
    for i = 1, #entities do
        if entities[i] then
            if not self.fg.fn.contains(self.melee_attack_entity_queue, function(v) if v.entity.id == entities[i].id then return true end end) then
                table.insert(self.melee_attack_entity_queue, {entity = entities[i], hits_taken = 0})
            end
        end
    end

    -- Sort array based on number of hits taken
    table.sort(self.melee_attack_entity_queue, function(a, b) return a.hits_taken < b.hits_taken end)

    -- Remove entities that are far away enough
    for i = #self.melee_attack_entity_queue, 1, -1 do
        local d = self.fg.mlib.line.getDistance(self.x, self.y, self.melee_attack_entity_queue[i].entity.x, self.melee_attack_entity_queue[i].entity.y)
        if d > 1.5*self.melee_attack_lock_radius then table.remove(self.melee_attack_entity_queue, i) end
    end

    self.melee_attack_closest_entity = self.melee_attack_entity_queue[1]
    self.melee_attack_next_closest_entity = self.melee_attack_entity_queue[2]

    -- Set melee attack locked
    if self.melee_attack_locked and not self.melee_attack_closest_entity then self.melee_attack_locked = false
    elseif not self.melee_attack_locked and self.melee_attack_closest_entity then self.melee_attack_locked = true end
    -- if not self.melee_attack_locked then self.melee_attack_first_hit = true end

    -- Attack logic
    if self.melee_attack_closest_entity then
        local attack_type = nil
        if self.fg.input:pressed('leftAttack') then attack_type = 'left' end
        if self.fg.input:pressed('rightAttack') then attack_type = 'right' end

        -- If attack pressed...
        if attack_type and not self.vulnerable_to_attack then
            self.melee_attack_line_locked = true
            self.melee_attack_hit_locked = true
            self.melee_attack_movement_locked = true
            local hit = self.melee_attack_closest_entity.entity.hp:hitOrMiss(attack_type)
            if hit then
                self:singleMeleeAttackTweenTo(self.melee_attack_closest_entity.entity.x, self.melee_attack_closest_entity.entity.y, 30, 0)
                self.timer:after(0.08, function() 
                    self:singleMeleeAttack(attack_type) 
                    self.melee_attack_hit_locked = false
                end)
            else
                self.vulnerable_to_attack = true
                self.melee_attack_closest_entity.entity:insertPreDeferredCall('setVulnerableTarget', self, 0)
                self.timer:after(0.2, function() 
                    self.vulnerable_to_attack = false 
                    self.melee_attack_movement_locked = false
                    self.melee_attack_hit_locked = false
                    self.melee_attack_line_locked = false
                end)
            end
        end
    end

    -- Set camera follow
    if self.melee_attack_closest_entity then
        self.fg.world.camera:follow({x = (self.x + self.melee_attack_closest_entity.entity.x)/2, y = (self.y + self.melee_attack_closest_entity.entity.y)/2}, {follow_style = 'lockon', lerp = 20})
    else self.fg.world.camera:follow(self, {follow_style = 'lockon', lerp = 10}) end

    -- Fix player's position if he has started attack on enemy
    if self.melee_attack_hit_locked and self.melee_attack_new_p then self.body:setPosition(self.melee_attack_new_p.x, self.melee_attack_new_p.y) end

    -- Set attack lock parents
    if self.melee_attack_closest_entity then self.closest_attack_lock.parent = self.melee_attack_closest_entity.entity
    else self.closest_attack_lock.parent = nil end
    self.closest_attack_lock:update(dt)

    -- Set attack line targets
    if self.melee_attack_closest_entity and not self.melee_attack_line_locked then
        self.attack_line.target_1 = self
        self.attack_line.target_2 = self.melee_attack_closest_entity.entity
    end
    if self.melee_attack_line_locked and not self.melee_attack_hit_locked then
        if self.melee_attack_next_closest_entity then
            self.attack_line.target_1 = self
            self.attack_line.target_2 = self.melee_attack_next_closest_entity.entity
        else
            self.attack_line.target_1 = nil
            self.attack_line.target_2 = nil
        end
    end
    if not self.melee_attack_closest_entity then 
        self.attack_line.target_1 = nil
        self.attack_line.target_2 = nil
    end
end

function AoEMeleeAttack:aoeMeleeAttackDraw()

end

function AoEMeleeAttack:aoeMeleeAttackSave()

end

return AoEMeleeAttack
