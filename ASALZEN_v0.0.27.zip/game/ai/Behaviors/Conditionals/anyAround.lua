local anyAround = Action:extend('anyAround')

function anyAround:new(object_types, radius)
    anyAround.super.new(self, 'anyAround')

    self.object_types = object_types
    self.radius = radius
end

function anyAround:update(dt, context)
    return anyAround.super.update(self, dt, context)
end

function anyAround:run(dt, context)
    local x, y = context.object.body:getPosition()
    local entities = context.object.world:queryAreaCircle(x, y, self.radius, self.object_types)
    if #entities == 0 then 
        return 'failure'
    else
        local entity = entities[math.random(1, #entities)]
        while entity.id == context.object.id do entity = entities[math.random(1, #entities)] end
        context.any_around_entity = entity 
        return 'success'
    end
end

function anyAround:start(context)

end

function anyAround:finish(status, context)

end

return anyAround
