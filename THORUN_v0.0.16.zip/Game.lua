local Game = fg.Object:extend('Game')

require 'data/Animations'

-- Require everything that can be required here
local prepaths = {'level/', 'mixins/', 'objects/', 'systems/', 'ai/Behaviors/'}
for _, prepath in ipairs(prepaths) do
    for _, p in ipairs(love.filesystem.getDirectoryItems('game/' .. prepath)) do
        if love.filesystem.isDirectory('game/' .. prepath .. p) then
            for _, f in ipairs(love.filesystem.getDirectoryItems('game/' .. prepath .. p .. '/')) do
                if f:sub(-4) == '.lua' then _G[f:sub(1, -5)] = require('game/' .. prepath .. p .. '/' .. f:sub(1, -5)) end
            end
        else if p:sub(-4) == '.lua' then _G[p:sub(1, -5)] = require('game/' .. prepath .. p:sub(1, -5)) end end
    end
end

-- Load scripts
SH = require 'game/scripts/ScriptHelper'
Scripts = {}
for _, p in ipairs(love.filesystem.getDirectoryItems('game/scripts')) do
    if p ~= 'ScriptHelper.lua' then
        Scripts[p:sub(1, -5)] = require('game/scripts/' .. p:sub(1, -5))
    end
end

function Game:new()
    love.graphics.setLineStyle('rough')
    love.graphics.setBackgroundColor(32, 32, 32)
    fg.setScreenSize(960, 720)
    fg.lovebird_enabled = true

    fg.input:bind('kp0', function() fg.debugDraw.physics_enabled = not fg.debugDraw.physics_enabled end)
    fg.input:bind('f1', function() fg.lurker.scan() end)
    fg.input:bind('f5', 'activate')
    fg.input:bind('f6', 'activateMem')

    local shaders = require('resources/shaders/shaders')
    fg.Shaders = {}
    fg.Shaders['combine'] = shaders.combine
    
    -- Transitions
    self.screen_transition = nil

    -- Editor settings
    self.active = false

    -- Set editor objects
    self.objects = {}
    require('data/EditorObjects')(self)

    -- Set editor tilesets
    self.tile_width, self.tile_height = 32, 32
    self.tilesets = fg.fn.map(love.filesystem.getDirectoryItems('resources/tilesets'), function(k, v) return v:sub(1, -5) end)

    -- Set editor layers
    self.layers = {'Collision', 'Background_2', 'Background_1', 'Default', 'Front_1', 'Front_2'}
    for _, layer in ipairs(self.layers) do fg.world:addLayer(layer) end

    self.levels = {}
    self.levels['Editor'] = Level(self, 'Editor', 0, 0)
    self.all_maps = {}
    for _, file in ipairs(love.filesystem.getDirectoryItems('resources/maps')) do table.insert(self.all_maps, file) end
    -- Here is where you'll create a floor and inject higher level game structure logic later
    for _, map in ipairs(self.all_maps) do self.levels[map] = Level(self, map, 0, 0) end

    self.first_player = false
    
    self:loadAssets()
end

function Game:update(dt)
    if not self.finished_loading then fg.Loader.update(); return end
    if not self.active then return end
    if fg.input:pressed('activate') then self:activate() end
    if fg.input:pressed('activateMem') then self:activateMem() end

    fg.world:sortLayerRenderOrder('Default', function(a, b) if b.class_name == 'Player' then return true end end)

    for _, level in pairs(self.levels) do level:update(dt) end
    if self.screen_transition then self.screen_transition:update(dt) end
end

function Game:draw()
    for _, level in pairs(self.levels) do level:draw() end
    if self.screen_transition then self.screen_transition:draw() end
end

function Game:start()
    self.active = true
    fg.debugDraw.physics_enabled = true
    fg.world.box2d_world:setGravity(0, 20*32)
    fg.world.areas['Default']:deactivate()

    -- Set game layers
    fg.world:addLayer('BG_Sky_2', {parallax_scale = 0.4})
    fg.world:addLayer('BG_Sky_1', {parallax_scale = 0.45})
    fg.world:addLayer('BG_Trees_3', {parallax_scale = 0.5})
    fg.world:addLayer('BG_Trees_2', {parallax_scale = 0.55})
    fg.world:addLayer('BG_Trees_1', {parallax_scale = 0.6})
    fg.world:addLayer('BG_Water_4', {parallax_scale = 0.62})
    fg.world:addLayer('BG_Water_3', {parallax_scale = 0.65})
    fg.world:addLayer('BG_Water_2', {parallax_scale = 0.7})
    fg.world:addLayer('BG_Water_1', {parallax_scale = 0.8})
    fg.world:addLayer('BG_Mountain_3', {parallax_scale = 0.85})
    fg.world:addLayer('BG_Mountain_2', {parallax_scale = 0.9})
    fg.world:addLayer('BG_Mountain_1', {parallax_scale = 0.95})
    fg.world:addLayer('Effects')
    fg.world:addLayer('Effects_Front')
    fg.world:addLayer('Default_Trail')
    fg.world:setLayerOrder({'Collision', 'BG_Sky_2', 'BG_Sky_1', 'BG_Trees_3', 'BG_Trees_2', 'BG_Trees_1', 'BG_Water_4', 'BG_Water_3', 'BG_Water_2', 'BG_Water_1', 
                            'BG_Mountain_3', 'BG_Mountain_2', 'BG_Mountain_1', 'Background_2', 'Background_1', 'Default_Trail', 'Default', 'Front_1', 'Front_2', 'Effects', 'Effects_Front'})

    fg.current_area = 'StartArea'
    self.levels['StartArea']:activate()
    fg.world.areas['StartArea']:initializePools()
end

function Game:screenTransition(transition_type, delay)
    self.screen_transition = TransitionSystem(transition_type, delay) 
end

function Game:changeLevelTo(level_name)
    local previous_area = fg.current_area
    self.levels[fg.current_area]:deactivate()
    self.levels[fg.current_area]:saveFromGame(fg.current_area .. '_GAME')
    fg.world.areas[fg.current_area]:clear()
    fg.world.areas[fg.current_area]:initializePools()
    fg.current_area = level_name
    if love.filesystem.exists('maps/' .. level_name .. '_GAME') then
        self.levels[fg.current_area]:loadFromGame(level_name .. '_GAME', previous_area .. '_GAME')
        self.levels[fg.current_area]:activate()
    else
        self.levels[fg.current_area]:loadFromEditor(level_name, previous_area .. '_GAME')
        self.levels[fg.current_area]:activate()
    end
    fg.world:unpause()
    fg.world:update(0)
    self.levels[fg.current_area]:movePlayerToTransitionPosition(previous_area)
    fg.world:pause()
    self.levels[fg.current_area]:loadScriptsPost(previous_area)
    if not self.first_player then self.first_player = true end
end

function Game:activate()
    if self.first_player then self.first_player = false end
    editor.active = false
    self.levels['Editor']:deactivate()
    for _, map in ipairs(self.all_maps) do fg.world.areas[map]:clear(); fg.world.areas[map]:initializePools(); fg.world.areas[map]:deactivate() end
    fg.current_area = 'StartArea'
    fg.world.areas[fg.current_area]:clear()
    fg.world.areas[fg.current_area]:initializePools()
    editor.map_textinput:setText('StartArea')
    self.levels[fg.current_area]:loadFromEditor('StartArea')
    self.levels[fg.current_area]:activate()
    local tilemap = self.levels[fg.current_area].tilemaps['Default']
    editor.previous_scale = fg.screen_scale
    local x, y = fg.world.camera:getPosition()
    editor.previous_camera_position = {x = x, y = y}
    fg.world.camera:moveTo(tilemap.x, tilemap.y)
    fg.setScale(2)
    for _, layer in ipairs(fg.world.layers_order) do fg.world:activateLayer(layer) end
    love.mouse.setVisible(true)
    if not self.first_player then self.first_player = true end
end

function Game:activateMem()
    if not self.levels['Editor'].last_editor_loaded_map then return end
    if self.first_player then self.first_player = false end
    editor.active = false
    self.levels['Editor']:deactivate()
    for _, map in ipairs(self.all_maps) do fg.world.areas[map]:clear(); fg.world.areas[map]:initializePools(); fg.world.areas[map]:deactivate() end
    fg.current_area = self.levels['Editor'].last_editor_loaded_map
    fg.world.areas[fg.current_area]:clear()
    fg.world.areas[fg.current_area]:initializePools()
    editor.map_textinput:setText(fg.current_area)
    self.levels[fg.current_area]:loadFromEditor(fg.current_area)
    self.levels[fg.current_area]:activate()
    local tilemap = self.levels[fg.current_area].tilemaps['Default']
    editor.previous_scale = fg.screen_scale
    local x, y = fg.world.camera:getPosition()
    editor.previous_camera_position = {x = x, y = y}
    fg.world.camera:moveTo(tilemap.x, tilemap.y)
    fg.setScale(2)
    for _, layer in ipairs(fg.world.layers_order) do fg.world:activateLayer(layer) end
    love.mouse.setVisible(true)
    if not self.first_player then self.first_player = true end
end

function Game:loadAssets()
    local assets = {
        -- Backgrounds
        snow_background = 'resources/backgrounds/snow_background.png',
        temple_background_back = 'resources/backgrounds/temple_background_back.png', 
        temple_background_back_bottom = 'resources/backgrounds/temple_background_back_bottom.png',
        temple_background_middle = 'resources/backgrounds/temple_background_middle.png',
        temple_background_middle_bottom = 'resources/backgrounds/temple_background_middle_bottom.png',
        snow_bg_water_1 = 'resources/backgrounds/snow_bg_water_1.png',
        snow_bg_water_2 = 'resources/backgrounds/snow_bg_water_2.png',
        snow_bg_water_3 = 'resources/backgrounds/snow_bg_water_3.png',
        snow_bg_water_4 = 'resources/backgrounds/snow_bg_water_4.png',
        snow_bg_trees_1 = 'resources/backgrounds/snow_bg_trees_1.png',
        snow_bg_trees_2 = 'resources/backgrounds/snow_bg_trees_2.png',
        snow_bg_trees_3 = 'resources/backgrounds/snow_bg_trees_3.png',
        snow_bg_sky_1 = 'resources/backgrounds/snow_bg_sky_1.png',
        snow_bg_sky_2 = 'resources/backgrounds/snow_bg_sky_2.png',
        snow_bg_mountain = 'resources/backgrounds/snow_bg_mountain.png',
        snow_bg_clouds_1 = 'resources/backgrounds/snow_bg_clouds_1.png',
        snow_bg_clouds_2 = 'resources/backgrounds/snow_bg_clouds_2.png',
        snow_bg_clouds_3 = 'resources/backgrounds/snow_bg_clouds_3.png',
        snow_bg_clouds_4 = 'resources/backgrounds/snow_bg_clouds_4.png',
        snow_bg_clouds_5 = 'resources/backgrounds/snow_bg_clouds_5.png',
        snow_bg_clouds_6 = 'resources/backgrounds/snow_bg_clouds_6.png',

        -- Player
        --[[
        player_basic_attack = 'resources/characters/player/basic_attack.png',
        player_block = 'resources/characters/player/block.png',
        player_climb = 'resources/characters/player/climb.png',
        player_death = 'resources/characters/player/death.png',
        player_fall = 'resources/characters/player/fall.png',
        player_hammer_throw = 'resources/characters/player/hammer_throw.png',
        player_heavy_attack = 'resources/characters/player/heavy_attack.png',
        player_hurt = 'resources/characters/player/hurt.png',
        player_idle = 'resources/characters/player/idle.png',
        player_jump = 'resources/characters/player/jump.png',
        player_run = 'resources/characters/player/run.png',
        player_light_attack_1 = 'resources/characters/player/light_attack_1.png',
        player_light_attack_2 = 'resources/characters/player/light_attack_2.png',
        player_light_attack_3 = 'resources/characters/player/light_attack_3.png',
        player_light_attack_4 = 'resources/characters/player/light_attack_4.png',
        player_light_attack_5 = 'resources/characters/player/light_attack_5.png',
        ]]--

        -- New player
        player_block = 'resources/characters/new_player/block.png',
        player_climb = 'resources/characters/new_player/climb.png',
        player_fall = 'resources/characters/new_player/fall.png',
        player_jump = 'resources/characters/new_player/jump.png',
        player_idle = 'resources/characters/new_player/idle.png',
        player_run = 'resources/characters/new_player/run.png',
        player_attack_1 = 'resources/characters/new_player/attack_1.png',
        player_attack_2 = 'resources/characters/new_player/attack_2.png',
        player_attack_3 = 'resources/characters/new_player/attack_3.png',
        player_attack_4 = 'resources/characters/new_player/attack_4.png',

        -- Blaster
        blaster_attack = 'resources/characters/blaster/attack.png',
        blaster_attack_single = 'resources/characters/blaster/attack_single.png',
        blaster_hurt_single = 'resources/characters/blaster/hurt_single.png',
        blaster_hurt = 'resources/characters/blaster/hurt.png',
        blaster_idle = 'resources/characters/blaster/idle.png',
        blaster_move = 'resources/characters/blaster/move.png',
        blaster_move_single = 'resources/characters/blaster/move_single.png',

        -- Decorations
        grass = 'resources/decorations/grass.png',
        energy_thing = 'resources/decorations/energy_thing.png',
        high_plant = 'resources/decorations/high_plant.png',
        stone_plant = 'resources/decorations/stone_plant.png',
        vines = 'resources/decorations/vines.png',
        wall_plant_1 = 'resources/decorations/wall_plant_1.png',
        wall_plant_2 = 'resources/decorations/wall_plant_2.png',
        wall_plant_3 = 'resources/decorations/wall_plant_3.png',
        wire_1 = 'resources/decorations/wire_1.png',
        wire_2 = 'resources/decorations/wire_2.png',
        torch = 'resources/decorations/torch.png',

        -- Effects
        explosion_blast_1 = 'resources/effects/explosion_blast_1.png',
        explosion_blast_2 = 'resources/effects/explosion_blast_2.png',
        explosion_flash_1 = 'resources/effects/explosion_flash_1.png',
        explosion_flash_2 = 'resources/effects/explosion_flash_2.png',
        explosion_flash_3 = 'resources/effects/explosion_flash_3.png',
        explosion_flash_4 = 'resources/effects/explosion_flash_4.png',
        hit_effect_1 = 'resources/effects/hit_effect_1.png',
        hit_effect_2 = 'resources/effects/hit_effect_2.png',
        hit_effect_3 = 'resources/effects/hit_effect_3.png',
        hit_effect_4 = 'resources/effects/hit_effect_4.png',
        robot_bits = 'resources/effects/robot_bits.png',
        player_disengage_trail = 'resources/characters/player/fall_trail.png',

        -- Objects
        snow_boulder = 'resources/objects/snow_boulder.png',
        snow_breakable = 'resources/objects/snow_breakable.png',
        terminal = 'resources/objects/terminal.png',
        capsule_opened = 'resources/objects/capsule_opened.png',
        capsule_closed = 'resources/objects/capsule_closed.png',
    }

    for asset_name, asset_path in pairs(assets) do fg.Loader.newImage(fg.Assets, asset_name, asset_path) end

    fg.Loader.start(function()
        self.finished_loading = true
        self:start()
    end)
end

return Game
