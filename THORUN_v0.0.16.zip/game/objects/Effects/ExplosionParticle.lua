local ExplosionParticle = fg.Class('ExplosionParticle', 'Entity')
ExplosionParticle:implement(fg.PhysicsBody)

ExplosionParticle.ignores = {'All', except = {'Solid'}}

function ExplosionParticle:new(area, x, y, settings)
    local settings = settings or {}
    ExplosionParticle.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    settings.w, settings.h = 4, 4
    self:physicsBodyNew(area, x, y, settings)
    self.body:setGravityScale(0.5)
    self.fixture:setRestitution(0.8)
    self.body:setLinearVelocity(self.v*math.cos(self.r), self.v*math.sin(self.r))

    local anim = self.fg.effects_animations['explosion_blast_2']
    self.w, self.h = anim.size[1], anim.size[2]
    self.animation = self.fg.Animation(self.fg.Assets[anim.image], anim.size[1], anim.size[2], self.fg.utils.math.random(anim.delay[1], anim.delay[2]))
    self.alpha = 255
    self.timer:after(self.animation.delay*(self.animation.size-1), function()
        self.timer:tween(self.animation.delay, self, {alpha = 0}, 'in-out-cubic')
        self.timer:after(self.animation.delay, function() self.dead = true end)
    end)
end

function ExplosionParticle:update(dt)
    self.timer:update(dt)
    self:physicsBodyUpdate(dt)
    self.r = self.fg.Vector(self.body:getLinearVelocity()):angle()
    self.animation:update(dt)
end

function ExplosionParticle:draw()
    self:physicsBodyDraw()
    love.graphics.setColor(255, 255, 255, self.alpha)
    self.animation:draw(self.x, self.y, self.r or 0, self.sx or 1, self.sy or 1, self.w/2, self.h/2)
    love.graphics.setColor(255, 255, 255, 255)
end

return ExplosionParticle
