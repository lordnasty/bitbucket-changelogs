local CapsuleTargetPosition = fg.Class('CapsuleTargetPosition', 'Entity')

function CapsuleTargetPosition:new(area, x, y, settings)
    local settings = settings or {}
    CapsuleTargetPosition.super.new(self, area, x, y, settings)
end

function CapsuleTargetPosition:update(dt)

end

function CapsuleTargetPosition:draw()

end

return CapsuleTargetPosition
