local Capsule = fg.Class('Capsule', 'Entity')
Capsule:implement(fg.PhysicsBody)
Capsule:implement(Steerable)

Capsule.ignores = {'Player'}

function Capsule:new(area, x, y, settings)
    local settings = settings or {}
    Capsule.super.new(self, area, x, y, settings)
    self:physicsBodyNew(area, x, y, {body_type = 'dynamic', shape = 'Rectangle', w = 48, h = 56})
    self.timer = self.fg.Timer()
    self.target_position = nil
    self.opened = false

    self.r = 0
    fg.world.camera:follow(self, {lerp = 2, lead = {x = 8, y = 8}})
    self:steerableNew({settings = {}})
    self.stable = self.fg.obv(false)
    self.last_position = {x = 0, y = 0}
    self.camera_lead = {x = 8, y = 8}

    local random = fg.utils.math.random
    self.timer:every('camera_lead_every', 0.9, function()
        self.timer:tween('camera_lead_tween', 0.6, self.camera_lead, {x = 8 + random(-0.25, 0.25), y = 8 + random(-0.25, 0.75)}, 'in-out-cubic', function()
            self.timer:tween('camera_lead_tween_2', 0.3, self.camera_lead, {x = 8, y = 8}, 'in-out-cubic')
        end)
    end)
end

function Capsule:update(dt)
    self.timer:update(dt)
    self:physicsBodyUpdate(dt)
    self:steerableUpdate(dt)
    local entities = self.area:getEntitiesWhere(function() return true end, {'CapsuleTargetPosition'})
    if #entities > 0 then self.target_position = entities[1] end
    if self.target_position then 
        local d = self.fg.Vector(self.x, self.y):dist(self.fg.Vector(self.last_position.x, self.last_position.y))
        if d <= 0.001 then self.stable:set(true) end
        -- Pre-land
        if self.stable+true then 
            self.arrive_deceleration = 2
            self:arriveOn(self.fg.Vector(self.target_position.x, self.target_position.y + 60)) 
            self.timer:after('capsule_open', 2, function()
                self.timer:cancel('camera_lead_every')
                self.opened = true
                self.area:createEntity('Player', self.x, self.y, {shape = 'BSGRectangle', w = 16, h = 28, s = 10})
            end)
        -- Flying
        elseif not self.stable.v then
            self.max_speed = 1000
            self.max_force = 10000
            self.arrive_deceleration = 5
            self:arriveOn(self.fg.Vector(self.target_position.x, self.target_position.y))
            self.r = self.velocity:angle() 
        end
    end

    if not self.stable.v then fg.world.camera:follow(self, {lerp = 2, lead = {x = self.camera_lead.x, y = self.camera_lead.y}}) end
    self.last_position = {x = self.x, y = self.y}
end

function Capsule:draw()
    self:physicsBodyDraw()
    if self.opened then
        love.graphics.draw(self.fg.Assets.capsule_opened, self.x, self.y, self.r, 1, 1, self.fg.Assets.capsule_closed:getWidth()/2, self.fg.Assets.capsule_closed:getHeight()/2)
    else love.graphics.draw(self.fg.Assets.capsule_closed, self.x, self.y, self.r, 1, 1, self.fg.Assets.capsule_closed:getWidth()/2, self.fg.Assets.capsule_closed:getHeight()/2) end
end

return Capsule
