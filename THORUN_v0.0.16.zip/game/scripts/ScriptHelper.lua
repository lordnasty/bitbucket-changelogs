local ScriptHelper = {}

ScriptHelper.getPlayer = function()
    if game.player then return game.player
    else 
        local entities = fg.world.areas[fg.current_area]:getEntitiesWhere(function() return true end, {'Player'})
        local player = entities[1]
        if player then return player
        else error("Player not found") end
    end
end

ScriptHelper.setSnowBackground = function(x1, y1, x2, y2, level_name)
    if level_name == 'StartArea' then
        local w = fg.Assets.snow_bg_water_1:getWidth()
        local n = math.ceil((x2-x1)/w) + 2
        for i = 1, n do 
            fg.world:addToLayer('BG_Mountain_3', fg.Background(x1 + (i-1)*w, y1 + 460, fg.Assets.snow_bg_mountain)) 
            fg.world:addToLayer('BG_Mountain_2', fg.Background(x1 + (i-1)*w, y1 + 530, fg.Assets.snow_bg_mountain)) 
            fg.world:addToLayer('BG_Mountain_1', fg.Background(x1 + (i-1)*w, y1 + 600, fg.Assets.snow_bg_mountain)) 
        end
        for i = 1, n do fg.world:addToLayer('BG_Water_1', fg.Background(x1 + (i-1)*w, y1 + 435, fg.Assets.snow_bg_water_1)) end
        local h = fg.Assets.snow_bg_water_1:getHeight()
        for i = 1, n do 
            fg.world:addToLayer('BG_Water_2', fg.Background(x1 + (i-1)*w, y1 + 420 - h/2, fg.Assets.snow_bg_water_2)) 
            fg.world:addToLayer('BG_Water_2', fg.Background(x1 + (i-1)*w, y1 + 420 - h/2 + fg.Assets.snow_bg_water_2:getHeight(), fg.Assets.snow_bg_water_2)) 
        end
        h = h + fg.Assets.snow_bg_water_2:getHeight()
        for i = 1, n do 
            fg.world:addToLayer('BG_Water_3', fg.Background(x1 + (i-1)*w, y1 + 420 - h/2, fg.Assets.snow_bg_water_3)) 
            fg.world:addToLayer('BG_Water_3', fg.Background(x1 + (i-1)*w, y1 + 420 - h/2 + fg.Assets.snow_bg_water_3:getHeight(), fg.Assets.snow_bg_water_3)) 
        end
        h = h + fg.Assets.snow_bg_water_3:getHeight()
        for i = 1, n do 
            fg.world:addToLayer('BG_Water_4', fg.Background(x1 + (i-1)*w, y1 + 420 - h/3, fg.Assets.snow_bg_water_4)) 
            fg.world:addToLayer('BG_Water_4', fg.Background(x1 + (i-1)*w, y1 + 420 - h/3 + fg.Assets.snow_bg_water_4:getHeight(), fg.Assets.snow_bg_water_4)) 
        end
        h = h + fg.Assets.snow_bg_water_4:getHeight()
        for i = 1, n do fg.world:addToLayer('BG_Trees_1', fg.Background(x1 + (i-1)*w, y1 + 420 - 7*h/6, fg.Assets.snow_bg_trees_1)) end
        for i = 1, n do fg.world:addToLayer('BG_Trees_2', fg.Background(x1 + (i-1)*w, y1 + 420 - 2*h, fg.Assets.snow_bg_trees_2)) end
        for i = 1, n do fg.world:addToLayer('BG_Trees_3', fg.Background(x1 + (i-1)*w, y1 + 420 - 5*h/2, fg.Assets.snow_bg_trees_3)) end
        for i = 1, n do fg.world:addToLayer('BG_Sky_1', fg.Background(x1 + (i-1)*w, y1 + 420 - 5.5*h/2, fg.Assets.snow_bg_sky_1)) end
        for i = 1, n do 
            local sh = fg.Assets.snow_bg_sky_2:getHeight()
            fg.world:addToLayer('BG_Sky_2', fg.Background(x1 + (i-1)*w, y1 + 420 - 4*h, fg.Assets.snow_bg_sky_2)) 
            fg.world:addToLayer('BG_Sky_2', fg.Background(x1 + (i-1)*w, y1 + 420 - 4*h + sh, fg.Assets.snow_bg_sky_2)) 
            for j = 1, 20 do 
                fg.world:addToLayer('BG_Sky_2', fg.Background(x1 + (i-1)*w, y1 + 420 - 4*h - j*sh, fg.Assets.snow_bg_sky_2)) 
                fg.world:addToLayer('BG_Sky_2', fg.Background(x1 + (i-1)*w - w, y1 + 420 - 4*h - j*sh, fg.Assets.snow_bg_sky_2)) 
            end
        end

        for i = 1, 300 do
            local sh = fg.Assets.snow_bg_sky_2:getHeight()
            local x, y = love.math.random(x1 - 600, x2 + 200), love.math.random(y1 - 4*h - 26*sh, y1)
            local layer = fg.utils.table.random({'BG_Sky_2', 'BG_Sky_1', 'BG_Trees_3', 'BG_Trees_2', 'BG_Trees_1'})
            local cloud = fg.utils.table.random({'snow_bg_clouds_1', 'snow_bg_clouds_2', 'snow_bg_clouds_3', 'snow_bg_clouds_4', 'snow_bg_clouds_5', 'snow_bg_clouds_6'})
            fg.world:addToLayer(layer, fg.Background(x, y, fg.Assets[cloud]))
        end
    end
end

ScriptHelper.getTilemapBorders = function(level_name)
    local x1, y1 = 10000, 10000
    local x2, y2 = -10000, -10000 
    for level_name, level in pairs(game.levels) do
        for layer, tilemap in pairs(level.tilemaps) do
            for i = 1, 100 do
                for j = 1, 100 do
                    if tilemap.tile_grid[i][j] ~= 0 then
                        local x, y = tilemap.x1 + (j-1)*tilemap.tile_width, tilemap.y1 + (i-1)*tilemap.tile_height
                        local x_, y_ = tilemap.x1 + j*tilemap.tile_width, tilemap.y1 + i*tilemap.tile_height
                        if x < x1 then x1 = x end
                        if y < y1 then y1 = y end
                        if x_ > x2 then x2 = x_ end
                        if y_ > y2 then y2 = y_ end
                    end
                end
            end
        end
    end
    return x1, y1, x2, y2
end

return ScriptHelper
