local StartArea = fg.Object:extend('StartArea')

function StartArea:new(data)
    if data then for k, v in pairs(data) do self[k] = v end end
end

function StartArea:update(dt)

end

function StartArea:init()
    -- local player = SH.getPlayer()
    local x1, y1, x2, y2 = SH.getTilemapBorders('StartArea')
    SH.setSnowBackground(x1, y1, x2, y2, 'StartArea')
end

return StartArea
