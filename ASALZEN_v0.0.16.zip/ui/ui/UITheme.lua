local Theme = {}

local makeStar = function(x, y, outer_radius, inner_radius)
    local vertices = {}
    for i = 1, 10 do
        local radius
        if i % 2 == 0 then radius = outer_radius else radius = inner_radius end
        table.insert(vertices, x + radius*math.cos(math.pi/2 + (i-1)*math.pi/5))
        table.insert(vertices, y + radius*math.sin(math.pi/2 + (i-1)*math.pi/5))
    end
    return vertices
end

Theme.Button = {}
Theme.Button.new = function(self)

end

Theme.Button.update = function(self, dt)

end

Theme.Button.draw = function(self)
    love.graphics.setColor(unpack(UI.colors.bg))
    fg.utils.graphics.roundedRectangle('fill', self.x, self.y, self.w, self.h, self.h/2, self.h/2)

    love.graphics.setColor(unpack(UI.colors.yellow))
    love.graphics.setFont(self.font)
    love.graphics.print(self.text, self.x + self.w - 35*fg.screen_scale - self.fs*self.font:getWidth(self.text), self.y + self.h/2, 0, self.fs, self.fs, 0, self.font:getHeight()/2)
    love.graphics.setColor(unpack(UI.colors.yellow))
    love.graphics.polygon('fill', unpack(makeStar(self.x + self.w - 18*fg.screen_scale, self.y + self.h/2, 10*fg.screen_scale, 5*fg.screen_scale)))
end

return Theme
