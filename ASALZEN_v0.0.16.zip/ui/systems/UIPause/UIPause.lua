local UIPause = fg.Object:extend('UIPause')
local UIButton = require 'ui/ui/UIButton'

function UIPause:UIPauseNew(settings)
    local settings = settings or {}
    fg.input:bind('escape', 'pause')
    fg.input:bind('start', 'pause')

    self.paused = false
    self.pausing = false

    self.right_bg_tweening = false
    self.right_bg = {x = 600*fg.screen_scale, y = 0, w = 500*fg.screen_scale, h = 375*fg.screen_scale}

    self.left_bg_tweening = false
    self.left_bg = {x = -450*fg.screen_scale, y = -50*fg.screen_scale, w = 375*fg.screen_scale, h = 600*fg.screen_scale}

    self.shadow_shader = love.graphics.newShader('resources/shaders/default.vert', 'resources/shaders/flat_colors.frag')
    self.portrait_s = {x = fg.screen_width, y = 0}

    self.status_b_tweening = false
    self.status_b = UIButton(-500*fg.screen_scale, 50*fg.screen_scale, 100*fg.screen_scale, 40*fg.screen_scale, {text = 'test button', font = fg.Fonts.helsinki})
end

function UIPause:UIPauseUpdate(dt)
    if fg.input:pressed('pause') and not self.pausing then
        if self.paused then self:unpause()
        elseif not self.paused then self:pause() end
    end

    self.status_b:update(dt)
    self.status_b.button.h = 40*fg.screen_scale

    if not self.status_b_tweening then
        if self.paused then self.status_b.button.x = -50*fg.screen_scale
        else self.status_b.button.x = -500*fg.screen_scale end
    end

    if not self.portrait_tweening then
        local sy = 1
        if self.portrait then sy = fg.screen_height/self.portrait:getHeight() end
        if self.paused then self.portrait_s = {x = fg.screen_width - 600*sy, y = 0}
        else self.portrait_s = {x = fg.screen_width, y = 0} end
    end

    if not self.left_bg_tweening then
        if self.paused then self.left_bg = {x = -100*fg.screen_scale, y = -50*fg.screen_scale, w = 375*fg.screen_scale, h = 600*fg.screen_scale}
        else self.left_bg = {x = -450*fg.screen_scale, y = -50*fg.screen_scale, w = 375*fg.screen_scale, h = 600*fg.screen_scale} end
    end

    if not self.right_bg_tweening then
        if self.paused then self.right_bg = {x = 150*fg.screen_scale, y = 0, w = 500*fg.screen_scale, h = 375*fg.screen_scale}
        else self.right_bg = {x = 600*fg.screen_scale, y = 0, w = 500*fg.screen_scale, h = 375*fg.screen_scale} end
    end
end

function UIPause:UIPauseDraw()
    if self.paused or self.pausing then
        love.graphics.setColor(unpack(UI.colors.orange))
        fg.utils.graphics.pushRotate(self.right_bg.x + self.right_bg.w/2, self.right_bg.y + self.right_bg.h/2, math.pi/4 + math.pi/12)
        love.graphics.rectangle("fill", self.right_bg.x, self.right_bg.y, self.right_bg.w, self.right_bg.h)
        love.graphics.pop()

        love.graphics.setColor(unpack(UI.colors.yellow))
        fg.utils.graphics.pushRotate(self.left_bg.x + self.left_bg.w/2, self.left_bg.y + self.left_bg.h/2, -math.pi/24)
        love.graphics.rectangle("fill", self.left_bg.x, self.left_bg.y, self.left_bg.w, self.left_bg.h)
        love.graphics.pop()

        local sy = fg.screen_height/self.portrait:getHeight()

        love.graphics.setShader(self.shadow_shader)
        love.graphics.setColor(unpack(UI.colors.yellow))
        love.graphics.draw(self.portrait, self.portrait_s.x, self.portrait_s.y, 0, 1.1*sy, 1.1*sy, 75, 75)
        love.graphics.setShader()

        love.graphics.setColor(255, 255, 255, 255)
        love.graphics.draw(self.portrait, self.portrait_s.x, self.portrait_s.y, 0, sy, sy)

        self.status_b:draw()
    end

    love.graphics.setColor(255, 255, 255, 255)
end

function UIPause:postAssetLoad()
    self.portrait = fg.Assets.sak0
    self.portrait:setFilter('linear', 'linear')
    self.portrait:setMipmapFilter('linear', 8)
end

function UIPause:pause()
    self.pausing = true

    self.right_bg_tweening = true
    self.timer:tween('right_bg_tween', 0.15, self.right_bg, {x = 150*fg.screen_scale}, 'in-out-cubic')

    self.timer:after(0.1, function()
        self.left_bg_tweening = true
        self.timer:tween('left_bg_tween', 0.15, self.left_bg, {x = -100*fg.screen_scale}, 'in-out-cubic') 

        self.timer:after(0.1, function()
            self.portrait_tweening = true
            local sy = fg.screen_height/self.portrait:getHeight()
            self.timer:tween('portrait_tween', 0.15, self.portrait_s, {x = fg.screen_width - 600*sy}, 'in-out-cubic')

            self.timer:after(0.1, function()
                self.status_b_tweening = true
                self.timer:tween('status_b_tween', 0.15, self.status_b.button, {x = -50*fg.screen_scale}, 'in-out-cubic', function()
                    self.status_b_tweening = false
                    self.right_bg_tweening = false
                    self.left_bg_tweening = false 
                    self.portrait_tweening = false
                    self.paused = true
                    self.pausing = false
                end)
            end)
        end)
    end)
end

function UIPause:unpause()
    self.pausing = true

    self.status_b_tweening = true
    self.timer:tween('status_b_tween', 0.15, self.status_b.button, {x = -500*fg.screen_scale}, 'in-out-cubic')

    self.timer:after(0.1, function()
        self.portrait_tweening = true
        self.timer:tween('portrait_tween', 0.15, self.portrait_s, {x = fg.screen_width}, 'in-out-cubic')

        self.timer:after(0.1, function()
            self.left_bg_tweening = true
            self.timer:tween('left_bg_tween', 0.15, self.left_bg, {x = -450*fg.screen_scale}, 'in-out-cubic')

            self.timer:after(0.1, function()
                self.right_bg_tweening = true
                self.timer:tween('right_bg_tween', 0.15, self.right_bg, {x = 600*fg.screen_scale}, 'in-out-cubic', function() 
                    self.status_b_tweening = false
                    self.portrait_tweening = false
                    self.left_bg_tweening = false 
                    self.right_bg_tweening = false 
                    self.paused = false
                    self.pausing = false
                end)
            end)
        end)
    end)
end

return UIPause
