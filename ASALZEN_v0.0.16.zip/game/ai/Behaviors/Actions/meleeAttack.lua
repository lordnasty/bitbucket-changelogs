local meleeAttack = Action:extend('meleeAttack')

function meleeAttack:new()
    meleeAttack.super.new(self, 'meleeAttack')
end

function meleeAttack:update(dt, context)
    return meleeAttack.super.update(self, dt, context)
end

function meleeAttack:run(dt, context)
    return 'success'
end

function meleeAttack:start(context)
    context.object:meleeAttack('single hit')
end

function meleeAttack:finish(status, context)
    context.object.vulnerable_target = nil
end

return meleeAttack
