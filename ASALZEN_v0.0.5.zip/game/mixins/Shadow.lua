local Shadow = fg.Object:extend('Shadow')

function Shadow:shadowDraw()
    love.graphics.setColor(255, 255, 255, 192)
    local height_scale = math.max(1 - self.z/100, 0.4)
    local shadow_width_scale = self.fg.utils.math.convertRange((self.shadow_width or 32), 
                                                               0, 32, 0, 1)
    local shadow_height_scale = self.fg.utils.math.convertRange((self.shadow_height or 32), 
                                                               0, 32, 0, 1)
    love.graphics.draw(self.fg.Assets.shadow, self.x, self.y, 0, 
                      (self.animation_flip or 1)*shadow_width_scale*height_scale, 
                       1*shadow_height_scale*height_scale,
                       self.fg.Assets.shadow:getWidth()/2, 
                       self.fg.Assets.shadow:getHeight() - height_scale*(self.shadow_offset or 8))
    love.graphics.setColor(255, 255, 255, 255)
end

return Shadow
