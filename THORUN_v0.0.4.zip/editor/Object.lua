local Object = fg.Object:extend('Object')
local EditorObject = require 'editor/EditorObject'

function Object:objectNew(settings)
    local settings = settings or {}
    self.object = nil
    self.objects = {}

    self.mp = fg.Vector(0, 0)
    self.mpl = fg.Vector(0, 0)
    self.mpd = fg.Vector(0, 0)
    self.ei:bind('lshift', 'lshift')
    self.ei:bind('lalt', 'lalt')

    self.objects_copy_buffer = {}
    self.object_pasting = false
    self.object_copying = false
    self.object_cutting = false
    self.paste_objects = {}

    self.polyrect_press_position = nil
    self.polyrect_final_position = nil

    self.polygon_press_positions = {}

    self.objects_state = {}
end

function Object:objectUpdate(dt)
    self.object = self.menu_current_object
    if self.object then self.object:update(dt) end
    for _, object in ipairs(self.objects) do object:update(dt) end
    self.mp = fg.Vector(love.mouse.getPosition())

    -- Snap to grid
    if self.ei:down('lshift') and not self.inside_properties_frame and not self.map_textinput_selected then
        local x, y = fg.world.camera:getWorldCoords(love.mouse.getPosition())
        self.mp.x, self.mp.y = (game.tile_width/2)*math.floor(x/(game.tile_width/2)), (game.tile_height/2)*math.floor(y/(game.tile_height/2)) 
        self.mp.x, self.mp.y = fg.world.camera:getCameraCoords(self.mp.x, self.mp.y)
    end

    self.mpd.x, self.mpd.y = self.mp.x - self.mpl.x, self.mp.y - self.mpl.y

    -- Spawn object on mouse click
    if self.ei:pressed('mouse1') and self.object and not self.inside_properties_frame and not self.map_textinput_selected then
        if self.object.type == 'Object' then
            self.object.active = true
            self.object.x, self.object.y = fg.world.camera:getWorldCoords(self.mp.x, self.mp.y)
            table.insert(self.objects, self.object)
            if not self.ei:down('lalt') then
                self.object = nil
                self.menu_current_object = nil
            else
                self.object = nil
                self.menu_current_object = nil
                fg.timer:after(0.01, function()
                    local x, y = love.mouse.getPosition()
                    self.menu_current_object = EditorObject(self, x, y, 
                                               {name = self.last_object.name, color = self.last_object.color, w = self.last_object.w, h = self.last_object.h,
                                                type = self.last_object.type, image = self.last_object.image, properties = self.last_object.properties})
                end)
            end
        elseif self.object.type == 'Polyrect' then
            if self.object.name == 'Script' or self.object.name == 'CameraLimit' then
                self.object.active = true
                local xi, yi = fg.world.camera:getWorldCoords(self.mp.x - game.tile_width/2, self.mp.y - game.tile_height/2)
                local xf, yf = fg.world.camera:getWorldCoords(self.mp.x + game.tile_width/2, self.mp.y + game.tile_height/2)
                self.object.x, self.object.y = (xi+xf)/2, (yi+yf)/2
                self.object.w, self.object.h = math.abs(xf-xi), math.abs(yf-yi)
                table.insert(self.objects, self.object)
                self.object = nil
                self.menu_current_object = nil
                self.polyrect_press_position = nil
                self.polyrect_final_position = nil
            else
                self.polyrect_press_position = {x = self.mp.x, y = self.mp.y}
            end

        elseif self.object.type == 'Polygon' then
            if #self.polygon_press_positions >= 2 then
                local n = #self.polygon_press_positions
                local first_x, first_y = self.polygon_press_positions[1], self.polygon_press_positions[2]
                local x, y = fg.world.camera:getWorldCoords(self.mp.x, self.mp.y)
                local d = fg.mlib.line.getDistance(x, y, first_x, first_y)
                if d >= 5 then
                    table.insert(self.polygon_press_positions, x)
                    table.insert(self.polygon_press_positions, y)
                else
                    if #self.polygon_press_positions >= 6 then
                        self.object.vertices = fg.utils.table.copy(self.polygon_press_positions)
                        self.object.active = true
                        local min_x, max_x, min_y, max_y = 10000, -10000, 10000, -10000
                        for i = 1, #self.polygon_press_positions, 2 do
                            local x, y = self.polygon_press_positions[i], self.polygon_press_positions[i+1]
                            if x < min_x then min_x = x end
                            if x > max_x then max_x = x end
                            if y < min_y then min_y = y end
                            if y > max_y then max_y = y end
                        end
                        self.object.x, self.object.y = (min_x+max_x)/2, (min_y+max_y)/2
                        self.object.w, self.object.h = math.abs(max_x-min_x), math.abs(max_y-min_y)
                        self.object.vertices = fg.fn.map(self.polygon_press_positions, function(i, v)
                            if i % 2 == 1 then return v - self.object.x
                            elseif i % 2 == 0 then return v - self.object.y end
                        end)
                        table.insert(self.objects, self.object)
                        self.polygon_press_positions = {}
                        self.object = nil
                        self.menu_current_object = nil
                    else
                        self.polygon_press_positions = {}
                        self.object = nil
                        self.menu_current_object = nil
                    end
                end
            else
                local x, y = fg.world.camera:getWorldCoords(self.mp.x, self.mp.y)
                table.insert(self.polygon_press_positions, x)
                table.insert(self.polygon_press_positions, y)
            end
        end
    end
    if self.ei:pressed('mouse1') then
        for i = #self.objects, 1, -1 do
            if self.objects[i].hot then self.objects[i].selected = true; break end
        end
    end
    if self.ei:down('mouse1') and self.object and self.polyrect_press_position and not self.inside_properties_frame and not self.map_textinput_selected then
        self.polyrect_final_position = {x = self.mp.x, y = self.mp.y}
    end
    if self.ei:released('mouse1') and self.object and self.polyrect_press_position and not self.inside_properties_frame and not self.map_textinput_selected then
        self.polyrect_final_position = {x = self.mp.x, y = self.mp.y}
        self.object.active = true
        local xi, yi = fg.world.camera:getWorldCoords(self.polyrect_press_position.x, self.polyrect_press_position.y)
        local xf, yf = fg.world.camera:getWorldCoords(self.polyrect_final_position.x, self.polyrect_final_position.y)
        self.object.x, self.object.y = (xi+xf)/2, (yi+yf)/2
        self.object.w, self.object.h = math.abs(xf-xi), math.abs(yf-yi)
        table.insert(self.objects, self.object)
        self.object = nil
        self.menu_current_object = nil
        self.polyrect_press_position = nil
        self.polyrect_final_position = nil
    end

    -- ESCAPE to cancel object placement
    if self.ei:pressed('escape') then
        self.object = nil
        self.menu_current_object = nil
        self.polygon_press_positions = {}
    end

    if not self.inside_properties_frame and not self.map_textinput_selected then
        -- Delete selected objects
        if self.ei:pressed('delete') then self:objectDelete() end

        -- Copy selected objects
        if self.ei:down('lctrl') and self.ei:pressed('copy') then self:objectCopy() end

        -- Cut selected objects
        if self.ei:down('lctrl') and self.ei:pressed('cut') then self:objectCut() end
        
        -- Pre-paste selected objects
        if self.ei:down('lctrl') and self.ei:pressed('paste') then self:objectPaste() end

        if self.object_pasting then
            if self.ei:pressed('mouse1') then
                local x, y = fg.world.camera:getWorldCoords(love.mouse.getPosition())
                for _, object in ipairs(self.paste_objects) do
                    if object.type == 'Object' then
                        local spx = (game.tile_width/2)*math.floor((x + object.paste_dx)/(game.tile_width/2))
                        local spy = (game.tile_height/2)*math.floor((y + object.paste_dy)/(game.tile_height/2))
                        table.insert(self.objects, EditorObject(self, spx, spy, {name = object.name, type = object.type, color = object.color,
                                     image = object.image, r = object.r, active = true, selected = true, properties = object.properties, 
                                     w = object.w, h = object.h}))
                    elseif object.type == 'Polyrect' then
                        local spx = (game.tile_width/2)*math.floor((x + object.paste_dx)/(game.tile_width/2)) + object.w/2
                        local spy = (game.tile_height/2)*math.floor((y + object.paste_dy)/(game.tile_height/2)) + object.h/2
                        table.insert(self.objects, EditorObject(self, spx, spy, {name = object.name, type = object.type, color = object.color,
                                     image = object.image, r = object.r, active = true, selected = true, properties = object.properties, 
                                     w = object.w, h = object.h}))
                    end
                end

                -- If was cutting then end cut+paste operation
                if self.object_cutting then
                    self.paste_objects = {}
                    self.object_copying = false
                    self.object_pasting = false
                    self.object_cutting = false
                end
            end

            -- Only way to get out of copy+paste operation
            if self.ei:pressed('escape') then
                self.paste_objects = {}
                self.object_pasting = false
                self.object_cutting = false
                self.object_copying = false
            end
        end
    end

    self.mpl.x, self.mpl.y = self.mp.x, self.mp.y

    if #self.objects_state > 0 then
        local pushed = {}
        pushed.objects = {}
        for _, object in ipairs(self.objects_state) do table.insert(pushed.objects, object) end
        self:pushToStack(pushed)
    end
    self.objects_state = {}

    -- Set inside properties frame flag
    self.inside_properties_frame = false
    for _, object in ipairs(self.objects) do
        local any_element_selected = false
        for _, element in ipairs(object.properties_frame.elements) do
            if element.selected then any_element_selected = true end
        end
        if (object.properties_frame.selected or any_element_selected) and not object.properties_frame.closed then
            self.inside_properties_frame = true 
        end
    end
end

function Object:objectDraw()
    if self.object then self.object:draw() end
    for _, object in ipairs(self.objects) do object:draw() end

    -- Draw selection rectangle
    if self.selection_start then
        love.graphics.setColor(128, 128, 128, 128)
        local x, y = love.mouse.getPosition()
        local x1, y1 = fg.world.camera:getCameraCoords(self.selection_start.x, self.selection_start.y)
        love.graphics.rectangle('line', x1, y1, x - x1, y - y1)
        love.graphics.setColor(128, 128, 128, 64)
        love.graphics.rectangle('fill', x1, y1, x - x1, y - y1)
        love.graphics.setColor(255, 255, 255, 255)
    end

    -- Draw polyrect rectangle
    if self.polyrect_press_position and self.polyrect_final_position and self.object then
        love.graphics.setColor(self.object.color[1], self.object.color[2], self.object.color[3], 128)
        local x1, y1 = self.polyrect_press_position.x, self.polyrect_press_position.y
        local x2, y2 = self.polyrect_final_position.x, self.polyrect_final_position.y
        love.graphics.rectangle('line', x1, y1, x2 - x1, y2 - y1)
        love.graphics.setColor(self.object.color[1], self.object.color[2], self.object.color[3], 64)
        love.graphics.rectangle('fill', x1, y1, x2 - x1, y2 - y1)
        love.graphics.setColor(255, 255, 255, 255)
    end

    -- Draw polygon
    if #self.polygon_press_positions > 0 and self.object then
        for i = 1, #self.polygon_press_positions, 2 do
            love.graphics.setLineStyle('rough')
            local x, y = fg.world.camera:getCameraCoords(self.polygon_press_positions[i], self.polygon_press_positions[i+1])
            love.graphics.setColor(self.object.color[1], self.object.color[2], self.object.color[3], 128)
            love.graphics.circle('fill', x, y, 5)
            love.graphics.setColor(self.object.color[1], self.object.color[2], self.object.color[3], 222)
            love.graphics.circle('line', x, y, 5)
            if i == #self.polygon_press_positions-1 then

            else

            end
        end
    end

    -- Draw pre-paste objects
    if self.object_pasting then
        for _, object in ipairs(self.paste_objects) do
            object:draw()
        end
    end
end

function Object:objectDelete()
    for i = #self.objects, 1, -1 do
        if self.objects[i].selected then 
            self:pushObjectState({object = {object = self.objects[i], id = self.objects[i].id}})
            table.remove(self.objects, i) 
        end
    end
end

function Object:objectCopy()
    self.object_copying = true
    self.objects_copy_buffer = {}
    for _, object in ipairs(self.objects) do
        if object.selected then
            table.insert(self.objects_copy_buffer, object)
        end
    end
end

function Object:objectCut()
    self.object_cutting = true
    self:objectCopy()
    self:objectDelete()
end

function Object:objectPaste()
    self.object_pasting = true
    for _, object in ipairs(self.objects) do
        if object.selected then
            object.selected = false
        end
    end
    local dx, dy = 0, 0
    for _, object in ipairs(self.objects_copy_buffer) do dx, dy = dx + object.x, dy + object.y end
    dx, dy = dx/#self.objects_copy_buffer, dy/#self.objects_copy_buffer
    for _, object in ipairs(self.objects_copy_buffer) do
        table.insert(self.paste_objects, EditorObject(self, object.x, object.y, {name = object.name, type = object.type, image = object.image, 
                     color = object.color, being_pasted = true, r = object.r, properties = object.properties, paste_dx = object.x - dx, 
                     paste_dy = object.y - dy, w = object.w, h = object.h}))
    end
    if self.object_cutting then self.objects_copy_buffer = {} end
end

function Object:cancelState()
    self.objects_copy_buffer = {}
    self.tiles_copy_buffer = {}
    self.paste_objects = {}
    self.object_pasting = false
    self.object_copying = false
    self.object_cutting = false
    self.pasting = false
    self.copying = false
    self.cutting = false
end

function Object:pushObjectState(state)
    table.insert(self.objects_state, state)
end

return Object
