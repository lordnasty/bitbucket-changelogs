local SnowBoulder = fg.Class('SnowBoulder', 'Entity')
SnowBoulder:implement(fg.PhysicsBody)

SnowBoulder.enter = {'Solid'}

function SnowBoulder:new(area, x, y, settings)
    local settings = settings or {}
    SnowBoulder.super.new(self, area, x, y, settings)
    settings.shape = 'circle'
    settings.r = 16
    self:physicsBodyNew(area, x, y, settings)
    self.body:setFixedRotation(false)
    self.fixture:setRestitution(0.2)
    
    self.snow_boulder_visual = self.fg.Assets.snow_boulder
    self.hp = 5
end

function SnowBoulder:update(dt)
    self:physicsBodyUpdate(dt)
    self.angle = self.body:getAngle()
end

function SnowBoulder:draw()
    love.graphics.draw(self.snow_boulder_visual, self.x, self.y, self.angle or 0, self.sx or 1, self.sy or 1, 16, 16)
    self:physicsBodyDraw()
end

function SnowBoulder:hitATK(attacker, attack_type)
    self.area.world.camera:shake(0.5, 0.2)
    self.hp = self.hp - 1
    for i = 1, 2 do self.area:createEntity('SnowRock', self.x, self.y, {size_id = self.fg.utils.table.random({'8L', '8R', '4L', '4R', '2L', '2R'})}) end
    if self.hp <= 0 then
        self.dead = true
        for i = 1, 2 do self.area:createEntity('SnowRock', self.x, self.y, {size_id = self.fg.utils.table.random({'16L1', '16R1'})}) end
    end
end

function SnowBoulder:onCollisionEnter(other, contact)
    if other.tag == 'Solid' then
        local vx, vy = self.body:getLinearVelocity()
        if vy > 250 then 
            self.dead = true 
            for i = 1, 2 do self.area:createEntity('SnowRock', self.x, self.y, {size_id = self.fg.utils.table.random({'16L1', '16R1'})}) end
        end
    end
end

function SnowBoulder:save()
    local save_data = {}
    save_data.angle = self.angle

    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y
    save_data.r = self.r
    save_data.shape = 'Circle'
    return save_data
end

return SnowBoulder
