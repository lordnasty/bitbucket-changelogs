local PersonHead = fg.Class('PersonHead', 'Entity')

PersonHead.dont_save = true

local hair_colors = {
    {251, 119, 119}, {255, 255, 255}, {119, 162, 251},
    {199, 122, 189}, {229, 142, 189}, {189, 142, 122},
    {189, 182, 122}, {199, 251, 122}, {162, 241, 122},
    {121, 122, 125}, {161, 162, 165}, {201, 202, 205},
    {211, 188, 129}, {241, 188, 119}, {251, 208, 119},
    {129, 188, 211}, {119, 149, 221}, {241, 128, 92},
    {241, 168, 241}, {241, 128, 241}, {201, 168, 241},
}

local head_offsets = {
    idle = {{0, 0}},
    run = {{0, -2}, {0, -1}, {0, 1}, {0, 0}, {0, -2}, {0, -1}, {0, 1}, {0, 0}},
    hit = {{-1, 1}},
    dash = {{5, 6}},
    low_dash = {{11, 13}},
    backdash = {{-4, 2}},
    block = {{-3, 4}},
    jump = {{0, 0}},
    fall = {{0, 0}},
    fall_down = {{0, 0}, {2, 5}, {2, 7}, {2, 6}, {2, 6}, {6, 9}, {9, 12}, {10, 15}, {14, 33}, {14, 32}, {14, 32}},
    down_idle = {{14, 33}},
    get_up = {{10, 32}, {10, 30}, {11, 27}, {11, 27}, {11, 26}, {11, 25}, {6, 7}, {4, 5}, {-1, -1}, {0, 0}},
    idle_combat = {{0, 1}},
    run_combat = {{0, -2}, {0, -1}, {0, 1}, {0, 0}, {0, -2}, {0, -1}, {0, 1}, {0, 0}},
    idle_punch_charge = {{0, 6}},
    run_punch_charge = {{0, 6}, {0, 5}, {0, 5}, {0, 6}, {0, 5}, {0, 5}},
    kick = {{-5, 5}, {-3, 4}, {-3, 4}, {-3, 4}, {-2, 3}},
    light_punch_left = {{0, 0}, {3, 0}, {3, 0}, {3, 0}, {0, 0}, {3, 0}, {3, 0}, {3, 0}},
    light_punch_right = {{0, 0}, {3, 0}, {3, 0}, {3, 0}, {0, 0}, {3, 0}, {3, 0}, {3, 0}},
    strong_punch_left = {{2, 2}, {0, 2}, {0, 3}, {0, 2}, {0, 2}, {1, 2}},
    strong_punch_right = {{1, 2}, {5, 3}, {6, 4}, {0, 2}, {0, 2}, {1, 2}},
    strong_punch_left_anticipation = {{-1, 1}, {-3, 4}, {-3, 5}, {-4, 6}, {2, 2}, {0, 2}, {0, 3}, {0, 3}, {0, 3}, {0, 3}, {0, 3}, {1, 2}},
    strong_punch_right_anticipation = {{-1, 1}, {-3, 4}, {-3, 5}, {-4, 6}, {1, 2}, {5, 3}, {6, 4}, {6, 4}, {6, 4}, {6, 4}, {6, 4}, {1, 2}},
    uppercut = {{1, 10}, {1, 10}, {1, 4}, {1, 4}, {1, 4}},
}

function PersonHead:new(area, x, y, settings)
    local settings = settings or {}
    PersonHead.super.new(self, area, x, y, settings)

    self.head = self.fg.Assets.male_head
    self.offset = {x = self.head:getWidth()/2, y = self.head:getHeight()/2 + 24}
    self.z = 0

    self.hair_color = settings.settings.hair_color or settings.hair_color or hair_colors[math.random(1, #hair_colors)]
    self.hair_index = settings.settings.hair_index or settings.hair_index or math.random(1, 7)
    self.mouth_index = settings.settings.mouth_index or settings.mouth_index or math.random(1, 8)
    self.eye_index = settings.settings.eye_index or settings.eye_index or math.random(1, 6)
    self.hit_eye_index = 7
    self.hit_mouth_index = 9
    self.vulnerable_mouth_index = 5
    self.normal_mouth_index = 3
    self.die_mouth_index = settings.settings.die_mouth_index or self.fg.utils.table.random({3, 7})
    self.hit_or_die_mouth = settings.settings.hit_or_die_mouth or self.fg.utils.table.random({'hit', 'die'})

    self.hairset = self.fg.Assets.male_hairset
    self.hairset_w, self.hairset_h = self.hairset:getWidth(), self.hairset:getHeight()
    self.eyes = self.fg.Assets.male_eyes
    self.eyes_w, self.eyes_h = self.eyes:getWidth(), self.eyes:getHeight()
    self.mouths = self.fg.Assets.male_mouths
    self.mouths_w, self.mouths_h = self.mouths:getWidth(), self.mouths:getHeight()

    self.hair = love.graphics.newQuad((self.hair_index-1)*64, 0, 64, 64, self.hairset_w, self.hairset_h)
    self.eye = love.graphics.newQuad((self.eye_index-1)*64, 0, 64, 64, self.eyes_w, self.eyes_h)
    self.mouth = love.graphics.newQuad((self.mouth_index-1)*64, 0, 64, 64, self.mouths_w, self.mouths_h)
    self.hit_eye = love.graphics.newQuad((self.hit_eye_index-1)*64, 0, 64, 64, self.eyes_w, self.eyes_h)
    self.hit_mouth = love.graphics.newQuad((self.hit_mouth_index-1)*64, 0, 64, 64, self.mouths_w, self.mouths_h)
    self.die_mouth = love.graphics.newQuad((self.die_mouth_index-1)*64, 0, 64, 64, self.mouths_w, self.mouths_h)
    self.vulnerable_mouth = love.graphics.newQuad((self.vulnerable_mouth_index-1)*64, 0, 64, 64, self.mouths_w, self.mouths_h)
    self.normal_mouth = love.graphics.newQuad((self.normal_mouth_index-1)*64, 0, 64, 64, self.mouths_w, self.mouths_h)

    self.eyes_opened_when_down = false
    self.mouth_closed_when_down = false
end

function PersonHead:update(dt)
    self.x, self.y, self.z = self.parent.x, self.parent.y + self.parent.head_y_offset, self.parent.z
end

function PersonHead:draw()
    local ox, oy = self.offset.x, self.offset.y
    local flip = self.parent.animation_flip
    local frame = self.parent.animations[self.parent.animation_state].animation.current_frame
    local hox, hoy = nil, nil
    local hox = head_offsets[self.parent.animation_state][frame][1]
    local hoy = head_offsets[self.parent.animation_state][frame][2]
    local sx, sy = self.parent.sx or 1, self.parent.sy or 1
    local angle = 0
    if self.parent.down_idle then angle = flip*math.pi/24 end
    local draw_data = {self.x, self.y, angle, flip*sx, 1*sy, ox - hox, oy - hoy + self.z}

    if self.parent.flash_hit then love.graphics.setShader(self.fg.Shaders.combine); love.graphics.setColor(180, 180, 180) end

    love.graphics.draw(self.head, unpack(draw_data))
    if self.parent.vulnerable_to_attack and not self.parent.hit then
        love.graphics.draw(self.fg.Assets.line_thingies, self.parent.x, self.parent.y, 0, flip*1, 1, 32, 58)
    end

    if self.parent.hit then
        if self.eye_index ~= 3 and self.eye_index ~= 5 then love.graphics.draw(self.eyes, self.hit_eye, unpack(draw_data)) 
        else love.graphics.draw(self.eyes, self.eye, unpack(draw_data)) end
        love.graphics.draw(self.mouths, self.hit_mouth, unpack(draw_data)) 
    elseif self.parent.down_idle or self.parent.fall_down then
        if self.eye_index ~= 3 and self.eye_index ~= 5 and not self.eyes_opened_when_down then love.graphics.draw(self.eyes, self.hit_eye, unpack(draw_data)) 
        else love.graphics.draw(self.eyes, self.eye, unpack(draw_data)) end
        if not self.mouth_closed_when_down then love.graphics.draw(self.mouths, self[self.hit_or_die_mouth .. '_mouth'], unpack(draw_data))
        else love.graphics.draw(self.mouths, self.hit_mouth, unpack(draw_data)) end
    elseif self.parent.vulnerable_to_attack then
        if self.eye_index ~= 3 and self.eye_index ~= 5 then love.graphics.draw(self.eyes, self.hit_eye, unpack(draw_data)) 
        else love.graphics.draw(self.eyes, self.eye, unpack(draw_data)) end
        love.graphics.draw(self.mouths, self.vulnerable_mouth, unpack(draw_data)) 
    else
        love.graphics.draw(self.eyes, self.eye, unpack(draw_data)) 
        love.graphics.draw(self.mouths, self.mouth, unpack(draw_data)) 
    end
    love.graphics.setColor(unpack(self.hair_color))
    love.graphics.draw(self.hairset, self.hair, unpack(draw_data))
    love.graphics.setShader()
    love.graphics.setColor(255, 255, 255, 255)
end

function PersonHead:highlightDraw()
    local ox, oy = self.offset.x, self.offset.y
    local flip = self.parent.animation_flip
    local frame = self.parent.animations[self.parent.animation_state].animation.current_frame
    local hox, hoy = nil, nil
    local hox = head_offsets[self.parent.animation_state][frame][1]
    local hoy = head_offsets[self.parent.animation_state][frame][2]
    local sx, sy = self.parent.sx or 1, self.parent.sy or 1
    local angle = 0
    if self.parent.down_idle then angle = flip*math.pi/24 end
    local draw_data = {self.x, self.y, angle, flip*sx, 1*sy, ox - hox, oy - hoy + self.z}

    love.graphics.draw(self.head, unpack(draw_data))
    if self.parent.vulnerable_to_attack and not self.parent.hit then
        love.graphics.draw(self.fg.Assets.line_thingies, self.parent.x, self.parent.y, 0, flip*1, 1, 32, 58)
    end

    if self.parent.hit then
        if self.eye_index ~= 3 and self.eye_index ~= 5 then love.graphics.draw(self.eyes, self.hit_eye, unpack(draw_data)) 
        else love.graphics.draw(self.eyes, self.eye, unpack(draw_data)) end
        love.graphics.draw(self.mouths, self.hit_mouth, unpack(draw_data)) 
    elseif self.parent.down_idle or self.parent.fall_down then
        if self.eye_index ~= 3 and self.eye_index ~= 5 then love.graphics.draw(self.eyes, self.hit_eye, unpack(draw_data)) 
        else love.graphics.draw(self.eyes, self.eye, unpack(draw_data)) end
        love.graphics.draw(self.mouths, self[self.hit_or_die_mouth .. '_mouth'], unpack(draw_data))
    elseif self.parent.vulnerable_to_attack then
        if self.eye_index ~= 3 and self.eye_index ~= 5 then love.graphics.draw(self.eyes, self.hit_eye, unpack(draw_data)) 
        else love.graphics.draw(self.eyes, self.eye, unpack(draw_data)) end
        love.graphics.draw(self.mouths, self.vulnerable_mouth, unpack(draw_data)) 
    else
        love.graphics.draw(self.eyes, self.eye, unpack(draw_data)) 
        love.graphics.draw(self.mouths, self.mouth, unpack(draw_data)) 
    end
    love.graphics.setColor(unpack(self.hair_color))
    love.graphics.draw(self.hairset, self.hair, unpack(draw_data))
    love.graphics.setColor(255, 255, 255, 255)
end

function PersonHead:preGetUp()
    self.eyes_opened_when_down = true
    self.mouth_closed_when_down = true
end

function PersonHead:postGetUp()
    self.eyes_opened_when_down = false
    self.mouth_closed_when_down = false
end

function PersonHead:changeMouth(mouth_index)
    self.mouth = love.graphics.newQuad((mouth_index-1)*64, 0, 64, 64, self.mouths_w, self.mouths_h)
end

function PersonHead:restoreMouth()
    self.mouth = love.graphics.newQuad((self.mouth_index-1)*64, 0, 64, 64, self.mouths_w, self.mouths_h)
end

function PersonHead:changeEyes(eye_index)
    self.eye = love.graphics.newQuad((eye_index-1)*64, 0, 64, 64, self.eyes_w, self.eyes_h)
end

function PersonHead:restoreEyes()
    self.eye = love.graphics.newQuad((self.eye_index-1)*64, 0, 64, 64, self.eyes_w, self.eyes_h)
end

function PersonHead:changeHairColor(hair_color_index)
    self.hair_color = hair_colors[hair_color_index]
end

function PersonHead:save()
    return {
        id = self.id, x = self.x, y = self.y,
        hair_color = self.hair_color, hair_index = self.hair_index, mouth_index = self.mouth_index,
        eye_index = self.eye_index, die_mouth_index = self.die_mouth_index, hit_or_die_mouth = self.hit_or_die_mouth,
    }
end

return PersonHead
