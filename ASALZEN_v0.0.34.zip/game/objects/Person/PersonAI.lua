local PersonAI = fg.Class('PersonAI', 'Entity')
PersonAI:implement(fg.PhysicsBody)
PersonAI:implement(Pseudo3D)
PersonAI:implement(Shadow)
PersonAI:implement(AI)
PersonAI:implement(Animated)
PersonAI:implement(Hittable)
PersonAI:implement(Steerable)
PersonAI:implement(StatsAI)

function PersonAI:new(area, x, y, settings)
    local settings = settings or {}
    PersonAI.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    self:physicsBodyNew(area, x, y, settings)
    self:pseudo3DNew({height_z = 50, settings = settings})

    self:steerableNew({settings = settings})
    self:animatedNew({animations = self.fg.person_animations, settings = settings})
    self.head = self.fg.world.areas[self.fg.current_area]:createEntityImmediate('PersonHead', self.x, self.y, {parent = self, settings = settings})
    self.hp_seq = self.fg.world.areas[self.fg.current_area]:createEntityImmediate('HPSequence', self.x, self.y, {parent = self, settings = settings})
    self:hittableNew({settings = settings})
    self:statsAINew({settings = settings})
    self:AINew({settings = settings})
end

function PersonAI:update(dt)
    self.timer:update(dt)
    self:physicsBodyUpdate(dt)
    self:pseudo3DUpdate(dt)

    self:steerableUpdate(dt)
    self:statsAIUpdate(dt)
    self:AIUpdate(dt)

    self:animatedUpdate(dt)
    self.head:update(dt)
end

function PersonAI:draw()
    self:shadowDraw()

    if self.animation_state == 'kick' or self.animation_state == 'block' then
        self.head:draw()
        love.graphics.setShader(self.enemy_type_coloring)
        self:animatedDraw()
        love.graphics.setShader()

    elseif self.animation_state == 'uppercut' then
        local frame = self.animations.uppercut.animation.current_frame
        if frame >= 3 then
            self.head:draw()
            love.graphics.setShader(self.enemy_type_coloring)
            self:animatedDraw()
            love.graphics.setShader()
        elseif frame < 3 then
            love.graphics.setShader(self.enemy_type_coloring)
            self:animatedDraw()
            love.graphics.setShader()
            self.head:draw()
        end

    else
        love.graphics.setShader(self.enemy_type_coloring)
        self:animatedDraw()
        love.graphics.setShader()
        self.head:draw()
    end

    self:AIDraw()
    self:physicsBodyDraw()
    self:pseudo3DDraw()
end

function PersonAI:highlightDraw()
    if self.animation_state == 'kick' then
        self.head:highlightDraw()
        self:animatedHighlightDraw()
    else
        self:animatedHighlightDraw()
        self.head:highlightDraw()
    end

    local animation = nil
    if self.animation_state == 'uppercut' then animation = self.animations.uppercut_front end
    if animation then animation.animation:draw(self.x, self.y, 0, self.animation_flip*(self.sx or 1), (self.y or 1), -animation.x_offset, self.z - animation.y_offset) end
end

function PersonAI:save()
    local pseudo_3d = self:pseudo3DSave()
    local hittable = self:hittableSave()
    local animated = self:animatedSave()
    local steerable = self:steerableSave()
    local stats_ai = self:statsAISave()
    local head = self.head:save()
    local hp_seq = self.hp_seq:save()
    local save_data = {}
    for k, v in pairs(pseudo_3d) do save_data[k] = v end
    for k, v in pairs(hittable) do save_data[k] = v end
    for k, v in pairs(animated) do save_data[k] = v end
    for k, v in pairs(steerable) do save_data[k] = v end
    -- for k, v in pairs(stats_ai) do save_data[k] = v end
    for k, v in pairs(head) do save_data[k] = v end
    for k, v in pairs(hp_seq) do save_data[k] = v end
    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y
    save_data.w, save_data.h = self.w, self.h
    save_data.shape = 'BSGRectangle'
    save_data.s = self.s
    return save_data
end

return PersonAI
