local Dodge = fg.Object:extend('Dodge')

function Dodge:new(settings)
    local settings = settings or {}
    for k, v in pairs(settings) do self[k] = v end
    self.type = 'Dodge'
    self.dodge_cooldown = 0.6
    self.can_dodge = true
end

function Dodge:update(dt)

end

function Dodge:pressed()
    if not self.can_dodge then return end
    self.can_dodge = false
    self.parent.timer:after('Dodge_cooldown', self.dodge_cooldown, function() self.can_dodge = true end)

    local fx, fy = 0
    if fg.input:down('moveLeft') then fx = -350 end
    if fg.input:down('moveRight') then fx = 350 end
    if fg.input:down('moveUp') then fy = -200 end
    if fg.input:down('moveDown') then fy = 200 end
    local gpx, gpy = fg.input:down('moveHorizontal'), fg.input:down('moveVertical')
    if math.abs(gpx or 0) > 0.1 or math.abs(gpy or 0) > 0.1 then fx = 350*gpx; fy = 200*gpy end

    self.parent.dodge = true
    self.parent:push(fx, fy, 0.15)
    self.parent.v_z = -40
    
    self.parent:changeCollisionClass('main', 'PlayerIgnoresNPC')
    -- Set dash, add condition for when an enemy is targetted so you backdash instead
    self.parent:setAnimationState('dash')
    self.parent.timer:after('Dodge_undash', 0.4, function() 
        self.parent.dodge = false
        self.parent.dash = false 
        self.parent:changeCollisionClass('main', 'Person')
    end)
    
end

function Dodge:down()

end

function Dodge:released()

end

return Dodge
