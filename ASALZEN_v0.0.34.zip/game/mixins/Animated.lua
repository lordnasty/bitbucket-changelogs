local Animated = fg.Object:extend('Animated')

function Animated:animatedNew(settings)
    local settings = settings or {}

    self.animation_state = settings.settings.animation_state or 'idle'
    self.animation_flip = settings.settings.animation_flip or 1
    self.animations = {}
    for _, anim in ipairs(settings.animations) do
        self.animations[anim.state] = {animation = fg.Animation(self.fg.Assets[anim.image], anim.size[1], anim.size[2], anim.delay), x_offset = anim.offset[1] or 0, y_offset = anim.offset[2] or 0}
        self.animations[anim.state].animation:setMode(anim.mode)
    end

    self.head_y_offset = 0
end

function Animated:animatedUpdate(dt)
    self.animations[self.animation_state].animation:update(dt)
    if self.direction == 'left' then self.animation_flip = -1
    elseif self.direction == 'right' then  self.animation_flip = 1 end

    local vx, vy = self.body:getLinearVelocity()
    if math.abs(vx) <= 5 and math.abs(vy) <= 5 then self.animation_state = 'idle' end
    if math.abs(vx) >= 5 or math.abs(vy) >= 5 then self.animation_state = 'run' end
    if self.v_z < 0 then self.animation_state = 'jump' end
    if self.v_z >= 1 then self.animation_state = 'fall' end
    if self.melee_attack_locked and (math.abs(vx) <= 5 and math.abs(vy) <= 5) then self.animation_state = 'idle_combat' end
    if self.melee_attack_locked and (math.abs(vx) >= 5 or math.abs(vy) >= 5) then self.animation_state = 'run_combat' end
    if self.agroed and (math.abs(vx) <= 5 and math.abs(vy) <= 5) then self.animation_state = 'idle_combat' end
    if self.agroed and (math.abs(vx) >= 5 or math.abs(vy) >= 5) then self.animation_state = 'run_combat' end
    if self.punch_charge and (math.abs(vx) <= 5 and math.abs(vy) <= 5) then self.animation_state = 'idle_punch_charge' end
    if self.punch_charge and (math.abs(vx) >= 5 or math.abs(vy) >= 5) then self.animation_state = 'run_punch_charge' end
    if self.dash then self.animation_state = 'dash' end
    if self.kick then self.animation_state = 'kick' end
    if self.low_dash then self.animation_state = 'low_dash' end
    if self.backdash then self.animation_state = 'backdash' end
    if self.block then 
        self.animation_state = 'block' 
        self.head_y_offset = -0.01
    end
    if self.light_punch_left then self.animation_state = 'light_punch_left' end
    if self.light_punch_right then self.animation_state = 'light_punch_right' end
    if self.strong_punch_left then 
        self.animation_state = 'strong_punch_left' 
        self.animations.strong_punch_left_arm.animation:seek(self.animations.strong_punch_left.animation.current_frame)
    end
    if self.strong_punch_right then 
        self.animation_state = 'strong_punch_right' 
        self.animations.strong_punch_right_arm.animation:seek(self.animations.strong_punch_right.animation.current_frame)
    end
    if self.strong_punch_left_anticipation then
        self.animation_state = 'strong_punch_left_anticipation' 
        self.animations.strong_punch_left_anticipation_arm.animation:seek(self.animations.strong_punch_left_anticipation.animation.current_frame)
    end
    if self.strong_punch_right_anticipation then
        self.animation_state = 'strong_punch_right_anticipation' 
        self.animations.strong_punch_right_anticipation_arm.animation:seek(self.animations.strong_punch_right_anticipation.animation.current_frame)
    end
    if self.uppercut then
        self.animation_state = 'uppercut'
        self.animations.uppercut_front.animation:seek(self.animations.uppercut.animation.current_frame)
        if self.animations.uppercut.animation.current_frame <= 2 then self.head_y_offset = 0.01
        else self.head_y_offset = -0.01 end
    end
    if self.hit then self.animation_state = 'hit' end
    if self.fall_down then self.animation_state = 'fall_down' end
    if self.down_idle then self.animation_state = 'down_idle' end
    if self.get_up then self.animation_state = 'get_up' end
    if self.stage_decreasing then 
        self.animation_state = 'get_up' 
        self.animations.get_up.animation:seek(4)
    end
end

function Animated:animatedDraw()
    if self.flash_hit then love.graphics.setShader(self.fg.Shaders.combine); love.graphics.setColor(180, 180, 180) end
    local animation = self.animations[self.animation_state]
    animation.animation:draw(self.x, self.y, 0, self.animation_flip*(self.sx or 1), (self.sy or 1), -animation.x_offset, self.z - animation.y_offset)
    love.graphics.setColor(255, 255, 255, 255)
end

function Animated:animatedHighlightDraw()
    local animation = self.animations[self.animation_state]
    animation.animation:draw(self.x, self.y, 0, self.animation_flip*(self.sx or 1), (self.sy or 1), -animation.x_offset, self.z - animation.y_offset)
end

function Animated:setAnimationState(state)
    for k, v in pairs(self.animations) do self[k] = false end
    if state then self[state] = true end
end

function Animated:setAnimationDelay(animation_name, delay)
    local animation = self.animations[animation_name].animation
    animation.delay = delay
    for i = 1, animation.size do animation:setDelay(i, delay) end
end

function Animated:playAnimation(animation_name, action)
    self:setAnimationState(animation_name)
    local animation = self.animations[animation_name].animation
    animation:reset()
    animation:play()
    self.timer:after(animation_name, animation.delay*animation.size, function()
        animation:reset()
        self[animation_name] = false
        if action then action() end
    end)
end

function Animated:playAnimationDelayLastFrame(animation_name, delay, action)
    self:setAnimationState(animation_name)
    local animation = self.animations[animation_name].animation
    animation:setMode('once')
    animation:reset()
    animation:play()
    self.timer:after(animation_name, animation.delay*animation.size + delay, function()
        animation:setMode('loop')
        animation:reset()
        self[animation_name] = false
        if action then action() end
    end)
end

function Animated:playAnimationFromFrame(animation_name, frame, action)
    self:setAnimationState(animation_name)
    local animation = self.animations[animation_name].animation
    animation:reset()
    animation:seek(frame)
    animation:play()
    self.timer:after(animation_name, animation.delay*(animation.size-frame), function()
        animation:reset()
        self[animation_name] = false
        if action then action() end
    end)
end

function Animated:playAnim(animation_name, frame_actions)
    self:setAnimationState(animation_name)
    local animation = self.animations[animation_name].animation
    animation:reset()
    animation:play()
    for _, frame_action in ipairs(frame_actions) do
        local frame, action = frame_action[1], frame_action[2]
        if frame == 0 then frame = animation.size end
        self.timer:after(animation_name .. '_' .. frame, animation.delay*frame, function() if action then action() end end)
    end
    self.timer:after(animation_name, animation.delay*animation.size, function()
        animation:reset()
        self[animation_name] = false
    end)
end

-- Move to some Effect mixin or something later
function Animated:ATKjuice()
    self.sx, self.sy = self.fg.utils.math.random(1.02, 1.1), self.fg.utils.math.random(1.02, 1.1)
    local r = self.fg.utils.math.random(0.1, 0.6)
    self.timer:tween('hit_scale_tween', r, self, {sx = 1, sy = 1}, 'in-out-cubic')
    self.timer:after('hit_scale_after', r, function() self.sx = 1; self.sy = 1 end)
end

function Animated:animatedSave()
    return {animation_state = self.animation_state, animation_flip = self.animation_flip}
end

return Animated
