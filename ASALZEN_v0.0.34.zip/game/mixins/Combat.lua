local Combat = fg.Object:extend('Combat')

function Combat:combatNew(settings)
    local settings = settings or {}

    if self.class_name == 'NPC' then
        self.fleft = self.fg.obv(settings.settings.fleft)
        self.fright = self.fg.obv(settings.settings.fright)
        self.fup = self.fg.obv(settings.settings.fup)
        self.fdown = self.fg.obv(settings.settings.fdown)
        self.right_attack = self.fg.obv(settings.settings.right_attack)
        self.left_attack = self.fg.obv(settings.settings.left_attack)
    end

    self.combat_actions = {
        Empty = Empty(), 
        LightAttack1 = LightAttack1({parent = self}),
        Dodge = Dodge({parent = self}),
    }

    self.fleft_action = self.combat_actions[settings.settings.fleft_action or 'Empty']
    self.fright_action = self.combat_actions[settings.settings.fright_action or 'Empty']
    self.fup_action = self.combat_actions[settings.settings.fup_action or 'Empty']
    self.fdown_action = self.combat_actions[settings.settings.fdown_action or 'Empty']
    self.right_attack_action = self.combat_actions[settings.settings.right_attack_action or 'Empty']
    self.left_attack_action = self.combat_actions[settings.settings.left_attack_action or 'Empty']
end

function Combat:combatUpdate(dt)
    local fleft_pressed, fright_pressed, fup_pressed, fdown_pressed, right_attack_pressed, left_attack_pressed,
          fleft_down, fright_down, fup_down, fdown_down, right_attack_down, left_attack_down,
          fleft_released, fright_released, fup_released, fdown_released, right_attack_released, left_attack_released = self:handleCombatInputs()

    if self:actionActive(self.fleft_action) then
        if fleft_pressed then self.fleft_action:pressed() end
        if fleft_down then self.fleft_action:down() end
        if fleft_released then self.fleft_action:released() end
    end
    
    if self:actionActive(self.fup_action) then
        if fup_pressed then self.fup_action:pressed() end
        if fup_down then self.fup_action:down() end
        if fup_released then self.fup_action:released() end
    end

    if self:actionActive(self.fdown_action) then
        if fdown_pressed then self.fdown_action:pressed() end
        if fdown_down then self.fdown_action:down() end
        if fdown_released then self.fdown_action:released() end
    end

    if self:actionActive(self.fright_action) then
        if fright_pressed then self.fright_action:pressed() end
        if fright_down then self.fright_action:down() end
        if fright_released then self.fright_action:released() end
    end

    if self:actionActive(self.left_attack_action) then
        if left_attack_pressed then self.left_attack_action:pressed() end
        if left_attack_down then self.left_attack_action:down() end
        if left_attack_released then self.left_attack_action:released() end
    end

    if self:actionActive(self.right_attack_action) then
        if right_attack_pressed then self.right_attack_action:pressed() end
        if right_attack_down then self.right_attack_action:down() end
        if right_attack_released then self.right_attack_action:released() end
    end

    self.fleft_action:update(dt)
    self.fright_action:update(dt)
    self.fup_action:update(dt)
    self.fdown_action:update(dt)
    self.right_attack_action:update(dt)
    self.left_attack_action:update(dt)
end

function Combat:combatDraw()

end

function Combat:bindAttack(action, attack)
    self[action .. '_action'] = self.combat_actions[attack]
end

function Combat:interruptAttack()
    
end

function Combat:interruptSkill()
    
end

function Combat:interruptKnockback()
    
end

function Combat:actionActive(action)
    if (action.type == 'Attack' or action.type == 'Skill') and not self.knockdback then return true end
    if action.type == 'Dodge' then return true end
end

function Combat:handleCombatInputs()
    local fleft_pressed, fright_pressed, fup_pressed, fdown_pressed, right_attack_pressed, left_attack_pressed = nil, nil, nil, nil, nil, nil
    local fleft_down, fright_down, fup_down, fdown_down, right_attack_down, left_attack_down = nil, nil, nil, nil, nil, nil
    local fleft_released, fright_released, fup_released, fdown_released, right_attack_released, left_attack_released = nil, nil, nil, nil, nil, nil

    if self.class_name == 'Player' then
        fleft_pressed = self.fg.input:pressed('fleft')
        fup_pressed = self.fg.input:pressed('fup')
        fright_pressed = self.fg.input:pressed('fright')
        fdown_pressed = self.fg.input:pressed('fdown')
        right_attack_pressed = self.fg.input:pressed('rightAttack')
        left_attack_pressed = self.fg.input:pressed('leftAttack')
        right_select_pressed = self.fg.input:pressed('rightSelect')
        left_select_pressed = self.fg.input:pressed('leftSelect')
        fleft_down = self.fg.input:down('fleft')
        fup_down = self.fg.input:down('fup')
        fright_down = self.fg.input:down('fright')
        fdown_down = self.fg.input:down('fdown')
        right_attack_down = self.fg.input:down('rightAttack')
        left_attack_down = self.fg.input:down('leftAttack')
        right_select_down = self.fg.input:down('rightSelect')
        left_select_down = self.fg.input:down('leftSelect')
        fleft_released = self.fg.input:released('fleft')
        fup_released = self.fg.input:released('fup')
        fright_released = self.fg.input:released('fright')
        fdown_released = self.fg.input:released('fdown')
        right_attack_released = self.fg.input:released('rightAttack')
        left_attack_released = self.fg.input:released('leftAttack')
        right_select_released = self.fg.input:released('rightSelect')
        left_select_released = self.fg.input:released('leftSelect')

    elseif self.class_name == 'NPC' then
        fleft_pressed = self.fleft:enter(true)
        fup_pressed = self.fup:enter(true)
        fright_pressed = self.fright:enter(true)
        fdown_pressed = self.fdown:enter(true)
        right_attack_pressed = self.right_attack:enter(true)
        left_attack_pressed = self.left_attack:enter(true)
        fleft_down = self.fleft.v
        fup_down = self.fup.v
        fright_down = self.fright.v
        fdown_down = self.fdown.v
        right_attack_down = self.right_attack.v
        left_attack_down = self.left_attack.v
        fleft_released = self.fleft:exit(true)
        fup_released = self.fup:exit(true)
        fright_released = self.fright:exit(true)
        fdown_released = self.fdown:exit(true)
        right_attack_released = self.right_attack:exit(true)
        left_attack_released = self.left_attack:exit(true)
    end

    return fleft_pressed, fright_pressed, fup_pressed, fdown_pressed, right_attack_pressed, left_attack_pressed,
           fleft_down, fright_down, fup_down, fdown_down, right_attack_down, left_attack_down,
           fleft_released, fright_released, fup_released, fdown_released, right_attack_released, left_attack_released
end

function Combat:combatSave()
    local fleft, fright, fup, fdown, right_attack, left_attack = nil, nil, nil, nil, nil, nil
    if self.class_name == 'NPC' then
        fleft = self.fleft.v
        fright = self.fright.v
        fup = self.fup.v
        fdown = self.fdown.v
        right_attack = self.right_attack.v
        left_attack = self.left_attack.v
    end

    return {
        fleft_action = self.fleft_action.class_name, fright_action = self.fright_action.class_name, fup_action = self.fup_action.class_name, fdown_action = self.fdown_action.class_name,
        right_attack_action = self.right_attack_action.class_name, left_attack_action = self.left_attack_action.class_name, fleft = fleft, fright = fright, fdown = fdown, fup = fup,
        left_attack = left_attack, right_attack = right_attack,
    }
end

return Combat
