local Stats = fg.Object:extend('Stats')

function Stats:statsNew(settings)
    local settings = settings or {}

    -- Status
    self.knockdback = settings.settings.knockdback
    self.dodge = settings.settings.dodg

    -- Stats
    self.max_hp = settings.settings.max_hp or 30
    self.current_hp = settings.settings.current_hp or self.max_hp
    self.damage = settings.settings.damage or 10
end

function Stats:statsUpdate(dt)

end

function Stats:statsDraw()

end

function Stats:statsSave()
    return {
        damage = self.damage, current_hp = self.current_hp, max_hp = self.max_hp, 
        knockdback = self.knockdback, dodge = self.dodge,
    }
end

return Stats
