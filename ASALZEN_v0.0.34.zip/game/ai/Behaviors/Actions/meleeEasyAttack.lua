local meleeEasyAttack = Action:extend('meleeEasyAttack')

function meleeEasyAttack:new()
    meleeEasyAttack.super.new(self, 'meleeEasyAttack')

    self.done = false
end

function meleeEasyAttack:update(dt, context)
    return meleeEasyAttack.super.update(self, dt, context)
end

function meleeEasyAttack:run(dt, context)
    if self.done then return 'success'
    else return 'running' end
end

function meleeEasyAttack:start(context)
    self.punch_charge = false
    if not context.object.agroed or context.object.dying or context.object.stage_decreasing or context.object.attacker or context.object.engaged_in_single_combat or 
       context.any_around_entity.melee_attack_hit_locked then 
        self.done = true
        return
    end
    self.done = false
    local angle = self.fg.Vector(context.any_around_entity.body:getPosition()):angleTo(self.fg.Vector(context.object.body:getPosition()))
    context.object.direction = self.fg.utils.angleToDirection2(self.fg.Vector(context.any_around_entity.body:getPosition()):angleTo(self.fg.Vector(context.object.body:getPosition())))
    context.object:steerablePush(200*math.cos(angle), 200*math.sin(angle))
    context.object.blocking_all_incoming_attacks = false
    context.object:playAnimationDelayLastFrame('uppercut', 1, function() 
        self.done = true 
        context.object.blocking_all_incoming_attacks = true
    end)
    local animation = context.object.animations.uppercut.animation
    context.object.timer:after('melee_area_attack', animation.delay*2, function()
        local dx = context.any_around_entity.x - context.object.x
        if dx < 0 then dx = -1 else dx = 1 end
        context.object.area:createEntity('MeleeArea', context.object.x + 16*dx, context.object.y, {parent = context.object})
    end)
end

function meleeEasyAttack:finish(status, context)
    context.any_around_entity = nil
end

return meleeEasyAttack
