 local EditorObject = require 'editor/EditorObject'
 local Level = fg.Object:extend('Level')

function Level:new(game, name, x, y)
    self.game = game
    self.name = name
    fg.world:createArea(name, x or 0, y or 0)

    local tilesets = {}
    for _, tileset in ipairs(self.game.tilesets) do table.insert(tilesets, love.graphics.newImage('resources/tilesets/' .. tileset .. '.png')) end
    local grid = {} for i = 1, 100 do grid[i] = {} for j = 1, 100 do grid[i][j] = 0 end end
    self.tilemaps = {}
    for _, layer in ipairs(self.game.layers) do
        self.tilemaps[layer] = fg.Tilemap(0, 0, self.game.tile_width, self.game.tile_height, tilesets, grid, {area = fg.world.areas[self.name]})
        fg.world:addToLayer(layer, self.tilemaps[layer])
    end
    self.last_loaded_map = nil
    self.last_editor_loaded_map = nil
end

function Level:update(dt)

end

function Level:draw()

end

function Level:activate()
    fg.world.areas[self.name]:activate()
end

function Level:deactivate()
    fg.world.areas[self.name]:deactivate()
end

function Level:handleLinks(source, target)
    if (source.class_name == 'Door' or source.class_name == 'LevelTransition') and target.class_name == 'TransPlayerPos' then
        target.linked_object_target_level = source.target_level
    end
end

function Level:movePlayerToTPP(previous_area)
    if not previous_area then return end
    -- Move player to correct position
    local player = nil
    local players = fg.world.areas[self.name]:getEntitiesWhere(function() return true end, {'Player'})
    if #players > 0 then player = players[1] end
    local tpps = fg.world.areas[fg.current_area]:getEntitiesBy('linked_object_target_level', previous_area, {'TransPlayerPos'})
    local tpp = nil
    if #tpps > 0 then tpp = tpps[1] end
    if player and tpp then 
        player.body:setPosition(tpp.x, tpp.y) 
        player.head.x, player.head.y = tpp.x, tpp.y
    end
    if tpp then fg.world.camera:moveTo(tpp.x, tpp.y) end
end

function Level:loadScriptsPost()
    -- Load scripts after everything else has been loaded
    local scripts = fg.world.areas[self.name]:getEntitiesWhere(function() return true end, {'Script'})
    for _, script in ipairs(scripts) do script:initPost() end
end

function Level:postLoad()
    -- Load scripts normally
    local scripts = fg.world.areas[self.name]:getEntitiesWhere(function() return true end, {'Script'})
    for _, script in ipairs(scripts) do script:init() end

    -- Set camera limits
    local camera_limits = fg.world.areas[self.name]:getEntitiesWhere(function() return true end, {'CameraLimit'})
    local left_top_x, left_top_y, bottom_right_x, bottom_right_y = nil, nil, nil, nil
    for _, cl in ipairs(camera_limits) do
        if cl.position == 'top-left' then left_top_x, left_top_y = cl.x, cl.y
        elseif cl.position == 'bottom-right' then bottom_right_x, bottom_right_y = cl.x, cl.y end
    end
    if left_top_x and left_top_y and bottom_right_x and bottom_right_y then 
        fg.world.camera:setBounds(left_top_x, left_top_y, bottom_right_x, bottom_right_y) 
    end
end

function Level:changeLevelTo(map_name, delay)
    local transitions = {'rectangle', 'rotating rectangle', 'rectangle lr'}
    local transition = transitions[math.random(1, #transitions)]
    game:screenTransition(transition .. ' up', delay)
    fg.world:pause()
    fg.timer:after('transition_up', delay, function()
        game:changeLevelTo(map_name)
        game:screenTransition(transition .. ' down', delay)
        fg.timer:after('transition_down', delay, function()
            game.screen_transition = nil
            fg.world:unpause()
        end)
    end)
end

function Level:saveFromGame(filename)
    -- Saves tilemaps
    local save_data = {}
    for _, l in ipairs(game.layers) do
        local tilemap = self.tilemaps[l]
        save_data[l] = {}
        save_data[l].tile_grid = fg.utils.table.copy(tilemap.tile_grid)
    end

    -- Saves objects
    save_data.objects = fg.Serial:saveArea(filename, fg.world.areas[self.name], nil, true)
    
    -- Save
    local save_string = fg.Serial.serialize(save_data)
    if not love.filesystem.write('maps/' .. filename, save_string) then
        error('Could not write ' .. filename .. ' while saving area ' .. self.name .. '.')
    end
end

function Level:saveFromEditor(additional_data, map_name)
    -- Saves tilemaps
    local save_data = {}
    for _, l in ipairs(game.layers) do
        local tilemap = self.tilemaps[l]
        save_data[l] = {}
        save_data[l].tile_grid = fg.utils.table.copy(tilemap.tile_grid)
    end

    -- Saves objects
    save_data.objects = {}
    for _, object in ipairs(additional_data) do
        table.insert(save_data.objects, object)
    end

    -- Save
    local save_string = fg.Serial.serialize(save_data)
    local file = nil
    if forwardslash then file = assert(io.open(cwd .. '/resources/maps/' .. map_name, 'w'))
    elseif backslash then file = assert(io.open(cwd .. '\\resources\\maps\\' .. map_name, 'w')) end
    file:write(save_string)
    file:close()

    self.last_editor_loaded_map = map_name
end

function Level:loadFromGame(map_name, previous_map)
    local save_data = love.filesystem.load('maps/' .. map_name)()
    local save_data_previous = nil
    if previous_map then save_data_previous = love.filesystem.load('maps/' .. previous_map)() end
    
    -- Loads tilemaps
    for _, l in ipairs(game.layers) do
        local tilemap = self.tilemaps[l]
        for i = 1, #save_data[l].tile_grid do
            for j = 1, #save_data[l].tile_grid[i] do
                tilemap:removeTile(i, j)
            end
        end
        for i = 1, #save_data[l].tile_grid do
            for j = 1, #save_data[l].tile_grid[i] do
                tilemap:changeTile(i, j, save_data[l].tile_grid[i][j])
            end
        end
    end
    
    -- Load objects
    for _, object in ipairs(save_data.objects) do
        local settings = {}
        for k, v in pairs(object) do settings[k] = v end
        if object.class_name ~= 'Player' and object.class_name ~= 'Script' then
            fg.world.areas[self.name]:createEntity(object.class_name, object.x, object.y, settings)
        end
    end

    -- Load player
    if save_data_previous then  
        for _, object in ipairs(save_data_previous.objects) do
            local settings = {}
            for k, v in pairs(object) do settings[k] = v end
            if object.class_name == 'Player' then
                fg.world.areas[self.name]:createEntity(object.class_name, object.x, object.y, settings)
            end
        end
    end

    -- Load scripts
    for _, object in ipairs(save_data.objects) do
        local settings = {}
        for k, v in pairs(object) do settings[k] = v end
        if object.class_name == 'Script' then
            fg.world.areas[self.name]:createEntity(object.class_name, object.x, object.y, settings)
        end
    end

    fg.world.areas[self.name]:update(0)

    -- Post load settings
    self:postLoad()
end

function Level:loadToEditor(map_name)
    editor.uids = {}

    local save_data = love.filesystem.load('resources/maps/' .. map_name)()

    -- Loads tilemaps
    for _, l in ipairs(game.layers) do
        local tilemap = self.tilemaps[l]
        for i = 1, #save_data[l].tile_grid do
            for j = 1, #save_data[l].tile_grid[i] do
                tilemap:removeTile(i, j)
            end
        end
        for i = 1, #save_data[l].tile_grid do
            for j = 1, #save_data[l].tile_grid[i] do
                tilemap:changeTile(i, j, save_data[l].tile_grid[i][j])
            end
        end
    end

    -- Loads objects
    for _, object in ipairs(save_data.objects) do
        table.insert(editor.objects, EditorObject(editor, object.x, object.y, {name = object.name, type = object.type, color = object.color,
        id = object.id, image = object.image, active = true, r = object.r, properties = object.properties, w = object.w, h = object.h, 
        z = object.z, target_id = object.target_id, source_id = object.source_id, link_target_id = object.link_target_id, link_source_id = object.link_source_id}))
    end

    -- Link
    for _, m in ipairs(editor.objects) do
        if m.type == 'Link' then
            for _, o in ipairs(editor.objects) do
                if o.id == m.target_id then m.target = o end
                if o.id == m.source_id then m.source = o end
            end
        end
    end

    self.last_editor_loaded_map = map_name
end

function Level:loadFromEditor(filename, previous_map)
    local save_data = love.filesystem.load('resources/maps/' .. filename)()
    local save_data_previous = nil
    if previous_map then save_data_previous = love.filesystem.load('maps/' .. previous_map)() end

    -- Loads tilemaps
    for _, l in ipairs(game.layers) do
        local tilemap = self.tilemaps[l]
        if tilemap then
            for i = 1, #save_data[l].tile_grid do
                for j = 1, #save_data[l].tile_grid[i] do
                    tilemap:removeTile(i, j)
                end
            end
            for i = 1, #save_data[l].tile_grid do
                for j = 1, #save_data[l].tile_grid[i] do
                    tilemap:changeTile(i, j, save_data[l].tile_grid[i][j])
                end
            end
            if l == 'Collision' then
                tilemap:setCollisionData(tilemap.tile_grid)
                fg.world.areas[self.name]:generateCollisionSolids(tilemap) 
            end
        end
    end

    -- Loads objects
    for _, object in ipairs(save_data.objects) do
        if (not self.game.first_player or object.name ~= 'Player') and object.name ~= 'Link' and object.name ~= 'Script' and object.id then
            local settings = self:getObjectSettings(object)
            settings.id = object.id
            settings.link_target_id = object.link_target_id
            settings.link_source_id = object.link_source_id
            fg.world.areas[self.name]:createEntity(self:getObjectName(object.name), object.x, object.y, settings)
        end
    end

    -- Load player
    if self.game.first_player and save_data_previous then
        for _, object in ipairs(save_data_previous.objects) do
            local settings = {}
            for k, v in pairs(object) do settings[k] = v end
            if object.class_name == 'Player' then
                settings.link_target_id = object.link_target_id
                settings.link_source_id = object.link_source_id
                fg.world.areas[self.name]:createEntity(object.class_name, object.x, object.y, settings)
            end
        end
    end

    fg.world.areas[self.name]:update(0)

    -- Load scripts
    for _, object in ipairs(save_data.objects) do
        if object.name == 'Script' then
            local settings = self:getObjectSettings(object)
            settings.id = object.id
            settings.link_target_id = object.link_target_id
            settings.link_source_id = object.link_source_id
            fg.world.areas[self.name]:createEntity(self:getObjectName(object.name), object.x, object.y, settings)
        end
    end

    -- Load links
    for _, object in ipairs(save_data.objects) do
        if object.name == 'Link' then
            local objects = {}
            for _, e in ipairs(fg.world.areas[self.name]:getAllEntities()) do
                if e.link_target_id == object.id then objects.target = e end
                if e.link_source_id == object.id then objects.source = e end
            end
            if objects.target and objects.source then
                self:handleLinks(objects.source, objects.target)
            end
        end
    end

    fg.world.areas[self.name]:update(0)

    -- Post load settings
    self:postLoad()

    self.last_loaded_map = filename
end

function Level:getObjectSettings(object)
    -- Person
    if object.name == 'Player' or object.name == 'BaseNPC' then
        return {shape = 'BSGRectangle', w = 16, h = 10, s = 4, z = object.z}

    elseif object.name == 'MeleeEasy' then
        return {shape = 'BSGRectangle', w = 16, h = 10, s = 4, z = object.z, enemy_type = 'MeleeEasy'}

    elseif object.name == 'MeleeEasyBlocker' then
        return {shape = 'BSGRectangle', w = 16, h = 10, s = 4, z = object.z, enemy_type = 'MeleeEasyBlocker'}

    -- Physics polyrect
    elseif object.name == 'Solid' or object.name == 'DownWall' then
        return {body_type = 'static', w = object.w, h = object.h}

    elseif object.name == 'LevelTransition' then
        return {body_type = 'static', w = object.w, h = object.h, target_level = object.properties.target_level}

    elseif object.name == 'TransPlayerPos' then
        return {linked_object_target_level = object.linked_object_target_level}

    elseif object.name == 'Door' then
        return {target_level = object.properties.target_level}

    elseif object.name == 'Script' then
        return {script_name = object.properties.script_name}

    elseif object.name == 'CameraLimit' then
        return {position = object.properties.position}

    -- Table
    elseif object.name == 'TableVertical' then
        return {direction = 'vertical', z = object.z}
    elseif object.name == 'TableHorizontal' then
        return {direction = 'horizontal', z = object.z}

    -- Chair
    elseif object.name == 'ChairLeft' then
        return {direction = 'left', z = object.z}
    elseif object.name == 'ChairRight' then
        return {direction = 'right', z = object.z}
    elseif object.name == 'ChairUp' then
        return {direction = 'up', z = object.z}
    elseif object.name == 'ChairDown' then
        return {direction = 'down', z = object.z}

    -- Bucket
    elseif object.name == 'BucketEmpty' then
        return {filled = false, z = object.z}
    elseif object.name == 'BucketFilled' then
        return {filled = true, z = object.z}

    else
        return {z = object.z}
    end
end

function Level:getObjectName(name)
    if fg.fn.any({'TableVertical', 'TableHorizontal'}, name) then return 'Table'
    elseif fg.fn.any({'ChairLeft', 'ChairRight', 'ChairUp', 'ChairDown'}, name) then return 'Chair'
    elseif fg.fn.any({'BucketEmpty', 'BucketFilled'}, name) then return 'Bucket'
    elseif fg.fn.any({'BaseNPC'}, name) then return 'NPC'
    else return name end
end

return Level
