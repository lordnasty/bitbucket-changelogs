local Flashstep = fg.Object:extend('Flashstep')

-- PersonMovement: flashstep_position
-- all light attacks: wrap in applyPreAttackPassives

function Flashstep:new(settings)
    local settings = settings or {}
    for k, v in pairs(settings) do self[k] = v end
    self.trigger_type = 'Pre Attack'
    self.combat_type = 'Attack'
    self.combat_class = 'Light'
    self.combat_range = 'Melee'
end

function Flashstep:update(dt)

end

function Flashstep:init()
    self.parent.flashstep = true
end

function Flashstep:apply(action)
    if not self.parent.locked then action() return end
    self.parent.flashstep_position = fg.Vector(self.parent.x, self.parent.y)
    local angle, direction = 0, fg.utils.angleToDirection2(fg.Vector(self.parent.x, self.parent.y):angleTo(fg.Vector(self.parent.locked.x, self.parent.locked.y)))
    if direction == 'left' then angle = math.pi; self.direction = 'right' else self.direction = 'left' end
    self.parent.timer:tween('flashstep_position_tween', 0.06, self.parent.flashstep_position, 
    {x = self.parent.locked.x + 30*math.cos(angle), y = self.parent.locked.y + 0.1}, 'linear')
    self.parent.timer:after('flashstep_position_after', 0.08, function()
        self.parent.flashstep_position = nil
        action() 
    end)
end

return Flashstep
