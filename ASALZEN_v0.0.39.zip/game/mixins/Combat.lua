local Combat = fg.Object:extend('Combat')

-- while [n] can't move = set parent.movement_locked = true on every [n]

function Combat:combatNew(settings)
    local settings = settings or {}

    if self.class_name == 'NPC' then
        self.fleft = self.fg.obv(settings.settings.fleft)
        self.fright = self.fg.obv(settings.settings.fright)
        self.fup = self.fg.obv(settings.settings.fup)
        self.fdown = self.fg.obv(settings.settings.fdown)
        self.left_shoulder = self.fg.obv(settings.settings.left_shoulder)
        self.left_button = self.fg.obv(settings.settings.left_button)
        self.right_shoulder = self.fg.obv(settings.settings.right_shoulder)
        self.right_button = self.fg.obv(settings.settings.right_button)
    end

    self.combat_actions = {
        Empty = Empty(), 
        LightAttack1 = LightAttack1({parent = self}),
        HeavyAttack1 = HeavyAttack1({parent = self}),
        Dodge = Dodge({parent = self}),
        Block = Block({parent = self}),
        Lock = Lock({parent = self, lock_type = (settings.settings.character and settings.settings.character.lock_type) or settings.settings.lock_type,
                    (settings.settings.character and settings.settings.character.lock_radius) or settings.settings.lock_radius}),
    }

    self.fleft_action = self.combat_actions[settings.settings.fleft_action or 'Empty']
    self.fright_action = self.combat_actions[settings.settings.fright_action or 'Empty']
    self.fup_action = self.combat_actions[settings.settings.fup_action or 'Empty']
    self.fdown_action = self.combat_actions[settings.settings.fdown_action or 'Empty']
    self.left_shoulder_action = self.combat_actions[settings.settings.left_shoulder_action or 'Empty']
    self.left_button_action = self.combat_actions[settings.settings.left_button_action or 'Empty']
    self.right_shoulder_action = self.combat_actions[settings.settings.right_shoulder_action or 'Empty']
    self.right_button_action = self.combat_actions[settings.settings.right_button_action or 'Empty']
end

function Combat:combatUpdate(dt)
    local is = {}
    is.fleft_pressed, is.fright_pressed, is.fup_pressed, is.fdown_pressed, 
    is.right_shoulder_pressed, is.right_button_pressed, is.left_shoulder_pressed, is.left_button_pressed,
    is.fleft_down, is.fright_down, is.fup_down, is.fdown_down, 
    is.right_shoulder_down, is.right_button_down, is.left_shoulder_down, is.left_button_down,
    is.fleft_released, is.fright_released, is.fup_released, is.fdown_released, 
    is.right_shoulder_released, is.right_button_released, is.left_shoulder_released, is.left_button_released = self:handleCombatInputs()

    local actions = {'fleft', 'fright', 'fup', 'fdown', 'right_shoulder', 'right_button', 'left_shoulder', 'left_button'}
    for _, action in ipairs(actions) do
        local current_action = action .. '_action'
        if self:actionActive(self[current_action]) then
            if is[action .. '_pressed'] then self[current_action]:pressed() end
            if is[action .. '_down'] then self[current_action]:down(dt, is[action .. '_down']) end
            if is[action .. '_released'] then self[current_action]:released() end
        end
    end

    for _, action in ipairs(actions) do
        local current_action = action .. '_action'
        self[current_action]:update(dt)
    end

    -- Set attacking
    local attacks = self:getAllAttacks()
    self.attacking = false
    for _, attack in ipairs(attacks) do if attack.attacking then self.attacking = true end end
end

function Combat:combatDraw()

end

function Combat:bindAction(action_name, action)
    self[action_name .. '_action'] = self.combat_actions[action]
end

function Combat:bindActions(actions)
    for k, v in pairs(actions) do self:bindAction(k, v) end
end

function Combat:interruptAttack()
    local attacks = self:getAllAttacks()
    for _, attack in ipairs(attacks) do
        if attack.interrupt then attack:interrupt() end
    end
end

function Combat:interruptSkill()
    local skills = self:getAllskills()
    for _, skill in ipairs(skills) do
        if skill.interrupt then skill:interrupt() end
    end
end

function Combat:interruptBlock()
    self.movement_locked = false
    self.blocking = false
    self['block'] = false
end

function Combat:interruptKnockback()
    self.knockdback = false
    if self.knockback_v then
        self.timer:cancel('knockbacking')
        self.knockback_v.x = 0
        self.knockback_v.y = 0
        self.knockback_v_damping = false
        self.body:setLinearVelocity(0, 0)
    elseif self.knockback_velocity then
        self.timer:cancel('knockbacking')
        self.knockback_velocity.x = 0
        self.knockback_velocity.y = 0
        self.knockback_velocity_damping = false
        self.body:setLinearVelocity(0, 0)
    end
end

function Combat:actionActive(action)
    if (action.type == 'Attack' or action.type == 'Skill') then
        if not self.locked and action.target_type and action.target_type == 'Lockon' then return false end -- while not locked can't attack/skill if target_type == 'Lockon'
        if self.attacking and not action.attacking then return false end -- while attacking can't attack/skill
        if self.dodging then return false end -- while dodging can't attack/skill
        if self.blocking then return false end -- while blocking can't attack/skill
        if self.knockdback then return false end -- while knockdback can't attack/skill
        return true
    end
    if action.type == 'Dodge' then return true end
    if action.type == 'Block' then return true end
    if action.type == 'Lock' then return true end
end

function Combat:getAllAttacks()
    local actions = {'fleft_action', 'fright_action', 'fup_action', 'fdown_action', 
                     'right_shoulder_action', 'right_button_action', 'left_shoulder_action', 'left_button_action'}
    local out_actions = {}
    for _, action in ipairs(actions) do
        if self[action].type == 'Attack' then
            table.insert(out_actions, self[action])
        end
    end
    return out_actions
end

function Combat:getAllSkills()
    local actions = {'fleft_action', 'fright_action', 'fup_action', 'fdown_action', 
                     'right_shoulder_action', 'right_button_action', 'left_shoulder_action', 'left_button_action'}
    local out_actions = {}
    for _, action in ipairs(actions) do
        if self[action].type == 'Skill' then
            table.insert(out_actions, self[action])
        end
    end
    return out_actions
end

function Combat:changeLockType(new_type)
    self.combat_actions.Lock.lock_type = new_type
end

function Combat:handleCombatInputs()
    local fleft_pressed, fright_pressed, fup_pressed, fdown_pressed = nil, nil, nil, nil
    local right_shoulder_pressed, right_button_pressed, left_shoulder_pressed, left_button_pressed = nil, nil, nil, nil
    local fleft_down, fright_down, fup_down, fdown_down = nil, nil, nil, nil
    local right_shoulder_down, right_button_down, left_shoulder_down, left_button_down = nil, nil, nil, nil
    local fleft_released, fright_released, fup_released, fdown_released = nil, nil, nil, nil
    local right_shoulder_released, right_button_released, left_shoulder_released, left_button_released = nil, nil, nil, nil

    if self.class_name == 'Player' then
        fleft_pressed = self.fg.input:pressed('fleft')
        fup_pressed = self.fg.input:pressed('fup')
        fright_pressed = self.fg.input:pressed('fright')
        fdown_pressed = self.fg.input:pressed('fdown')
        left_button_pressed = self.fg.input:pressed('leftAttack')
        right_button_pressed = self.fg.input:pressed('rightAttack')
        left_shoulder_pressed = self.fg.input:pressed('leftSelect')
        right_shoulder_pressed = self.fg.input:pressed('rightSelect')
        fleft_down = self.fg.input:down('fleft')
        fup_down = self.fg.input:down('fup')
        fright_down = self.fg.input:down('fright')
        fdown_down = self.fg.input:down('fdown')
        right_shoulder_down = self.fg.input:down('rightSelect')
        right_button_down = self.fg.input:down('rightAttack')
        left_shoulder_down = self.fg.input:down('leftSelect')
        left_button_down = self.fg.input:down('leftAttack')
        fleft_released = self.fg.input:released('fleft')
        fup_released = self.fg.input:released('fup')
        fright_released = self.fg.input:released('fright')
        fdown_released = self.fg.input:released('fdown')
        left_button_released = self.fg.input:released('leftAttack')
        right_button_released = self.fg.input:released('rightAttack')
        left_shoulder_released = self.fg.input:released('leftSelect')
        right_shoulder_released = self.fg.input:released('rightSelect')

    elseif self.class_name == 'NPC' then
        fleft_pressed = self.fleft:enter(true)
        fup_pressed = self.fup:enter(true)
        fright_pressed = self.fright:enter(true)
        fdown_pressed = self.fdown:enter(true)
        right_button_pressed = self.right_button:enter(true)
        left_button_pressed = self.left_button:enter(true)
        right_shoulder_pressed = self.right_shoulder:enter(true)
        left_shoulder_pressed = self.left_shoulder:enter(true)
        fleft_down = self.fleft.v
        fup_down = self.fup.v
        fright_down = self.fright.v
        fdown_down = self.fdown.v
        right_shoulder_down = self.right_shoulder.v
        right_button_down = self.right_button.v
        left_shoulder_down = self.left_shoulder.v
        left_button_down = self.left_button.v
        fleft_released = self.fleft:exit(true)
        fup_released = self.fup:exit(true)
        fright_released = self.fright:exit(true)
        fdown_released = self.fdown:exit(true)
        right_button_released = self.right_button:exit(true)
        left_button_released = self.left_button:exit(true)
        right_shoulder_released = self.right_shoulder:exit(true)
        left_shoulder_released = self.left_shoulder:exit(true)
    end

    return fleft_pressed, fright_pressed, fup_pressed, fdown_pressed, 
           right_shoulder_pressed, right_button_pressed, left_shoulder_pressed, left_button_pressed,
           fleft_down, fright_down, fup_down, fdown_down, 
           right_shoulder_down, right_button_down, left_shoulder_down, left_button_down,
           fleft_released, fright_released, fup_released, fdown_released, 
           right_shoulder_released, right_button_released, left_shoulder_released, left_button_released
end

function Combat:combatSave()
    local fleft, fright, fup, fdown, right_shoulder, right_button, left_shoulder, left_button = nil, nil, nil, nil, nil, nil, nil, nil
    if self.class_name == 'NPC' then
        fleft = self.fleft.v
        fright = self.fright.v
        fup = self.fup.v
        fdown = self.fdown.v
        left_shoulder = self.left_shoulder.v
        left_button = self.left_button.v
        right_shoulder = self.right_shoulder.v
        right_button = self.right_button.v
    end

    return {
        fleft_action = self.fleft_action.class_name, fright_action = self.fright_action.class_name, fup_action = self.fup_action.class_name, 
        fdown_action = self.fdown_action.class_name, right_shoulder_action = self.right_shoulder_action.class_name, 
        right_button_action = self.right_button_action.class_name, left_shoulder_action = self.left_shoulder_action.class_name, 
        left_button_action = self.left_button_action.class_name, fleft = fleft, fright = fright, fdown = fdown, fup = fup, 
        right_button = right_button, right_shoulder = right_shoulder, left_button = left_button, left_shoulder = left_shoulder,
        lock_type = self.combat_actions.Lock.lock_type, lock_radius = self.combat_actions.Lock.lock_radius,
    }
end

return Combat
