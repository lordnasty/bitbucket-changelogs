local Lock = fg.Object:extend('Lock')

function Lock:new(settings)
    local settings = settings or {}
    for k, v in pairs(settings) do self[k] = v end
    self.type = 'Lock'
    self.down_value = fg.obv(0)

    if self.parent.class_name == 'NPC' then self.lock_targets = {'Player'}
    elseif self.parent.class_name == 'Player' then self.lock_targets = {'NPC'} end
    self.lock_type = settings.lock_type or 'Manual'
    self.lock_radius = settings.lock_radius or 600
    self.lock_active = false
    self.lock_direction_x = fg.obv(0)
    self.lock_direction_y = fg.obv(0)
    self.entity_queue = {}
    self.queue_index = 1
    self.lock_visual = self.parent.area:createEntityImmediate('AttackLockVisual', -10000, -10000)
end

function Lock:update(dt)
    local fg = self.parent.fg

    -- Get nearby entities
    local entities = fg.fn.select(self.parent.area:queryAreaCircle(self.parent.x, self.parent.y, self.lock_radius, self.lock_targets), function(k, e) 
        if e.id ~= self.parent.id and not e.dying and not e.stage_decreasing then return true end 
    end)

    -- Insert entities that are not already in the entity queue
    for i = 1, #entities do
        if entities[i] then
            if not fg.fn.contains(self.entity_queue, function(e) if e.id == entities[i].id then return true end end) then
                table.insert(self.entity_queue, entities[i])
            end
        end
    end

    -- Remove entities that are far away enough
    for i = #self.entity_queue, 1, -1 do
        local d = fg.mlib.line.getDistance(self.parent.x, self.parent.y, self.entity_queue[i].x, self.entity_queue[i].y)
        if d > self.lock_radius or self.entity_queue[i].dying or self.entity_queue[i].stage_decreasing then table.remove(self.entity_queue, i) end
    end

    -- Fix queue index if out of range
    if self.queue_index < 1 then self.queue_index = 1 end
    if self.queue_index > #self.entity_queue then self.queue_index = #self.entity_queue end

    self.lock_visual:update(dt)

    -- Camera follow
    if self.parent.class_name == 'Player' then
        if self.parent.locked then
            fg.world.camera:follow({x = (self.parent.x + self.parent.locked.x)/2, y = (self.parent.y + self.parent.locked.y)/2}, {follow_style = 'lockon', lerp = 20})
        else fg.world.camera:follow(self.parent, {follow_style = 'lockon', lerp = 10}) end
    end

    if self.parent.locked then
        -- Keyboard tabbing selection
        if fg.input:pressed('lockSelect') then 
            self.queue_index = self.queue_index + 1 
            if self.queue_index > #self.entity_queue then self.queue_index = 1 end
            self.lock_visual.parent = self.entity_queue[self.queue_index]
            self.parent.locked = self.entity_queue[self.queue_index]
        end

        -- Right stick selection
        local x, y = fg.input:down('lockHorizontal'), fg.input:down('lockVertical')
        if x then
            if x >= 0.5 then self.lock_direction_x:set(1) end
            if x <= -0.5 then self.lock_direction_x:set(-1) end
            if x >= -0.2 and x <= 0.2 then self.lock_direction_x:set(0) end
        end
        if y then
            if y >= 0.5 then self.lock_direction_y:set(1) end
            if y <= -0.5 then self.lock_direction_y:set(-1) end
            if y >= -0.2 and y <= 0.2 then self.lock_direction_y:set(0) end
        end

        if self.lock_direction_x:enter(1) then self:lockSelect('right') end
        if self.lock_direction_x:enter(-1) then self:lockSelect('left') end
        if self.lock_direction_y:enter(1) then self:lockSelect('down') end
        if self.lock_direction_y:enter(-1) then self:lockSelect('up') end
    end
end

function Lock:pressed()
    if self.lock_type == 'Manual' then
        self.lock_visual.parent = self.entity_queue[self.queue_index]
        self.parent.locked = self.entity_queue[self.queue_index]
    elseif self.lock_type == 'Auto' then
        self.lock_active = not self.lock_active 
        if self.lock_active then
            self.lock_visual.parent = self.entity_queue[self.queue_index]
            self.parent.locked = self.entity_queue[self.queue_index]
        else
            self.lock_visual.parent = nil
            self.parent.locked = false
        end
    end
end

function Lock:down(dt, down_value)
    if down_value and type(down_value) == 'number' then
        self.down_value:set(down_value)
        if self.down_value:ge(0.4) then self:pressed()
        elseif self.down_value:le(0.4) then self:released() end
    end
end

function Lock:released()
    if self.lock_type == 'Manual' then
        self.lock_visual.parent = nil
        self.parent.locked = false
    end
end

function Lock:lockSelect(direction)
    local entities = fg.fn.select(self.parent.area:queryAreaCircle(self.parent.locked.x, self.parent.locked.y, self.lock_radius, self.lock_targets), function(k, e) 
        if e.id ~= self.parent.locked.id and not e.dying and not e.stage_decreasing then return true end 
    end)

    local x, y = self.parent.locked.x, self.parent.locked.y
    local angled = function(a, b) local d = math.abs(a - b) % 360; if d > 180 then return 360 - d else return d end end
    local angles = {right = 0, left = -180, up = -90, down = 90}
    local min, j = 10000000, 1 
    -- Find closest direction entity
    for i, e in ipairs(entities) do 
        local d = fg.mlib.line.getDistance(x, y, e.x, e.y)
        local v = math.max(angled(math.deg(math.atan2(e.y - y, e.x - x)), angles[direction]), 20)*d
        if v < min then min = v; j = i end
    end
    -- Find its index and set it as new queue_index
    for i, e in ipairs(self.entity_queue) do
        if e.id == entities[j].id then
            self.queue_index = i
            break
        end
    end

    -- Set new locked entity
    self.lock_visual.parent = self.entity_queue[self.queue_index]
    self.parent.locked = self.entity_queue[self.queue_index]
end

return Lock
