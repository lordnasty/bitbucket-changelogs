local Empty = fg.Object:extend('Empty')

function Empty:new(settings)
    local settings = settings or {}
    self.type = 'Empty'
end

function Empty:update(dt)

end

function Empty:pressed()

end

function Empty:down()
    
end

function Empty:released()

end

return Empty
