game.events['MeleeArea_LightAttack1'] = function(melee_area, light_attack, source, target)
    source:ATKjuice()
    target:hitATK(source)

    local dx, dy = target.x - source.x, target.y - source.y
    if dx < 0 then dx = -1 else dx = 1 end
    if dy < 0 then dy = -1 else dy = 1 end
    local random = fg.utils.math.random

    -- Star hit effect
    local angle = 0
    if dx > 0 then angle = random(-math.pi/4, math.pi/4) else angle = random(3*math.pi/4, 5*math.pi/4) end
    source.area:createEntity('StarHitEffect', 0, 0, {angle = angle, v = random(25, 100), parent = target, offset_x = dx*8, offset_y = -36 + random(-2, 2)})

    -- 1st attack 
    if light_attack.hit_counter == 2 then
        source.area:createEntity('HitEffect', source.x + dx*24 + random(-4, 4), source.y - 20 + random(-4, 4))

    -- 2nd attack push
    elseif light_attack.hit_counter == 3 then
        target:knockback(dx*100, 0)
        source.area:createEntity('HitEffect', source.x + dx*30 + random(-4, 4), source.y - 20 + random(-4, 4))
        fg.world.camera:shake(1, 0.1)

    -- 3rd attack push
    elseif light_attack.hit_counter == 1 then
        target:knockback(dx*200, 0)
        source.area:createEntity('HitEffect', source.x + dx*36 + random(-4, 4), source.y - 20 + random(-4, 4))
        fg.world.camera:shake(2, 0.2)
    end

    -- 2nd or 3rd attacks
    if light_attack.hit_counter ~= 2 then
        -- Blood 
        local z = target.z + target.height_z - 6
        local n = math.random(2, 4)
        for i = 1, n do 
            source.area:createEntity('BloodParticle', target.x + 4*dx, target.y, {v = fg.Vector(dx*random(150, 250), random(-25, 25)), z = z, v_z = -random(0, 50)}) 
        end
    end
end
