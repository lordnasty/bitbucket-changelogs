game.events['MeleeArea_HeavyAttack1'] = function(melee_area, heavy_attack, source, target)
    source:ATKjuice()
    target:hitATK(source)

    local dx, dy = target.x - source.x, target.y - source.y
    if dx < 0 then dx = -1 else dx = 1 end
    if dy < 0 then dy = -1 else dy = 1 end
    local random = fg.utils.math.random

    -- Star hit effect
    local angle = 0
    if dx > 0 then angle = random(-math.pi/4, math.pi/4) else angle = random(3*math.pi/4, 5*math.pi/4) end
    source.area:createEntity('StarHitEffect', 0, 0, {angle = angle, v = random(25, 100), parent = target, offset_x = dx*8, offset_y = -36 + random(-2, 2)})

    -- Blood 
    local z = target.z + target.height_z - 6
    local n = math.random(2, 4)
    for i = 1, n do 
        source.area:createEntity('BloodParticle', target.x + 4*dx, target.y, {v = fg.Vector(dx*random(150, 250), random(-25, 25)), z = z, v_z = -random(0, 50)}) 
    end

    -- Hit effect
    source.area:createEntity('HitEffect', source.x + dx*24 + random(-4, 4), source.y - 20 + random(-4, 4))

    -- Push, shake
    fg.world.camera:shake(2, 0.2)
    target:knockback(dx*200, 0) 
    if melee_area.first_hit then heavy_attack.first_hit_successful = true end
end
