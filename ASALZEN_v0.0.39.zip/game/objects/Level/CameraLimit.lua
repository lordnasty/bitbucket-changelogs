local CameraLimit = fg.Class('CameraLimit', 'Entity')

function CameraLimit:new(area, x, y, settings)
    local settings = settings or {}
    CameraLimit.super.new(self, area, x, y, settings)
end

function CameraLimit:update(dt)

end

function CameraLimit:draw()

end

function CameraLimit:save()
    return {id = self.id, x = self.x, y = self.y, position = self.position}
end

return CameraLimit
