local MeleeArea = fg.Class('MeleeArea', 'Entity')
MeleeArea:implement(fg.PhysicsBody)

MeleeArea.ignores = {'All'}

function MeleeArea:new(area, x, y, settings)
    local settings = settings or {}
    MeleeArea.super.new(self, area, x, y, settings)

    self:physicsBodyNew(area, x, y, settings)
end

function MeleeArea:update(dt)
    self:physicsBodyUpdate(dt)

    self.dead = true

    local entities = self.area:queryAreaRectangle(self.x, self.y, self.w, self.h, {'Player', 'NPC'})
    entities = self.fg.fn.select(entities, function(_, entity) return entity.id ~= self.source.id and entity.class_name ~= self.source.class_name end)
    for _, entity in ipairs(entities) do game.events[self.class_name .. '_' .. self.attack.class_name](self, self.attack, self.source, entity) end

    --[[
        local angle = self.fg.Vector(player.x, player.y):angleTo(self.fg.Vector(self.parent.x, self.parent.y))
        self.area:hitFrameStopAdd(15, {'All', except = {'HitEffect', 'BloodPool', 'PersonHead'}}, function()
            player.v_z = -100
            player:push(150*math.cos(angle), 50*math.sin(angle))
            self.fg.world.camera:shake(2, 0.3)
        end)
    ]]--
end

function MeleeArea:draw()
    self:physicsBodyDraw()
end

return MeleeArea
