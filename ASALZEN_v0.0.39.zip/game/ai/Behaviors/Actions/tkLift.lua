local tkLift = Action:extend('tkLift')

function tkLift:new()
    tkLift.super.new(self, 'tkLift')

    self.done = false
end

function tkLift:update(dt, context)
    return tkLift.super.update(self, dt, context)
end

function tkLift:run(dt, context)
    if self.done then return 'success' end
    if context.any_around_entity then
        context.any_around_entity.v_z = -mg.utils.math.random(10, 30)
        return 'running'
    else return 'failure' end
end

function tkLift:start(context)
    context.object.tk_charging = true
    context.object.timer:after({0.5, 1.5}, function() self.done = true end)
end

function tkLift:finish(status, context)
    context.any_around_entity = nil
    context.object.tk_charging = false
    self.done = false
end

return tkLift
