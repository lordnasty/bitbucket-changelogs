local meleeEasyChase = Action:extend('meleeEasyChase')

function meleeEasyChase:new(success_radius, separation_radius)
    meleeEasyChase.super.new(self, 'meleeEasyChase')

    self.success_radius = success_radius
    self.separation_radius = separation_radius
end

function meleeEasyChase:update(dt, context)
    return meleeEasyChase.super.update(self, dt, context)
end

function meleeEasyChase:run(dt, context)
    if context.any_around_entity then
        if context.object.stage_decreasing or context.object.dying or not context.object.agroed then 
            return 'failure'
        else
            context.object:arriveOn(self.fg.Vector(context.any_around_entity.body:getPosition()))
            local distance = self.fg.mlib.line.getDistance(context.object.x, context.object.y, context.any_around_entity.body:getPosition())
            if distance < self.success_radius then return 'success'
            elseif distance < 2*self.success_radius then 
                context.object.punch_charge = true
                if context.object.head.eye_index ~= 3 and context.object.head.eye_index ~= 5 then context.object.head:changeEyes(7) end
                context.object.head:changeMouth(5)
            elseif distance > 2*self.success_radius then 
                context.object.punch_charge = false
                context.object.head:restoreEyes()
                context.object.head:restoreMouth()
            end
        end
    end 
    return 'running'
end

function meleeEasyChase:start(context)
    context.object:separationOn(self.separation_radius, {'PersonAI'})
end

function meleeEasyChase:finish(status, context)
    context.object:arriveOff()
    context.object:separationOff()
end

return meleeEasyChase
