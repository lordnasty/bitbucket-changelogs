local WaitUntil = Decorator:extend('WaitUntil')

function WaitUntil:new(behavior)
    WaitUntil.super.new(self, 'WaitUntil', behavior)
end

function WaitUntil:update(dt, context)
    return WaitUntil.super.update(self, dt, context)
end

function WaitUntil:run(dt, context)
    local status = self.behavior:update(dt, context)
    if status == 'success' then return 'success'
    else return 'running' end
end

function WaitUntil:start(context)

end

function WaitUntil:finish(status, context)

end

return WaitUntil
