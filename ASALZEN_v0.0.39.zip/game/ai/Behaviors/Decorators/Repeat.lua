local Repeat = Decorator:extend('Repeat')

function Repeat:new(behavior)
    Repeat.super.new(self, 'Repeat', behavior)
end

function Repeat:update(dt, context)
    return Repeat.super.update(self, dt, context)
end

function Repeat:run(dt, context)
    local status = self.behavior:update(dt, context)
    return 'running'
end

function Repeat:start(context)

end

function Repeat:finish(status, context)

end

return Repeat
