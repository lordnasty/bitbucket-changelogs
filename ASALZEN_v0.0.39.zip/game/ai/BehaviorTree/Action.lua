Action = Behavior:extend('Action')

function Action:new(name)
    Action.super.new(self)
    self.name = name or 'Action'
    self.fg = fg
end

function Action:update(dt, context)
    return Action.super.update(self, dt, context)
end
