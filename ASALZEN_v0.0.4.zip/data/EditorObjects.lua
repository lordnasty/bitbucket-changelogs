local _ = {}
local objects = {
    {name = 'Solid', type = 'Polyrect', color = {192, 64, 64}},
    {name = 'LevelTransition', type = 'Polyrect', color = {192, 128, 64}},
    {name = 'DownWall', type = 'Polyrect', color = {96, 96, 96}},
    {name = 'Script', type = 'Polyrect', color = {96, 192, 96}},
    {name = 'CameraLimit', type = 'Polyrect', color = {192, 96, 96}},
    {name = 'Person',type = 'Object', image = 'resources/editor/person.png'},
    {name = 'PersonAI', type = 'Object', image = 'resources/editor/person_ai.png'},
    {name = 'Door', type = 'Object', image = 'resources/editor/door.png'},
    {name = 'TableVertical', type = 'Object', image = 'resources/editor/table_vertical.png'},
    {name = 'TableHorizontal', type = 'Object', image = 'resources/editor/table_horizontal.png'},
    {name = 'Box', type = 'Object', image = 'resources/editor/box.png'},
    {name = 'ChairRight', type = 'Object', image = 'resources/editor/chair_right.png'},
    {name = 'ChairUp', type = 'Object', image = 'resources/editor/chair_up.png'},
    {name = 'ChairLeft', type = 'Object', image = 'resources/editor/chair_left.png'},
    {name = 'ChairDown', type = 'Object', image = 'resources/editor/chair_down.png'},
    {name = 'Desk', type = 'Object', image = 'resources/editor/desk.png'},
    {name = 'BucketEmpty', type = 'Object', image = 'resources/editor/bucket_empty.png'},
    {name = 'BucketFilled', type = 'Object', image = 'resources/editor/bucket_filled.png'},
}

for i, object in ipairs(objects) do _[i] = object end

return function(self)
    self.objects = {}
    for _, v in pairs(_) do table.insert(self.objects, {name = v.name, editor_type = v.type, image = v.image, color = v.color}) end
end
