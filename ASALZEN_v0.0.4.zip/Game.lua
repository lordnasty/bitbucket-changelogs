local Game = fg.Object:extend('Game')

require 'data/Animations'
require 'game/ai/BehaviorTree/Root'

-- Require everything that can be required here
local prepaths = {'level/', 'mixins/', 'objects/', 'systems/', 'ai/Behaviors/'}
for _, prepath in ipairs(prepaths) do
    for _, p in ipairs(love.filesystem.getDirectoryItems('game/' .. prepath)) do
        if love.filesystem.isDirectory('game/' .. prepath .. p) then
            for _, f in ipairs(love.filesystem.getDirectoryItems('game/' .. prepath .. p .. '/')) do
                if f:sub(-4) == '.lua' then _G[f:sub(1, -5)] = require('game/' .. prepath .. p .. '/' .. f:sub(1, -5)) end
            end
        else if p:sub(-4) == '.lua' then _G[p:sub(1, -5)] = require('game/' .. prepath .. p:sub(1, -5)) end end
    end
end

-- Load scripts
SH = require 'game/scripts/ScriptHelper'
Scripts = {}
for _, p in ipairs(love.filesystem.getDirectoryItems('game/scripts')) do
    if p ~= 'ScriptHelper.lua' then
        Scripts[p:sub(1, -5)] = require('game/scripts/' .. p:sub(1, -5))
    end
end

function Game:new()
    love.graphics.setLineStyle('rough')
    love.graphics.setBackgroundColor(32, 32, 32)
    fg.setScreenSize(960, 720)
    fg.lovebird_enabled = true

    -- fg.debugDraw.controller_enabled = 'PS3'
    fg.input:bind('f1', function() fg.lurker.scan() end)
    fg.input:bind('kp0', function() fg.debugDraw.physics_enabled = not fg.debugDraw.physics_enabled end)
    fg.input:bind('f5', 'activate')
    fg.input:bind('f6', 'activateMem')

    local shaders = require('resources/shaders/shaders')
    fg.Shaders = {}
    fg.Shaders['combine'] = shaders.combine

    -- Transitions
    self.screen_transition = nil

    -- Editor settings
    self.active = false

    -- Set editor objects
    self.objects = {}
    require('data/EditorObjects')(self)

    -- Set editor tilesets
    self.tile_width, self.tile_height = 32, 32
    self.tilesets = fg.fn.map(love.filesystem.getDirectoryItems('resources/tilesets'), function(k, v) return v:sub(1, -5) end)

    -- Set editor layers
    self.layers = {'Collision', 'Background_2', 'Background_1', 'Default', 'Front_1', 'Front_2'}
    for _, layer in ipairs(self.layers) do fg.world:addLayer(layer) end

    self.levels = {}
    self.levels['Editor'] = Level(self, 'Editor', 0, 0)
    self.all_maps = {}
    for _, file in ipairs(love.filesystem.getDirectoryItems('resources/maps')) do table.insert(self.all_maps, file) end
    -- Here is where you'll create a floor and inject higher level game structure logic later
    for _, map in ipairs(self.all_maps) do self.levels[map] = Level(self, map, 0, 0) end

    self.first_player = false

    -- OccludedHighlight
    self.occluded_highlight = OccludedHighlight()

    self:loadAssets()
end

function Game:update(dt)
    if not self.finished_loading then fg.Loader.update(); return end
    if not self.active then return end
    if fg.input:pressed('activate') then self:activate() end
    if fg.input:pressed('activateMem') then self:activateMem() end
    fg.world:sendToShader('Blood_Floor', 'Outline', 'brightness', 0.4)
    fg.world:sendToShader('Floor', 'Outline', 'brightness', 0.0)
    fg.world:sortRenderOrder(function(a, b) return a.y + (a.sort_y or 0) < b.y + (b.sort_y or 0) end)

    for _, level in pairs(self.levels) do level:update(dt) end
    if self.occluded_highlight then self.occluded_highlight:update(dt) end
    if self.screen_transition then self.screen_transition:update(dt) end
end

function Game:draw()
    for _, level in pairs(self.levels) do level:draw() end
    if self.occluded_highlight then self.occluded_highlight:draw() end
    if self.screen_transition then self.screen_transition:draw() end
end

function Game:start()
    self.active = true
    fg.debugDraw.physics_enabled = true
    local vert = 'resources/shaders/default.vert'
    fg.world.areas['Default']:deactivate()
    fg.gravity_z = 400

    -- Set game layers
    fg.Spritebatches['Blood'] = fg.Spritebatch(0, 0, fg.Assets.blood, 1000, 'stream')
    fg.world:addLayer('Blood_Floor')
    fg.world:addToLayer('Blood_Floor', fg.Spritebatches['Blood'])
    fg.world:addShaderToLayer('Blood_Floor', 'Outline', vert, 'resources/shaders/outline.frag')
    fg.world:addLayer('Floor')
    fg.world:addShaderToLayer('Floor', 'Outline', vert, 'resources/shaders/outline.frag')
    fg.world:addLayer('Effects')
    fg.world:addLayer('Effects_Outlined')
    fg.world:addShaderToLayer('Effects_Outlined', 'Outline', vert, 'resources/shaders/outline.frag')
    fg.world:addLayer('UI')
    fg.world:addShaderToLayer('UI', 'Outline', vert, 'resources/shaders/outline.frag')
    fg.world:setLayerOrder({'Background_2', 'Background_1', 'Blood_Floor', 'Floor', 'Default', 'Front_1', 'Front_2', 'Effects', 'Effects_Outlined', 'UI', 'Debug'})

    for _, map in ipairs(self.all_maps) do fg.world.areas[map]:initializePools() end
    fg.current_area = 'StartArea'
    self.levels['StartArea']:activate()
    fg.world.areas['StartArea']:initializePools()
end

function Game:loadAssets()
    fg.Loader.newImage(fg.Assets, 'shadow', 'resources/shadow.png')
    fg.Loader.newImage(fg.Assets, 'hit_effect', 'resources/effects/hit_effect.png')
    fg.Loader.newImage(fg.Assets, 'locked_on', 'resources/effects/locked_on_2.png')
    fg.Loader.newImage(fg.Assets, 'locked_on_big', 'resources/effects/locked_on_big_2.png')
    fg.Loader.newImage(fg.Assets, 'blood', 'resources/effects/blood.png')
    fg.Loader.newImage(fg.Assets, 'blood_particle', 'resources/effects/blood_particle.png')
    fg.Loader.newImage(fg.Assets, 'triangle', 'resources/effects/triangle.png')
    fg.Loader.newImage(fg.Assets, 'sweatdrop', 'resources/effects/sweatdrop.png')
    fg.Loader.newImage(fg.Assets, 'line_thingies', 'resources/effects/line_thingies.png')
    fg.Loader.newImage(fg.Assets, 'icons_strip8', 'resources/effects/icons_strip8.png')

    fg.Loader.newImage(fg.Assets, 'door_open', 'resources/objects/door_open.png')
    fg.Loader.newImage(fg.Assets, 'door_close', 'resources/objects/door_close.png')
    fg.Loader.newImage(fg.Assets, 'door_opened', 'resources/objects/door_opened.png')
    fg.Loader.newImage(fg.Assets, 'door_closed', 'resources/objects/door_closed.png')
    fg.Loader.newImage(fg.Assets, 'box', 'resources/objects/box.png')
    fg.Loader.newImage(fg.Assets, 'chair', 'resources/objects/chair.png')
    fg.Loader.newImage(fg.Assets, 'desk', 'resources/objects/desk.png')
    fg.Loader.newImage(fg.Assets, 'bucket', 'resources/objects/bucket.png')
    fg.Loader.newImage(fg.Assets, 'table_horizontal', 'resources/objects/table_1.png')
    fg.Loader.newImage(fg.Assets, 'table_vertical', 'resources/objects/table_2.png')

    fg.Loader.newImage(fg.Assets, 'male_idle', 'resources/male/idle.png')
    fg.Loader.newImage(fg.Assets, 'male_run', 'resources/male/run.png')
    fg.Loader.newImage(fg.Assets, 'male_hit', 'resources/male/hit.png')
    fg.Loader.newImage(fg.Assets, 'male_block', 'resources/male/block.png')
    fg.Loader.newImage(fg.Assets, 'male_dash', 'resources/male/dash.png')
    fg.Loader.newImage(fg.Assets, 'male_backdash', 'resources/male/backdash.png')
    fg.Loader.newImage(fg.Assets, 'male_low_dash', 'resources/male/low_dash.png')
    fg.Loader.newImage(fg.Assets, 'male_fall_down', 'resources/male/fall_down.png')
    fg.Loader.newImage(fg.Assets, 'male_down_idle', 'resources/male/down_idle.png')
    fg.Loader.newImage(fg.Assets, 'male_idle_combat', 'resources/male/idle_combat.png')
    fg.Loader.newImage(fg.Assets, 'male_run_combat', 'resources/male/run_combat.png')
    fg.Loader.newImage(fg.Assets, 'male_kick', 'resources/male/kick.png')
    fg.Loader.newImage(fg.Assets, 'male_light_punch_left', 'resources/male/light_punch_left.png')
    fg.Loader.newImage(fg.Assets, 'male_light_punch_right', 'resources/male/light_punch_right.png')
    fg.Loader.newImage(fg.Assets, 'male_strong_punch_left', 'resources/male/strong_punch_left.png')
    fg.Loader.newImage(fg.Assets, 'male_strong_punch_left_arm', 'resources/male/strong_punch_left_arm.png')
    fg.Loader.newImage(fg.Assets, 'male_strong_punch_right', 'resources/male/strong_punch_right.png')
    fg.Loader.newImage(fg.Assets, 'male_strong_punch_right_arm', 'resources/male/strong_punch_right_arm.png')
    fg.Loader.newImage(fg.Assets, 'male_head', 'resources/male/head.png')
    fg.Loader.newImage(fg.Assets, 'male_eyes', 'resources/male/eyes.png')
    fg.Loader.newImage(fg.Assets, 'male_mouths', 'resources/male/mouths.png')
    fg.Loader.newImage(fg.Assets, 'male_hairset', 'resources/male/hairset.png')

    fg.Loader.start(function()
        self.finished_loading = true
        self:start()
    end)
end

function Game:screenTransition(transition_type, delay)
    self.screen_transition = TransitionSystem(transition_type, delay) 
end

function Game:changeLevelTo(level_name)
    local previous_area = fg.current_area
    self.levels[fg.current_area]:deactivate()
    self.levels[fg.current_area]:saveFromGame(fg.current_area .. '_GAME')
    fg.world.areas[fg.current_area]:clear()
    fg.world.areas[fg.current_area]:initializePools()
    fg.current_area = level_name
    if love.filesystem.exists('maps/' .. level_name .. '_GAME') then
        self.levels[fg.current_area]:loadFromGame(level_name .. '_GAME', previous_area .. '_GAME')
        self.levels[fg.current_area]:activate()
    else
        self.levels[fg.current_area]:loadFromEditor(level_name, previous_area .. '_GAME')
        self.levels[fg.current_area]:activate()
    end
    fg.world:unpause()
    fg.world:update(0)
    fg.world:pause()
    self.levels[fg.current_area]:movePlayerToDoorPosition(previous_area)
    if not self.first_player then self.first_player = true end
end

function Game:activate()
    if self.first_player then self.first_player = false end
    editor.active = false
    self.levels['Editor']:deactivate()
    for _, map in ipairs(self.all_maps) do fg.world.areas[map]:clear(); fg.world.areas[map]:initializePools(); fg.world.areas[map]:deactivate() end
    fg.current_area = 'Intro'
    fg.world.areas[fg.current_area]:clear()
    fg.world.areas[fg.current_area]:initializePools()
    editor.map_textinput:setText('Intro')
    self.levels[fg.current_area]:loadFromEditor('Intro')
    self.levels[fg.current_area]:activate()
    local tilemap = self.levels[fg.current_area].tilemaps['Default']
    fg.world.camera:moveTo(tilemap.x, tilemap.y)
    for _, layer in ipairs(fg.world.layers_order) do fg.world:activateLayer(layer) end
    love.mouse.setVisible(true)
    if not self.first_player then self.first_player = true end
end

function Game:activateMem()
    if not self.levels['Editor'].last_editor_loaded_map then return end
    if self.first_player then self.first_player = false end
    editor.active = false
    self.levels['Editor']:deactivate()
    for _, map in ipairs(self.all_maps) do fg.world.areas[map]:clear(); fg.world.areas[map]:initializePools(); fg.world.areas[map]:deactivate() end
    fg.current_area = self.levels['Editor'].last_editor_loaded_map
    fg.world.areas[fg.current_area]:clear()
    fg.world.areas[fg.current_area]:initializePools()
    editor.map_textinput:setText(fg.current_area)
    self.levels[fg.current_area]:loadFromEditor(fg.current_area)
    self.levels[fg.current_area]:activate()
    local tilemap = self.levels[fg.current_area].tilemaps['Default']
    fg.world.camera:moveTo(tilemap.x, tilemap.y)
    for _, layer in ipairs(fg.world.layers_order) do fg.world:activateLayer(layer) end
    love.mouse.setVisible(true)
    if not self.first_player then self.first_player = true end
end

return Game
