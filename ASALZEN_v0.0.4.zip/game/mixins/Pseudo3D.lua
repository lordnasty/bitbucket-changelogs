local Pseudo3D = fg.Object:extend('Pseudo3D')

function Pseudo3D:pseudo3DNew(settings)
    local settings = settings or {}
    self.z = settings.settings.z or settings.z or 0
    self.v_z = settings.settings.v_z or settings.v_z or 0
    self.a_z = settings.settings.a_z or 0
    self.z_xy = settings.settings.z_xy or 0
    self.restitution_z = settings.settings.restitution_z or settings.restitution_z or 0
    self.height_z = settings.settings.height_z or settings.height_z or 0
    self.stand = settings.settings.stand or settings.stand or false
    self.stand_z = settings.settings.stand_z or settings.stand_z or 0
    self.disable_z_calculations = settings.settings.disable_z_calculations or false
end

function Pseudo3D:pseudo3DUpdate(dt)
    -- The highest z at position x, y
    self.z_xy = self:pseudo3DGetZXY(self.id, self.x, self.y)

    if not self.disable_z_calculations then
        self.v_z = self.v_z + (self.fg.gravity_z + self.a_z)*dt
        self.z = math.max(self.z - self.v_z*dt, 0)
    end

    if self.z <= self.z_xy then
        -- If restitution is set then reflect object back
        if self.restitution_z > 0 then
            self.v_z = -self.v_z*self.restitution_z
        -- Otherwise ground it
        else
            self.z = self.z_xy
            self.v_z = 0
        end

        if self.body then
            local vx, vy = self.body:getLinearVelocity()
            self.body:setLinearVelocity(0.9*vx, 0.9*vy)
        end
    end
end

function Pseudo3D:pseudo3DDraw()
    if fg.debug_draw then
        love.graphics.setColor(128, 64, 244)
        love.graphics.line(self.x - 8, self.y - self.height_z, self.x + 8, self.y - self.height_z)
        love.graphics.setColor(255, 255, 255)
    end
end

function Pseudo3D:pseudo3DGetZXY(id, x, y)
    local max = 0
    local entities = fg.world.areas[self.fg.current_area]:getAllEntities()
    for _, entity in ipairs(entities) do
        if entity.z and entity.stand then
            if x >= entity.x - entity.w/2 and x <= entity.x + entity.w/2 and 
               y >= entity.y - entity.h/2 and y <= entity.y + entity.h/2 and 
               entity.id ~= id and entity.z + entity.stand_z >= max then 
                max = entity.z + entity.stand_z
            end
        end
    end
    return max
end

function Pseudo3D:pseudo3DPreSolve(other, contact)
    for _, tag in ipairs(fg.classes[self.class_name].pre) do
        if other.tag == tag then
            other_stand_or_height_z = 0
            if other.object.stand then 
                other_stand_or_height_z = other.object.stand_z 
            else other_stand_or_height_z = other.object.height_z end
            if self.z > (other.object.z + other_stand_or_height_z) then 
                contact:setEnabled(false)
            end
        end
    end
end

function Pseudo3D:pseudo3DSave()
    return {
        z = self.z, v_z = self.v_z, a_z = self.a_z, z_xy = self.z_xy, restitution_z = self.restitution_z, 
        height_z = self.height_z, stand = self.stand, stand_z = self.stand_z, disable_z_calculations = self.disable_z_calculations
    }
end

return Pseudo3D
