--
-- classic
--
-- Copyright (c) 2014, rxi
--
-- This module is free software; you can redistribute it and/or modify it under
-- the terms of the MIT license. See LICENSE for details.
--


local Object = {}
Object.__index = Object

function Object:new()

end

function Object:extend(name)
    local cls = {}
    for k, v in pairs(self) do
        if k:find("__") == 1 then
            cls[k] = v
        end
    end
    cls.__index = cls
    cls.super = self
    cls.class_name = name
    setmetatable(cls, self)
    return cls
end

function Object:implement(...)
    for _, cls in pairs({...}) do
        for k, v in pairs(cls) do
            if self[k] == nil and type(v) == "function" then
                self[k] = v
                self[k .. '__callbacks'] = {}
            elseif self[k] and type(v) == "function" then
                if not k:find('__') then
                    table.insert(self[k .. '__callbacks'], v)
                    local f = self[k]
                    self[k] = function(...)
                        f(...)
                        for _, c in ipairs(self[k .. '__callbacks']) do c(...) end
                    end
                end
            end
        end
    end
end

function Object:is(T)
    local mt = getmetatable(self)
    while mt do
        if mt == T then
            return true
        end
        mt = getmetatable(mt)
    end
    return false
end

function Object:__tostring()
    return "Object"
end

function Object:__call(...)
    local obj = setmetatable({}, self)
    obj:new(...)
    return obj
end

return Object
