local EditorObject = fg.Object:extend('EditorObject')
local EditorUITheme = require('editor/EditorUITheme')

function EditorObject:new(editor, x, y, settings)
    self.editor = editor
    self.id = settings.id or fg.getUID()
    self.x, self.y = x, y
    local settings = settings or {}
    for k, v in pairs(settings) do self[k] = v end

    if self.image then 
        self.imager = love.graphics.newImage(self.image)
        self.w, self.h = self.imager:getWidth(), self.imager:getHeight() 
    end
    self.r = settings.r or 0

    self.active = settings.active or false
    self.hot = false
    self.selected = settings.selected or false

    self.selection_rectangle_selected = false
    self.moving = false

    self.rotation_hot = false
    self.rotation_down = false

    self.previous_position = nil
    self.previous_rotation = nil

    self.properties_frame = fg.ui.Frame(self.x, self.y, 300, 45, {theme = EditorUITheme, closeable = true, closed = true, close_button_width = 15, close_button_height = 15})
    local add_button = fg.ui.Button(self.properties_frame.w - 5 - 15, self.properties_frame.h - 5 - 15, 15, 15, {theme = EditorUITheme, font = self.editor.font, text = '+'})
    self.add_button_id = self.properties_frame:addElement(add_button)
    self.textinput_ids = {}

    self.properties = fg.utils.table.copy(settings.properties) or {}
    for k, v in pairs(self.properties) do self:addProperty(k, v) end
    self:addPropertyTextinputs()

    self.properties_frame.closed = false
    self.properties_frame:update(0)
    self.properties_frame.closed = true
end

function EditorObject:update(dt)
    if not self.active then return end
    local x, y = fg.world.camera:getWorldCoords(love.mouse.getPosition())

    if x >= self.x - self.w/2 and x <= self.x + self.w/2 and y >= self.y - self.h/2 and y <= self.y + self.h/2 then
        self.hot = true
    else self.hot = false end

    -- Object hot 
    local px, py = self.x + self.w/2, self.y - self.h/2
    local ox, oy = self.x, self.y
    local rx, ry = ox + math.cos(self.r)*(px - ox) - math.sin(self.r)*(py - oy), oy + math.sin(self.r)*(px - ox) + math.cos(self.r)*(py - oy)
    if x >= rx - 4 and x <= rx + 4 and y >= ry - 4 and y <= ry + 4 then
        self.rotation_hot = true
    else self.rotation_hot = false end

    -- Object mouse rotation
    if self.rotation_hot and self.selected and self.editor.ei:pressed('mouse1') then
        self.previous_rotation = self.r
        self.rotation_down = true
        self.r = fg.Vector(x, y):angleTo(fg.Vector(self.x, self.y)) + math.pi/4
        if self.editor.ei:down('lctrl') then
            for _, object in ipairs(self.editor.objects) do
                if object.selected and object.id ~= self.id then
                    object.previous_rotation = object.r
                end
            end
        end
    end
    if self.rotation_down and self.selected and self.editor.ei:down('mouse1') then
        self.r = fg.Vector(x, y):angleTo(fg.Vector(self.x, self.y)) + math.pi/4
        if self.editor.ei:down('lctrl') then
            for _, object in ipairs(self.editor.objects) do
                if object.selected and object.id ~= self.id then
                    object.r = self.r
                    object.moving = false
                end
            end
        end
    end
    if self.rotation_down and self.selected and self.editor.ei:released('mouse1') then
        self.rotation_down = false
        self.editor:pushObjectState({object = {rotation = {r = self.previous_rotation}, id = self.id}})
        self.previous_rotation = nil
        if self.editor.ei:down('lctrl') then
            for _, object in ipairs(self.editor.objects) do
                if object.selected and object.id ~= self.id then
                    object.editor:pushObjectState({object = {rotation = {r = object.previous_rotation}, id = object.id}})
                    object.previous_rotation = nil
                end
            end
        end
    end

    -- Selection rectangle visual feedback selection
    if self.editor.selection_start then
        if fg.mlib.polygon.isPolygonInside({
            self.editor.selection_start.x, self.editor.selection_start.y, 
            x, self.editor.selection_start.y, x, y, self.editor.selection_start.x, y}, {
            self.x - self.w/2, self.y - self.h/2, self.x + self.w/2, self.y - self.h/2,
            self.x + self.w/2, self.y + self.h/2, self.x - self.w/2, self.y + self.h/2
        }) then
            self.selection_rectangle_selected = true
        else self.selection_rectangle_selected = false end
    end

    -- Selection rectangle
    if self.selection_rectangle_selected and self.editor.ei:released('mouse1') then
        self.selected = true
    end

    -- Unselect
    if not self.editor.selection_start then self.selection_rectangle_selected = false end
    if not self.hot and not self.rotation_hot and self.editor.ei:pressed('mouse1') and not self.editor.ei:down('lctrl') then
        self.selected = false
    end

    -- Move selected
    local mpx, mpy = (game.tile_width/2)*math.floor(x/(game.tile_width/2)), (game.tile_height/2)*math.floor(y/(game.tile_height/2))
    local spx, spy = (game.tile_width/2)*math.floor(self.x/(game.tile_width/2)), (game.tile_height/2)*math.floor(self.y/(game.tile_height/2))
    if self.editor.ei:down('lshift') and self.selected then x, y = mpx, mpy; self.x, self.y = spx, spy end
    if self.selected and (self.hot or self.editor.ei:down('lctrl')) and self.editor.ei:pressed('mouse1') and not self.rotation_down then
        self.moving = fg.Vector(self.x - x, self.y - y)
        self.previous_position = fg.Vector(self.x, self.y)
    end
    if self.selected and self.moving and self.editor.ei:down('mouse1') then
        self.x, self.y = x + self.moving.x, y + self.moving.y
    end
    if self.selected and self.moving and self.editor.ei:released('mouse1') then
        self.moving = false
        self.editor:pushObjectState({object = {position = {x = self.previous_position.x, y = self.previous_position.y}, id = self.id}})
        self.previous_position = nil
    end

    -- Properties
    self.properties_frame.x, self.properties_frame.y = fg.world.camera:getCameraCoords(self.x + self.w/2 + 5, self.y - self.h/2)
    self.properties_frame:update(dt)
    if self.hot and self.editor.ei:pressed('mouse2') then 
        self.selected = true
        fg.timer:after(0.01, function() self.properties_frame.closed = false end)
    elseif not self.selected and not self.properties_frame.selected then self.properties_frame.closed = true end

    -- Add new property space
    local add_button = self.properties_frame:getElement(self.add_button_id)
    if add_button then
        if add_button.pressed then
            self:addPropertySpace()
            self:addPropertyTextinputs()
        end
    end

    self:setProperties()
end

function EditorObject:draw()
    if self.type == 'Object' then
        if self.active then
            self.properties_frame:draw()
            local x, y = fg.world.camera:getCameraCoords(self.x, self.y)
            love.graphics.draw(self.imager, x, y, self.r, fg.screen_scale, fg.screen_scale, self.w/2, self.h/2)
            if self.hot or self.selection_rectangle_selected then
                love.graphics.setColor(128, 160, 160, 160)
                fg.utils.graphics.pushRotateScale(x, y, self.r, fg.screen_scale, fg.screen_scale)
                love.graphics.rectangle('line', x - self.w/2, y - self.h/2, self.w, self.h)
                love.graphics.pop()
                love.graphics.setColor(255, 255, 255, 255)
            end
            if self.selected then
                love.graphics.setColor(188, 222, 222, 222)
                fg.utils.graphics.pushRotateScale(x, y, self.r, fg.screen_scale, fg.screen_scale)
                love.graphics.rectangle('line', x - self.w/2, y - self.h/2, self.w, self.h)
                if self.rotation_hot or self.rotation_down then love.graphics.setColor(128, 188, 188, 255) 
                else love.graphics.setColor(92, 132, 132, 255) end
                love.graphics.circle('fill', x + self.w/2, y - self.h/2, 3)
                love.graphics.setColor(188, 222, 222, 222)
                love.graphics.circle('line', x + self.w/2, y - self.h/2, 3.5)
                love.graphics.setColor(128, 182, 182, 128)
                love.graphics.rectangle('fill', x - self.w/2, y - self.h/2, self.w, self.h)
                love.graphics.pop()
                love.graphics.setColor(255, 255, 255, 255)
            end
        elseif self.being_pasted then
            local mx, my = fg.world.camera:getWorldCoords(self.editor.mp.x, self.editor.mp.y)
            local spx = (game.tile_width/2)*math.floor((mx + self.paste_dx)/(game.tile_width/2))
            local spy = (game.tile_height/2)*math.floor((my + self.paste_dy)/(game.tile_height/2))
            local x, y = fg.world.camera:getCameraCoords(spx, spy)
            love.graphics.setColor(255, 255, 255, 128)
            love.graphics.draw(self.imager, x, y, self.r, fg.screen_scale, fg.screen_scale, self.w/2, self.h/2)
            love.graphics.setLineStyle('rough')
            love.graphics.setColor(128, 128, 128, 32)
            fg.utils.graphics.pushRotateScale(x, y, self.r, fg.screen_scale, fg.screen_scale)
            love.graphics.rectangle('line', x -  self.w/2, y - self.h/2, self.w, self.h)
            love.graphics.pop()
            love.graphics.setColor(255, 255, 255, 255)
        else
            love.graphics.setColor(255, 255, 255, 128)
            love.graphics.draw(self.imager, self.editor.mp.x, self.editor.mp.y, self.r, fg.screen_scale, fg.screen_scale, self.w/2, self.h/2)
            love.graphics.setLineStyle('rough')
            love.graphics.setColor(128, 128, 128, 32)
            fg.utils.graphics.pushRotateScale(self.editor.mp.x, self.editor.mp.y, self.r, fg.screen_scale, fg.screen_scale)
            love.graphics.rectangle('line', self.editor.mp.x - self.w/2, self.editor.mp.y - self.h/2, self.w, self.h)
            love.graphics.pop()
            love.graphics.setColor(255, 255, 255, 255)
        end

    elseif self.type == 'Polyrect' then
        if self.active then
            self.properties_frame:draw()
            love.graphics.setLineStyle('smooth')
            local x1, y1 = fg.world.camera:getCameraCoords(self.x - self.w/2, self.y - self.h/2)
            local xm, ym = fg.world.camera:getCameraCoords(self.x, self.y)
            local x2, y2 = fg.world.camera:getCameraCoords(self.x + self.w/2, self.y + self.h/2)
            love.graphics.setColor(self.color[1], self.color[2], self.color[3], 128)
            fg.utils.graphics.pushRotateScale(xm, ym, self.r, 1, 1)
            love.graphics.rectangle('fill', x1, y1, x2 - x1, y2 - y1)
            love.graphics.pop()
            love.graphics.setColor(255, 255, 255, 255)
            if self.hot or self.selection_rectangle_selected then
                love.graphics.setColor(math.min(self.color[1] + 48, 255), math.min(self.color[2] + 48, 255), math.min(self.color[3] + 48, 255), 160)
                fg.utils.graphics.pushRotateScale(xm, ym, self.r, 1, 1)
                love.graphics.rectangle('line', x1, y1, x2 - x1, y2 - y1)
                love.graphics.pop()
                love.graphics.setColor(255, 255, 255, 255)
            end
            if self.selected then
                love.graphics.setColor(math.min(self.color[1] + 96, 255), math.min(self.color[2] + 96, 255), math.min(self.color[3] + 96, 255), 222)
                fg.utils.graphics.pushRotateScale(xm, ym, self.r, 1, 1)
                love.graphics.rectangle('line', x1, y1, x2 - x1, y2 - y1)
                if self.rotation_hot or self.rotation_down then 
                    love.graphics.setColor(math.min(self.color[1] + 64, 255), math.min(self.color[2] + 64, 255), math.min(self.color[3] + 64, 255), 255)
                else love.graphics.setColor(math.min(self.color[1] + 32, 255), math.min(self.color[2] + 32, 255), math.min(self.color[3] + 32, 255), 255)  end
                love.graphics.circle('fill', x2, y1, 6)
                love.graphics.setColor(math.min(self.color[1] + 96, 255), math.min(self.color[2] + 96, 255), math.min(self.color[3] + 96, 255), 222)
                love.graphics.circle('line', x2, y1, 7)
                love.graphics.setColor(math.min(self.color[1] + 32, 255), math.min(self.color[2] + 32, 255), math.min(self.color[3] + 32, 255), 128)
                love.graphics.rectangle('fill', x1, y1, x2 - x1, y2 - y1)
                love.graphics.pop()
                love.graphics.setColor(255, 255, 255, 255)
            end
        elseif self.being_pasted then
            local mx, my = fg.world.camera:getWorldCoords(self.editor.mp.x, self.editor.mp.y)
            local spx = (game.tile_width/2)*math.floor((mx + self.paste_dx)/(game.tile_width/2))
            local spy = (game.tile_height/2)*math.floor((my + self.paste_dy)/(game.tile_height/2))
            local x, y = fg.world.camera:getCameraCoords(spx, spy)
            --local x1, y1 = fg.world.camera:getCameraCoords(self.x - self.w/2, self.y - self.h/2)
            --local x2, y2 = fg.world.camera:getCameraCoords(self.x + self.w/2, self.y + self.h/2)
            local xm, ym = fg.world.camera:getCameraCoords(spx + self.w/2, spy + self.h/2)
            local xw, yh = fg.world.camera:getCameraCoords(spx + self.w, spy + self.h)
            love.graphics.setColor(self.color[1] + 32, self.color[2] + 32, self.color[3] + 32, 128)
            fg.utils.graphics.pushRotateScale(xm, ym, self.r, 1, 1)
            love.graphics.rectangle('fill', x, y, xw - x, yh - y)
            love.graphics.setLineStyle('rough')
            love.graphics.setColor(self.color[1], self.color[2], self.color[3], 32)
            love.graphics.rectangle('line', x, y, xw - x, yh - y)
            love.graphics.pop()
            love.graphics.setColor(255, 255, 255, 128)
        else
            love.graphics.setColor(self.color[1], self.color[2], self.color[3], 128)
            love.graphics.setLineStyle('rough')
            love.graphics.rectangle('line', self.editor.mp.x - 4, self.editor.mp.y - 4, 8, 8)
            love.graphics.setColor(255, 255, 255, 255)
        end

    elseif self.type == 'Polygon' then
        if self.active then
            self.properties_frame:draw()
            love.graphics.setLineStyle('smooth')
            local x1, y1 = fg.world.camera:getCameraCoords(self.x - self.w/2, self.y - self.h/2)
            local xm, ym = fg.world.camera:getCameraCoords(self.x, self.y)
            local x2, y2 = fg.world.camera:getCameraCoords(self.x + self.w/2, self.y + self.h/2)
            love.graphics.setColor(self.color[1], self.color[2], self.color[3], 128)
            fg.utils.graphics.pushRotateScale(xm, ym, self.r, 1, 1)
            love.graphics.rectangle('line', x1, y1, x2 - x1, y2 - y1)
            love.graphics.pop()
            love.graphics.setColor(255, 255, 255, 255)

            love.graphics.setColor(self.color[1], self.color[2], self.color[3], 128)
            local vertices = fg.fn.flatten(love.math.triangulate(fg.fn.map(self.vertices, function(i, v)
                if i % 2 == 1 then return self.x + v
                elseif i % 2 == 0 then return self.y + v end
            end)))
            for i = 1, #vertices, 2 do vertices[i], vertices[i+1] = fg.world.camera:getCameraCoords(vertices[i], vertices[i+1]) end
            love.graphics.polygon('fill', vertices)

            love.graphics.setColor(self.color[1]+32, self.color[2]+32, self.color[3]+32, 160)
            love.graphics.polygon('line', vertices)
            
            for i = 1, #self.vertices, 2 do
                local x, y = fg.world.camera:getCameraCoords(self.x + self.vertices[i], self.y + self.vertices[i+1])
                love.graphics.setColor(self.color[1], self.color[2], self.color[3], 128)
                love.graphics.circle('fill', x, y, 5)
                love.graphics.setColor(self.color[1], self.color[2], self.color[3], 222)
                love.graphics.circle('line', x, y, 5)
            end

            love.graphics.setColor(255, 255, 255, 255)

        elseif self.being_pasted then

        else
            love.graphics.setColor(self.color[1], self.color[2], self.color[3], 128)
            love.graphics.setLineStyle('rough')
            love.graphics.circle('line', self.editor.mp.x, self.editor.mp.y, 5)
            love.graphics.setColor(255, 255, 255, 255)
        end
    end
end

function EditorObject:addPropertySpace()
    self.properties_frame.h = self.properties_frame.h + 40
end

function EditorObject:addPropertyTextinputs()
    local position = #self.textinput_ids/2 + 1
    local settings = {theme = EditorUITheme, font = self.editor.font, text_margin = 8, text_max_length = 13}
    local textinput_left = fg.ui.Textinput(5, 5 + (position-1)*40, 130, 35, settings)
    local textinput_right = fg.ui.Textinput(140, 5 + (position-1)*40, 130, 35, settings)
    table.insert(self.textinput_ids, self.properties_frame:addElement(textinput_left))
    table.insert(self.textinput_ids, self.properties_frame:addElement(textinput_right))
end

function EditorObject:addProperty(property, value)
    self:addPropertyTextinputs()
    self.properties_frame:getElement(self.textinput_ids[#self.textinput_ids-1]):setText(property)
    self.properties_frame:getElement(self.textinput_ids[#self.textinput_ids]):setText(value)
    self:addPropertySpace()
end

function EditorObject:getProperties()
    local properties = {}
    for i = 1, #self.textinput_ids, 2 do
        local property = self.properties_frame:getElement(self.textinput_ids[i]).text
        local value = self.properties_frame:getElement(self.textinput_ids[i+1]).text
        properties[property] = value
    end
    return properties
end

function EditorObject:setProperties()
    self.properties = {}
    for i = 1, #self.textinput_ids, 2 do
        local property = self.properties_frame:getElement(self.textinput_ids[i]).text
        local value = self.properties_frame:getElement(self.textinput_ids[i+1]).text
        if property ~= '' or value ~= '' then 
            self.properties[property] = value
        end
    end
end

return EditorObject
