local StonePlant = fg.Class('StonePlant', 'Entity')

StonePlant.layer = 'Front_1'

function StonePlant:new(area, x, y, settings)
    local settings = settings or {}
    StonePlant.super.new(self, area, x, y, settings)
    self.stone_plant_visual = self.fg.Assets.stone_plant
end

function StonePlant:update(dt)

end

function StonePlant:draw()
    local w, h = self.stone_plant_visual:getWidth(), self.stone_plant_visual:getHeight()
    love.graphics.draw(self.stone_plant_visual, self.x, self.y, self.r or 0, 1, 1, w/2, h/2)
end

function StonePlant:save()
    return {id = self.id, x = self.x, y = self.y, n = self.n, r = self.r}
end

return StonePlant
