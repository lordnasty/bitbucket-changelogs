local Vine = fg.Class('Vine', 'Entity')

Vine.layer = 'Front_1'

function Vine:new(area, x, y, settings)
    local settings = settings or {}
    Vine.super.new(self, area, x, y, settings)
    local n = settings.n or math.random(0, 2)
    self.vine_visual = self.fg.Assets.vines
    self.vine_quad = love.graphics.newQuad(32*n, 0, 32, 32, 96, 32)
end

function Vine:update(dt)

end

function Vine:draw()
    love.graphics.draw(self.vine_visual, self.vine_quad, self.x, self.y, self.r or 0, 1, 1, 16, 16)
end

function Vine:save()
    return {id = self.id, x = self.x, y = self.y, n = self.n, r = self.r}
end

return Vine
