local ExplosionEffect = fg.Class('ExplosionEffect', 'Entity')

ExplosionEffect.ignores = {'All', except = {'Solid'}}
ExplosionEffect.layer = 'Effects_Front'

function ExplosionEffect:new(area, x, y, settings)
    local settings = settings or {}
    ExplosionEffect.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    local u = self.fg.utils

    self.timer:after(self.explosion_delay or 0, function()
        -- White explosion circle
        self.pre_explosion_white = true
        self.pre_explosion_radius = 1
        self.timer:tween(0.1, self, {pre_explosion_radius = self.explosion_radius or u.math.random(24, 36)}, 'in-out-cubic')

        -- Turn to black
        self.timer:after(0.1, function()
            self.area.world.camera:shake(2, 0.2)
            self.pre_explosion_white = false
            self.pre_explosion_black = true
            self.timer:tween(0.15, self, {pre_explosion_radius = 1}, 'in-out-cubic')
            self.timer:after(0.15, function() self.pre_explosion_black = false end)
        end)

        -- Initial flashes
        local r = self.explosion_radius or 18
        for i = 1, math.random(8, 12) do
            self.timer:after(u.math.random(0.2, 0.3), function()
                local x, y = u.math.randomCircle(self.x, self.y, r)
                self.area:createEntity('AnimatedEffect', x, y, {r = u.math.random(0, 2*math.pi), v = u.math.random(0, 20), type = 'explosion_flash_1'})
            end)
            self.timer:after(self.fg.utils.math.random(0.1, 0.3), function()
                local x, y = u.math.randomCircle(self.x, self.y, r)
                self.area:createEntity('AnimatedEffect', x, y, {r = u.math.random(0, 2*math.pi), v = u.math.random(0, 20), 
                                       type = u.table.random({'explosion_flash_2', 'explosion_flash_3', 'explosion_flash_4'})})
            end)
        end

        -- Directional
        for i = 1, math.random(6, 10) do
            self.timer:after(0.2, function()
                local x, y = u.math.randomCircle(self.x, self.y, r)
                local angle = self.fg.Vector(x - self.x, y - self.y):angle()
                self.area:createEntity('ExplosionParticle', x, y, {r = angle, v = u.math.random(-150, 150)})
            end)
        end
    end)
end

function ExplosionEffect:update(dt)
    self.timer:update(dt)
end

function ExplosionEffect:draw()
    if self.pre_explosion_white then
        love.graphics.setColor(255, 255, 255, 255)
        love.graphics.circle('fill', self.x, self.y, self.pre_explosion_radius, 36)
        love.graphics.setColor(255, 255, 255, 16)
        love.graphics.circle('fill', self.x, self.y, 2*self.pre_explosion_radius, 36)
    elseif self.pre_explosion_black then
        love.graphics.setColor(0, 0, 0, 255)
        love.graphics.circle('fill', self.x, self.y, self.pre_explosion_radius, 36)
    end
    love.graphics.setColor(255, 255, 255, 255)
end

return ExplosionEffect
