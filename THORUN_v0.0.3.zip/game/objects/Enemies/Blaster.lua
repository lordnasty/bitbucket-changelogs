local Blaster = fg.Class('Blaster', 'Entity')
Blaster:implement(fg.PhysicsBody)
Blaster:implement(Animated)
Blaster:implement(Hittable)
Blaster:implement(Steerable)

Blaster.ignores = {'Player'}

function Blaster:new(area, x, y, settings)
    local settings = settings or {}
    settings.w, settings.h = 16, 28
    Blaster.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    self:physicsBodyNew(area, x, y, settings)
    self:animatedNew({animations = self.fg.blaster_animations, settings = settings})
    self:steerableNew({settings = settings})
    self:hittableNew({settings = settings})

    self.body:setGravityScale(0)
    self.animation_state = 'move'
end

function Blaster:update(dt)
    self.timer:update(dt)
    self:physicsBodyUpdate(dt)
    self:animatedUpdate(dt)
    self:steerableUpdate(dt)

    -- Animation
    self.animation_state = 'idle'
    if self.hit then self.animation_state = 'hurt' end
end

function Blaster:draw()
    self:physicsBodyDraw()
    self:animatedDraw()
end

function Blaster:save()
    local animated = self:animatedSave()
    local steerable = self:steerableSave()
    local hittable = self:hittableSave()
    local save_data = {}
    for k, v in pairs(animated) do save_data[k] = v end
    for k, v in pairs(steerable) do save_data[k] = v end
    for k, v in pairs(hittable) do save_data[k] = v end
    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y
    save_data.w, save_data.h = self.w, self.h
    save_data.shape = 'Rectangle'
    return save_data
end

return Blaster
