C2DMatrix = require 'game/mixins/Steerable/C2DMatrix'

function pointToWorldSpace(point, heading, side, position)
    local trans_point = fg.Vector(point.x, point.y)
    local mat_transform = C2DMatrix()
    mat_transform:rotate(heading, side)
    mat_transform:translate(position.x, position.y)
    mat_transform:transformVector2Ds(trans_point)
    return trans_point
end

function pointToLocalSpace(point, heading, side, position)
    local trans_point = fg.Vector(point.x, point.y)
    local mat_transform = C2DMatrix()
    local tx, ty = -position:dot(heading), -position:dot(side)
    mat_transform._11 = heading.x; mat_transform._12 = side.x;
    mat_transform._21 = heading.y; mat_transform._22 = side.y;
    mat_transform._31 = tx;        mat_transform._32 = ty;
    mat_transform:transformVector2Ds(trans_point)
    return trans_point
end

function vectorToWorldSpace(vec, heading, side)
    local trans_vec = fg.Vector(vec.x, vec.y)
    local mat_transform = C2DMatrix()
    mat_transform:rotate(heading, side)
    mat_transform:transformVector2Ds(trans_vec)
    return trans_vec
end

function vec2DRotateAroundOrigin(vec, ang)
    local mat = C2DMatrix()
    mat:rotateR(ang)
    mat:transformVector2Ds(vec)
    return vec
end
