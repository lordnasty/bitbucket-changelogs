local PersonMovement = fg.Object:extend('PersonMovement')

function PersonMovement:personMovementNew(settings)
    local settings = settings or {}
    self.init_max_v = settings.settings.init_max_v or 100
    self.max_v = settings.settings.max_v or self.init_max_v
    self.init_a = settings.settings.init_a or 1000
    self.a = settings.settings.a or self.init_a
    if settings.settings.v then self.v = self.fg.Vector(settings.settings.v.x, settings.settings.v.y)
    else self.v = self.fg.Vector(0, 0) end
    if settings.settings.push_v then self.push_v = self.fg.Vector(settings.settings.push_v.x, settings.settings.push_v.y)
    else self.push_v = self.fg.Vector(0, 0) end
    self.moving = settings.settings.moving or {left = false, right = false}
    self.direction = settings.settings.direction or 'right'
    self.damping = settings.settings.damping or 0.8
    for _, key_action in ipairs(settings.keys) do 
        self.fg.input:bind(key_action[1], key_action[2]) 
    end
end

function PersonMovement:personMovementUpdate(dt)
    local vx, vy = self.body:getLinearVelocity()

    if not self.melee_attack_movement_locked then
        if self.fg.input:down('moveLeft') then self:moveLeft() end
        if self.fg.input:down('moveRight') then self:moveRight() end
    end

    if self.moving.left then
        self.v.x = math.max(self.v.x - self.a*dt, -self.max_v)
        self.direction = 'left'
    end

    if self.moving.right then
        self.v.x = math.min(self.v.x + self.a*dt, self.max_v)
        self.direction = 'right'
    end

    if not self.moving.right and not self.moving.left then
        self.v.x = self.v.x*self.damping
        if math.abs(self.v.x) < 24 then self.v.x = 0 end
    end

    self.body:setLinearVelocity(self.v.x + self.push_v.x, vy + self.push_v.y)

    self.moving.left = false
    self.moving.right = false
end

function PersonMovement:personMovementDraw()

end

function PersonMovement:moveLeft()
    self.moving.left = true
end

function PersonMovement:moveRight()
    self.moving.right = true
end

function PersonMovement:personMovementSave()
    return {
        init_max_v = self.init_max_v, max_v = self.max_v, init_a = self.init_a, a = self.a, v = {x = self.v.x, y = self.v.y},
        push_v = {x = self.push_v.x, y = self.push_v.y}, direction = self.direction, damping = self.damping, moving = self.moving,
    }
end

return PersonMovement
