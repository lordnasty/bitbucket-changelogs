local Notifier = fg.Object:extend('Notifier')
local EditorNotification = require 'editor/EditorNotification'

function Notifier:notifierNew(settings)
    local settings = settings or {}

    self.notifications = {}
end

function Notifier:notifierUpdate(dt)
    for i = #self.notifications, 1, -1 do
        self.notifications[i]:update(dt)
        if self.notifications[i].dead then
            table.remove(self.notifications, i)
        end
    end
end

function Notifier:notifierDraw()
    love.graphics.setFont(self.font)
    for _, notification in ipairs(self.notifications) do
        notification:draw()
    end
end

function Notifier:addNotification(notification_str)
    for i, notification in ipairs(self.notifications) do notification:pushUp(i) end
    local w = self.font:getWidth(notification_str)
    table.insert(self.notifications, EditorNotification(self, love.window.getWidth() - (w + 20), love.window.getHeight() - 10, notification_str))
end

return Notifier
