local PersonMovement = fg.Object:extend('PersonMovement')

function PersonMovement:personMovementNew(settings)
    local settings = settings or {}
    self.init_max_v = settings.settings.init_max_v or 100
    self.max_v = settings.settings.max_v or self.init_max_v
    self.init_a = settings.settings.init_a or 1000
    self.a = settings.settings.a or self.init_a
    if settings.settings.v then self.v = self.fg.Vector(settings.settings.v.x, settings.settings.v.y)
    else self.v = self.fg.Vector(0, 0) end
    if settings.settings.push_v then self.push_v = self.fg.Vector(settings.settings.push_v.x, settings.settings.push_v.y)
    else self.push_v = self.fg.Vector(0, 0) end
    self.push_v_damping = settings.settings.push_v_damping or false
    self.direction = settings.settings.direction or 'right'
    self.push_damping = settings.settings.push_damping or 0.9
    self.damping = settings.settings.damping or 0.8
    self.move_angle = settings.settings.move_angle or 0
    self.moving = settings.settings.moving or {left = false, right = false, up = false, down = false}
    self.dashing = settings.settings.dashing or false
    self.movement_locked = settings.settings.movement_locked or false
    for _, key_action in ipairs(settings.keys) do self.fg.input:bind(key_action[1], key_action[2]) end
end

function PersonMovement:personMovementUpdate(dt)
    -- If being pushed then ignore Movement calculations
    if math.abs(self.push_v.x) > 0 or math.abs(self.push_v.y) > 0 then
        if self.push_v_damping then self.push_v = self.push_v*0.9 end
        self.body:setLinearVelocity(self.push_v.x, self.push_v.y)
        return
    end

    if not self.melee_attack_movement_locked and not self.movement_locked then
        if self.fg.input:down('moveLeft') then self:moveLeft() end
        if self.fg.input:down('moveRight') then self:moveRight() end
        if self.fg.input:down('moveUp') then self:moveUp() end
        if self.fg.input:down('moveDown') then self:moveDown() end
        local x = self.fg.input:down('moveHorizontal')
        local y = self.fg.input:down('moveVertical')
        if x and y then
            if x <= -0.5 then self:moveLeft() end
            if x >= 0.5 then self:moveRight() end
            if y <= -0.5 then self:moveUp() end
            if y >= 0.5 then self:moveDown() end
        end
    end

    if self.moving.left then self.move_angle = math.pi end
    if self.moving.right then self.move_angle = 0 end
    if self.moving.up then self.move_angle = 3*math.pi/2 end
    if self.moving.down then self.move_angle = math.pi/2 end
    -- Account for diagonal movement
    if self.moving.left and self.moving.up then self.move_angle = 5*math.pi/4 end
    if self.moving.left and self.moving.down then self.move_angle = 3*math.pi/4 end
    if self.moving.right and self.moving.up then self.move_angle = 7*math.pi/4 end
    if self.moving.right and self.moving.down then self.move_angle = 1*math.pi/4 end

    if self.moving.left or self.moving.right or self.moving.up or self.moving.down then
        self.v.x = self.v.x + self.a*math.cos(self.move_angle)*dt
        self.v.y = self.v.y + self.a*math.sin(self.move_angle)*dt
        self.direction = self.fg.utils.angleToDirection4(self.move_angle)
    end

    -- Manual damping for the entity to stop moving
    -- box2d's damping is another option
    if not self.moving.left and not self.moving.right then
        self.v.x = self.v.x*self.damping
    end
    if not self.moving.up and not self.moving.down then
        self.v.y = self.v.y*self.damping
    end

    --[[
    -- push_v damping
    if self.push_v_damping then
        self.push_v.x = self.push_v.x*self.push_damping
        self.push_v.y = self.push_v.y*self.push_damping
    end
    ]]--

    -- Limit to max_v
    if self.v.x < -self.max_v then self.v.x = self.max_v*math.cos(self.move_angle) end
    if self.v.x > self.max_v then self.v.x = self.max_v*math.cos(self.move_angle) end
    if self.v.y < -self.max_v then self.v.y = self.max_v*math.sin(self.move_angle) end
    if self.v.y > self.max_v then self.v.y = self.max_v*math.sin(self.move_angle) end

    -- Set final velocity
    self.body:setLinearVelocity(self.v.x, self.v.y)

    -- Stop all movement at the end of the frame so that they don't carry over to the next
    self.moving.left = false
    self.moving.right = false
    self.moving.up = false
    self.moving.down = false
end

function PersonMovement:moveLeft()
    self.moving.left = true
end

function PersonMovement:moveRight()
    self.moving.right = true
end

function PersonMovement:moveUp()
    self.moving.up = true
end

function PersonMovement:moveDown()
    self.moving.down = true
end

function PersonMovement:push(fx, fy, duration)
    local t1 = (-self.v_z + math.sqrt(self.v_z*self.v_z + 2*self.fg.gravity_z*self.z))/self.fg.gravity_z
    local t2 = (-self.v_z - math.sqrt(self.v_z*self.v_z + 2*self.fg.gravity_z*self.z))/self.fg.gravity_z
    local t = duration or math.max(t1, t2)
    self.timer:during('pushing', t, function() self.push_v.x = fx; self.push_v.y = fy end)
    self.timer:after('pushing_after', t, function()
        self.push_v_damping = true 
        self.timer:after('pushing_damp', 1, function() 
            self.push_v_damping = false 
            self.push_v.x = 0
            self.push_v.y = 0
        end)
    end)
end

function PersonMovement:personMovementSave()
    return {
        init_max_v = self.init_max_v, max_v = self.max_v, init_a = self.init_a, a = self.a, v = {x = self.v.x, y = self.v.y},
        push_v = {x = self.push_v.x, y = self.push_v.y}, push_v_damping = self.push_v_damping, direction = self.direction,
        push_damping = self.push_damping, damping = self.damping, move_angle = self.move_angle, dashing = self.dashing, moving = self.moving,
        movement_locked = self.movement_locked
    }
end

return PersonMovement
