local Bucket = fg.Class('Bucket', 'Entity')
Bucket:implement(fg.PhysicsBody)
Bucket:implement(Pseudo3D)

function Bucket:new(area, x, y, settings)
    local settings = settings or {}
    self.filled = settings.filled
    settings.w, settings.h = 10, 6
    self.bucket_shadow = love.graphics.newQuad(32, 0, 16, 16, 48, 16)
    if self.filled then self.bucket_quad = love.graphics.newQuad(16, 0, 16, 16, 48, 16)
    else self.bucket_quad = love.graphics.newQuad(0, 0, 16, 16, 48, 16) end
    Bucket.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    self.bucket_visual = self.fg.Assets.bucket
    self:physicsBodyNew(area, x, y, settings)
    self:pseudo3DNew({height_z = 6, settings = settings})
end

function Bucket:update(dt)
    self.timer:update(dt)
    self:physicsBodyUpdate(dt)
    self:pseudo3DUpdate(dt)
end

function Bucket:draw()
    local w, h = 16, 16
    -- Shadow
    love.graphics.setColor(255, 255, 255, 128)
    love.graphics.draw(self.bucket_visual, self.bucket_shadow, self.x - w/2, self.y - h/2 - 3)
    love.graphics.setColor(255, 255, 255, 255)
    -- Bucket
    love.graphics.draw(self.bucket_visual, self.bucket_quad, self.x - w/2, self.y - h/2 - 4)
    self:physicsBodyDraw()
    self:pseudo3DDraw()
end

function Bucket:highlightDraw()
    local w, h = 16, 16
    love.graphics.draw(self.bucket_visual, self.bucket_quad, self.x - w/2, self.y - h/2 - 4)
end

function Bucket:save()
    local pseudo_3d = self:pseudo3DSave()
    local save_data = {}
    for k, v in pairs(pseudo_3d) do save_data[k] = v end
    save_data.filled = self.filled
    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y
    save_data.w, save_data.h = self.w, self.h
    save_data.shape = 'Rectangle'
    return save_data
end

return Bucket
