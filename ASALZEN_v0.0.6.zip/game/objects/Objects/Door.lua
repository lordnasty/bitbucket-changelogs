local Door = fg.Class('Door', 'Entity')
Door:implement(fg.PhysicsBody)

function Door:new(area, x, y, settings)
    local settings = settings or {}
    settings.w, settings.h = 96, 32
    settings.body_type = 'static'
    Door.super.new(self, area, x, y, settings)
    self:physicsBodyNew(area, x, y + 32, settings)
    self.timer = self.fg.Timer()

    self.highlighted = false
    self.target_level = settings.target_level or 'StartArea'
    self.open = settings.open or false
    self.opening = settings.opening or false
    self.closing = settings.closing or false
    self.door_opened = self.fg.Assets.door_opened
    self.door_closed = self.fg.Assets.door_closed
    self.door_open = self.fg.Animation(self.fg.Assets.door_open, 96, 96, 0.08)
    self.door_open:setMode('once')
    self.door_close = self.fg.Animation(self.fg.Assets.door_close, 96, 96, 0.08)
    self.door_close:setMode('once')

    if self.open then self:closeDoor() end
end

function Door:update(dt)
    self.timer:update(dt)
    self:physicsBodyUpdate(dt)
    if self.opening then self.door_open:update(dt) end
    if self.closing then self.door_close:update(dt) end
end

function Door:draw()
    self:physicsBodyDraw(192, 64, 192)
    if not self.open and not self.closing and not self.opening then love.graphics.draw(self.door_closed, self.x - 48, self.y - 48 - 32) end
    if self.open and not self.closing and not self.opening then love.graphics.draw(self.door_opened, self.x - 48, self.y - 48 - 32) end
    if self.opening then self.door_open:draw(self.x - 48, self.y - 48 - 32) end
    if self.closing then self.door_close:draw(self.x - 48, self.y - 48 - 32) end
    if self.highlighted then
        love.graphics.setLineStyle('rough')
        love.graphics.setColor(192, 32, 32)
        love.graphics.rectangle('line', self.x - 48 + 12, self.y - 48 - 32 + 16, 72, 80)
        love.graphics.setColor(255, 255, 255)
    end
end

function Door:changeDoorState()
    if self.opening or self.closing then return end
    if self.open then self:closeDoor()
    else self:openDoor() end
    self.timer:after('change_state', 0.5, function() game.levels[self.area.name]:changeLevelTo(self.target_level, 0.5) end)
end

function Door:openDoor()
    self.door_open:play()
    self.closing = false
    self.opening = true
    self.timer:after('open', 0.4, function() 
        self.door_open:reset()
        self.open = true
        self.opening = false 
    end)
end

function Door:closeDoor()
    self.door_close:play()
    self.opening = false
    self.closing = true
    self.timer:after('close', 0.4, function() 
        self.door_close:reset()
        self.open = false
        self.closing = false 
    end)
end

function Door:save()
    return {
        id = self.id, target_level = self.target_level, open = self.open,
        body_type = 'static', w = self.w, h = self.h, x = self.x, y = self.y - 32,
    }
end

return Door 
