local StarHitEffect = fg.Class('StarHitEffect', 'Entity')

StarHitEffect.layer = 'Effects_Outlined'

function StarHitEffect:new(area, x, y, settings)
    local settings = settings or {}
    StarHitEffect.super.new(self, area, x, y, settings)

    self.timer = self.fg.Timer()
    self.star_visual = self.fg.Assets.icons_strip8
    self.star_quad = love.graphics.newQuad(0, 0, 16, 16, self.star_visual:getWidth(), self.star_visual:getHeight())
    self.sx, self.sy = 0, 0
    self.r = self.fg.utils.math.random(-4*math.pi, 4*math.pi)
    self.timer:tween({0.3, 0.8}, self, {r = self.fg.utils.math.random(-math.pi, math.pi)}, 'in-out-cubic')
    self.timer:tween({0.3, 0.8}, self, {v = 0}, 'in-out-cubic')
    self.timer:tween(0.25, self, {sx = 0.9, sy = 0.9}, 'in-out-cubic', function()
        self.timer:after(0.2, function()
            self.timer:tween(0.2, self, {sx = 0, sy = 0}, 'in-out-cubic', function() self.dead = true end)
        end)
    end)
end

function StarHitEffect:update(dt)
    self.timer:update(dt)
    self.x, self.y = self.x + self.v*math.cos(self.angle)*dt, self.y + self.v*math.sin(self.angle)*dt 
end

function StarHitEffect:draw()
    love.graphics.setColor(238, 238, 72)
    love.graphics.draw(self.star_visual, self.star_quad, self.parent.x + self.offset_x + self.x, self.parent.y + self.offset_y + self.y, self.r, self.sx, self.sy, 8, 8)
    love.graphics.setColor(255, 255, 255)
end

return StarHitEffect
