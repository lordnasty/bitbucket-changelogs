local SweatDrop = fg.Class('SweatDrop', 'Entity')

SweatDrop.layer = 'Effects'

function SweatDrop:new(area, x, y, settings)
    local settings = settings or {}
    SweatDrop.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    self.sweatdrop = self.fg.Assets.sweatdrop
    self.sx, self.sy = 0, 0
    self.y_drop = 0
    self.timer:tween(0.2, self, {sx = 0.9, sy = 0.9}, 'linear')
    self.timer:tween(1.5, self, {y_drop = 9}, 'out-expo')
end

function SweatDrop:update(dt)
    self.timer:update(dt)
    if self.parent then 
        if not self.parent.vulnerable_to_attack or self.parent.hit then self.dead = true end 
        local dx = 1 if self.parent.direction == 'left' then dx = -1 end
        self.x, self.y = self.parent.x + (dx*self.x_offset or 0), self.parent.y + (self.y_offset or 0)
    end
end

function SweatDrop:draw()
    local w, h = self.sweatdrop:getWidth(), self.sweatdrop:getHeight()
    love.graphics.draw(self.sweatdrop, self.x, self.y + self.y_drop, 0, self.sx, self.sy, w/2, h/2)
end

return SweatDrop
