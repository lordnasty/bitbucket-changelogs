local BloodPool = fg.Class('BloodPool', 'Entity')

BloodPool.pool_enabled = 200 
BloodPool.pool_overflow_rule = 'distance'

function BloodPool:new(area, x, y, settings)
    local settings = settings or {}
    BloodPool.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()

    self.w, self.h = settings.w or 32, settings.h or 32
    self:construct(settings)
end

function BloodPool:update(dt)
    self.timer:update(dt)
    self.fg.Spritebatches['Blood'].spritebatch:add(self.blood_quad, self.x, self.y, self.angle,
                                                   self.sx, self.sy, self.w/2, self.h/2)
end

function BloodPool:draw()

end

function BloodPool:reset(x, y, settings)
    self.x, self.y = x, y
    self:construct(settings)
end

function BloodPool:construct(settings)
    local settings = settings or {}
    self.v = settings.v or {x = 0, y = 0}
    self.angle = settings.angle or 0
    
    -- Spray
    if math.abs(self.v.x) > 200 or math.abs(self.v.y) > 200 then
        self.sx = 1
        self.sy = 1 
        self.blood_quad = love.graphics.newQuad(math.random(0, 3)*32, 0, 32, 32, 
                                                self.fg.Assets.blood:getWidth(), 
                                                self.fg.Assets.blood:getHeight())
        self.timer:cancel('pool_up')
    -- Pool
    else 
        self.sx = 0.2
        self.sy = 0.2
        self.blood_quad = love.graphics.newQuad(math.random(0, 3)*32, 32, 32, 32, 
                                                self.fg.Assets.blood:getWidth(),
                                                self.fg.Assets.blood:getHeight()) 
        self.timer:tween('pool_up', self.fg.utils.math.random(settings.pool_tween_min_time or 0.1, 
                         settings.pool_tween_max_time or 0.3), self, {sx = settings.sx or 1, 
                         sy = settings.sy or 1}, 'in-out-cubic')
    end
end

function BloodPool:save()
    return {
        id = self.id, x = self.x, y = self.y, angle = self.angle, v = self.v,
        sx = self.sx, sy = self.sy, w = self.w, h = self.h, 
    }
end

return BloodPool
