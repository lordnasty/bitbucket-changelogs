local Timer = Decorator:extend('Timer')

function Timer:new(name, behavior)
    Timer.super.new(self, name, behavior)
    self.ready_to_run = false
end

function Timer:update(dt, context)
    return Timer.super.update(self, dt, context)
end

function Timer:run(dt, context)
    if self.ready_to_run then
        local status = self.behavior:update(dt, context)
        return status
    else return 'running' end
end

function Timer:start(context)
    self.ready_to_run = false
    mg.timer:after(5, function() self.ready_to_run = true end)
end

function Timer:finish(status, context)
    self.ready_to_run = false
end

return Timer
