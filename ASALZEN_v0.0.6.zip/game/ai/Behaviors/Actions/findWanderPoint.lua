local findWanderPoint = Action:extend('findWanderPoint')

function findWanderPoint:new(x, y, radius)
    findWanderPoint.super.new(self, 'findWanderPoint')

    self.x = x
    self.y = y
    self.radius = radius
end

function findWanderPoint:update(dt, context)
    return findWanderPoint.super.update(self, dt, context)
end

function findWanderPoint:run(dt, context)
    local angle = mg.utils.math.random(0, 2*math.pi)
    local distance = mg.utils.math.random(0, self.radius)
    context.move_to_point_target = mg.Vector(self.x + distance*math.cos(angle), self.y + distance*math.sin(angle))
    return 'success'
end

function findWanderPoint:start(context)

end

function findWanderPoint:finish(status, context)

end

return findWanderPoint
