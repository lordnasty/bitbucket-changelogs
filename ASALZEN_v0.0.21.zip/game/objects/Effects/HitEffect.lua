local HitEffect = fg.Class('HitEffect', 'Entity')

HitEffect.layer = 'Effects'

function HitEffect:new(area, x, y, settings)
    HitEffect.super.new(self, area, x, y, settings)

    self.timer = self.fg.Timer()
    self.animation = self.fg.Animation(self.fg.Assets.hit_effect, 64, 64, 0.09)
    self.animation:setMode('once')
    self.timer:after(self.animation.delay*self.animation.size, function() self.dead = true end)
end

function HitEffect:update(dt)
    self.timer:update(dt)
    self.animation:update(dt)
end

function HitEffect:draw()
    love.graphics.setShader(self.fg.Shaders.combine)
    love.graphics.setColor(160, 160, 160)
    self.animation:draw(self.x, self.y, 0, 1, 1, 32, 32)
    love.graphics.setShader()
    love.graphics.setColor(255, 255, 255)
end

return HitEffect
