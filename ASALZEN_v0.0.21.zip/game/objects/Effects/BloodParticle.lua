local BloodParticle = fg.Class('BloodParticle', 'Entity')
BloodParticle:implement(Pseudo3D)
BloodParticle:implement(Shadow)

function BloodParticle:new(area, x, y, settings)
    BloodParticle.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    self:pseudo3DNew({settings = settings})

    self.v = settings.v or self.fg.Vector(0, 0)
    self.w, self.h = 4, 4
    self.shadow_width, self.shadow_height = 6, 6
    self.blood_particle = self.fg.Assets.blood_particle
end

function BloodParticle:update(dt)
    self.timer:update(dt)
    self:pseudo3DUpdate(dt)

    self.x = self.x + self.v.x*dt
    self.y = self.y + self.v.y*dt

    if self.z <= 0 then
        self.dead = true
        self.area:createEntity('BloodPool', self.x, self.y, 
                              {v = self.fg.Vector(self.v.x, self.v.y), 
                               angle = self.fg.Vector(self.x, self.y):angleTo(
                               self.fg.Vector(self.x - self.v.x, self.y - self.v.y))})
    end
end

function BloodParticle:draw()
    self:pseudo3DDraw()
    self:shadowDraw()

    love.graphics.draw(self.blood_particle, self.x, self.y - self.z, 0, 1, 1, self.w/2, self.h/2)
end

return BloodParticle
