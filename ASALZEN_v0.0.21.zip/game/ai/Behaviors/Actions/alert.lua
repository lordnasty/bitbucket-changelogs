local alert = Action:extend('alert')

function alert:new()
    alert.super.new(self, 'alert')
end

function alert:update(dt, context)
    return alert.super.update(self, dt, context)
end

function alert:run(dt, context)
    return 'success'
end

function alert:start(context)
    if context.alert_target then
        context.direction = self.fg.utils.angleToDirection2(self.fg.Vector(context.alert_target.body:getPosition()):angleTo(self.fg.Vector(context.object.body:getPosition())))
        context.object.direction = context.direction
        context.object.v_z = -70
        context.object.melee_attack_locked = true
    end
end

function alert:finish(status, context)
    context.alert_target = nil
end

return alert
