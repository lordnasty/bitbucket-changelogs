Sequence = Behavior:extend('Sequence')

function Sequence:new(name, behaviors)
    Sequence.super.new(self)
    self.name = name
    self.behaviors = behaviors
    self.current_behavior = 1
end

function Sequence:update(dt, context)
    return Sequence.super.update(self, dt, context) 
end

function Sequence:run(dt, context)
    while true do
        local status = self.behaviors[self.current_behavior]:update(dt, context)
        if status ~= 'success' then return status end
        self.current_behavior = self.current_behavior + 1
        if self.current_behavior == #self.behaviors + 1 then return 'success' end
    end
end

function Sequence:start(context)
    self.current_behavior = 1
end

function Sequence:finish(status, context)

end
