local AICombat = fg.Object:extend('AICombat')

function AICombat:AICombatNew(settings)
    local settings = settings or {}
    
    self.agroed = false
    self.reaction_time = 1
    self.melee_attack_locked = false
    self.melee_attack_new_p = nil
    self.melee_attack_moving_to_target = false
    self.vulnerable_attack_delay = 1
    self.o_vulnerable_target = self.fg.obv(nil)

    self.light_punch_left = settings.settings.light_punch_left or false
    self.light_punch_right = settings.settings.light_punch_right or false
    self.strong_punch_left = settings.settings.strong_punch_left or false
    self.strong_punch_right = settings.settings.strong_punch_right or false
    self.kick = settings.settings.kick or false
    self.low_dash = settings.settings.low_dash or false
    self.dash = settings.settings.dash or false
    self.backdash = settings.settings.backdash or false
    self.block = settings.settings.block or false
end

function AICombat:AICombatUpdate(dt)
    -- Set vulnerable_target
    if self.o_vulnerable_target.v then if not self.o_vulnerable_target.v.vulnerable_to_attack then self.o_vulnerable_target:set(nil) end end
    if not self.o_vulnerable_target.v then self.melee_attack_locked = false end

    -- If player misses first hit and is vulnerable
    if self.o_vulnerable_target-nil then
        local object = self.o_vulnerable_target.v
        self.agroed = true

        -- Alert
        self:alert(object)

        -- Move and attack
        self.timer:after(self.vulnerable_attack_delay, function()
            if object then
                self:moveToTarget(object)
                self.timer:after('attack_after', 0.1, function()
                    self:meleeAttack('single hit')
                    self.o_vulnerable_target:set(nil)
                end)
            end
        end)
    end

    -- Move if tweening...
    if self.melee_attack_moving_to_target then self.body:setPosition(self.melee_attack_new_p.x, self.melee_attack_new_p.y) end
end

function AICombat:AICombatDraw()

end

function AICombat:hitATK(attacker, attack_type)
    self.agroed = true
end

function AICombat:meleeAttack(attack_type)
    local object = self.o_vulnerable_target.v
    if not object then return end
    local random = self.fg.utils.math.random
    local dx, dy = object.x - self.x, object.y - self.y
    if dx < 0 then dx = -1 else dx = 1 end
    if dy < 0 then dy = -1 else dy = 1 end

    self.last_combat_action = love.timer.getTime()
    object:hitATK(self, attack_type)

    -- Animation
    if attack_type == 'single hit' then
        local animations = {'light_punch_left', 'light_punch_right', 'strong_punch_left', 'strong_punch_right', 'kick'}
        self:playAnimation(animations[math.random(1, #animations)])
    end

    -- Hit effect
    self.area:createEntity('HitEffect', self.x + dx*24 + random(-4, 4), self.y - 20 + random(-4, 4))

    -- Star Hit Effect
    local angle = 0
    if dx > 0 then angle = random(-math.pi/4, math.pi/4) else angle = random(3*math.pi/4, 5*math.pi/4) end
    self.area:createEntity('StarHitEffect', 0, 0, {angle = angle, v = random(25, 100), parent = object, offset_x = dx*8, offset_y = -36 + random(-2, 2)})

    -- Particles
    local z = object.z + object.height_z - 6
    local n = math.random(2, 4)
    for i = 1, n do
        self.area:createEntity('BloodParticle', object.x + 4*dx, object.y, {v = fg.Vector(dx*random(150, 250), random(-25, 25)), z = z, v_z = -random(0, 50)})
    end

    -- Juice
    self.sx, self.sy = self.fg.utils.math.random(1.02, 1.1), self.fg.utils.math.random(1.02, 1.1)
    local r = self.fg.utils.math.random(0.1, 0.6)
    self.timer:tween('hit_scale_tween', r, self, {sx = 1, sy = 1}, 'in-out-cubic')
    self.timer:after('hit_scale_after', r, function() self.sx = 1; self.sy = 1 end)
end

function AICombat:setVulnerableTarget(target, attack_delay)
    self.o_vulnerable_target(target)
    self.vulnerable_attack_delay = attack_delay or self.vulnerable_attack_delay
end

function AICombat:moveToTarget(object)
    local angle = 0
    if self.direction == 'right' then angle = math.pi end
    self.melee_attack_moving_to_target = true
    self.melee_attack_new_p = self.fg.Vector(self.x, self.y)
    self.timer:tween('attack_move_tween', 0.1, self.melee_attack_new_p, {x = object.x + 25*math.cos(angle), y = object.y + 0.1}, 'linear')
    self.timer:after('attack_move_after', 0.1, function()
        self.melee_attack_moving_to_target = false
        self.melee_attack_new_p = nil
    end)
end

function AICombat:alert(object)
    local dx = 1
    local direction = self.fg.utils.angleToDirection2(self.fg.Vector(object.body:getPosition()):angleTo(self.fg.Vector(self.body:getPosition())))
    self.direction = direction
    if direction == 'right' then dx = -1 end
    self.v_z = -70
    self.melee_attack_locked = true
    fg.world.areas['MainCorridor3']:createEntity('Exclamation', self.x, self.y, {parent = self, duration = 0.8, offset_x = dx*12, offset_y = -42})
end

function AICombat:AICombatSave()
    return {
        light_punch_left = self.light_punch_left, light_punch_right = self.light_punch_right,
        strong_punch_left = self.strong_punch_left, strong_punch_right = self.strong_punch_right,
        kick = self.kick, dash = self.dash, backdash = self.backdash, low_dash = self.low_dash, block = self.block
    }
end

return AICombat
