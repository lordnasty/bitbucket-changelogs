local UIDialogue = fg.Object:extend('UIDialogue')

function UIDialogue:UIDialogueNew(settings)
    local settings = settings or {}

    fg.input:bind('fdown', 'diag-next')
    fg.input:bind('fleft', 'diag-next')
    fg.input:bind('r1', 'diag-next')
    fg.input:bind('l1', 'diag-next')
    fg.input:bind('j', 'diag-next')
    fg.input:bind('e', 'diag-next')

    self.fs = 24*fg.screen_scale/512 
    self.font = fg.Fonts.helsinki

    self.diag_active = false

    self.diag_textbox_tweening = false
    self.diag_textbox = {x = fg.screen_width + 20*fg.screen_scale, y = fg.screen_height + 20*fg.screen_scale, w = fg.screen_width - 40*fg.screen_scale, h = 90*fg.screen_height/fg.min_height}

    self.diag_text_complete = false
    self.diag_info = nil
    self.diag_r = 0
    self.diag_current_index = 1
    self.textbox_speed = 0.05
    self.textbox_speed_stage = 1
    self.diag_button_visible = true
    self.timer:every(0.4, function() self.diag_button_visible = not self.diag_button_visible end)
end

function UIDialogue:UIDialogueUpdate(dt)
    if not self.diag_active then return end

    self.diag_textbox.w = fg.screen_width - 40*fg.screen_width/fg.min_width
    self.diag_textbox.h = 90*fg.screen_height/fg.min_height 
    if not self.diag_textbox_tweening then
        self.diag_textbox = {x = 20*fg.screen_width/fg.min_width, y = fg.screen_height - 100*fg.screen_height/fg.min_height, 
                             w = fg.screen_width - 40*fg.screen_width/fg.min_height, h = 90*fg.screen_height/fg.min_height}
    end

    self.fs = 24*(fg.screen_height/fg.min_height)/512
    if self.diag_text then self.diag_text:update(dt) end

    if fg.input:pressed('diag-next') then
        if self.textbox_speed_stage == 1 and not self.diag_text_complete then
            self.diag_text_complete = true
            if self.diag_post_trigger then self.diag_post_trigger() end
            self.textbox_speed_stage = 40 
        else
            self.diag_current_index = self.diag_current_index + 1
            self:processText()
        end
    end
end

function UIDialogue:UIDialogueDraw()
    if not self.diag_active then return end

    local r, g, b = unpack(UI.colors.white)
    love.graphics.setColor(r, g, b, 236)
    fg.utils.graphics.roundedRectangle('fill', self.diag_textbox.x, self.diag_textbox.y, self.diag_textbox.w, self.diag_textbox.h, 30*fg.screen_scale, 30*fg.screen_scale)

    love.graphics.setColor(r, g, b, 255)
    fg.utils.graphics.roundedRectangle('fill', self.diag_textbox.x + 25*fg.screen_scale, self.diag_textbox.y + 3*fg.screen_scale, 
                                       self.diag_textbox.w - 50*fg.screen_scale, self.diag_textbox.h - 6*fg.screen_scale, 4*fg.screen_scale, 4*fg.screen_scale)

    if self.name_text then
        local r, g, b = unpack(UI.colors.pink)
        love.graphics.setColor(r, g, b, 160)
        love.graphics.print(self.name_text, self.diag_textbox.x + 30*fg.screen_scale, self.diag_textbox.y + 6*fg.screen_scale, 0, self.fs, self.fs)
    end

    if self.diag_text then
        local r, g, b = unpack(UI.colors.bg)
        love.graphics.setColor(r, g, b, 160)
        self.diag_text:draw()
    end

    local r, g, b = unpack(UI.colors.pink)
    local a = 160
    if self.diag_button_visible then a = 0 end
    love.graphics.setColor(r, g, b, a)
    fg.utils.graphics.roundedRectangle('fill', self.diag_textbox.x + self.diag_textbox.w - 37*fg.screen_scale, self.diag_textbox.y + self.diag_textbox.h - 15*fg.screen_scale, 
                                       10*fg.screen_scale, 10*fg.screen_scale, 3*fg.screen_scale, 3*fg.screen_scale)
end

function UIDialogue:diagActivate(info)
    if info.script.name == 'MainCorridor3' then
        ui:createEntity('InteractPopup', 0, 0, {text = 'Skip', action = 'skip', r = -math.pi/8, press_action = function(self) 
            ui.timer:tween(1, fg.world, {focus_point_radius = 2}, 'in-out-cubic')
            ui.timer:tween(1, fg.world, {focus_point_amount = 0}, 'in-out-cubic')
            ui:diagDeactivate() 
            self.dead = true
        end})
    end

    self.diag_info = info
    self.diag_active = true
    self.diag_textbox_tweening = true
    self.diag_textbox = {x = fg.screen_width + 20*fg.screen_width/fg.min_width, y = fg.screen_height + 20*fg.screen_height/fg.min_height, 
                         w = fg.screen_width - 40*fg.screen_width/fg.min_width, h = 90*fg.screen_height/fg.min_height}
    self.timer:tween('diag_textbox', 0.2, self.diag_textbox, {x = 20*fg.screen_width/fg.min_width, y = fg.screen_height - 100*fg.screen_height/fg.min_height}, 
                     'in-out-cubic', function() self.diag_textbox_tweening = false end)
    self.timer:tween('diag_r', 0.4, self, {diag_r = math.pi/42}, 'in-out-cubic')

    self.timer:after(0.2, function() self:processText() end)
end

function UIDialogue:processText()
    if not self.diag_info then return end
    if self.diag_current_index > #self.diag_info.texts then self.name_text = nil; self.diag_text = nil; self:diagDeactivate(); return end

    local trigger = self.diag_info.triggers[self.diag_current_index]
    local text = self.diag_info.texts[self.diag_current_index]
    local name = self.diag_info.names[self.diag_current_index]
    self.textbox_speed_stage = 1
    self.diag_text_complete = false

    self.timer:cancel('wait_text')
    local command, command2, args, args2 = nil, nil, nil, nil
    if trigger then command, args, command2, args2 = trigger() end
    self.name_text = name
    local createText = function()
        self.diag_text_complete = false
        self.diag_text = fg.Text(self.diag_textbox.x + 30*fg.screen_scale, self.diag_textbox.y + 25*fg.screen_scale, text, {
            font = self.font,
            font_multiplier = self.fs,
            wrap_width = self.diag_textbox.w - 65*fg.screen_scale,

            customDraw = function(x, y, c) love.graphics.print(c.character, (x or self.x) + c.x, (y or self.y) + c.y, 0, self.fs, self.fs) end,
            textboxInit = function(c) c.t = 0 end,
            textbox = function(dt, c)
                local r, g, b, a = love.graphics.getColor()
                c.t = c.t + dt
                if c.t > c.position*self.textbox_speed/self.textbox_speed_stage then love.graphics.setColor(r, g, b, 255)
                else love.graphics.setColor(r, g, b, 0) end
                if c.t >= #c.str_text*self.textbox_speed then 
                    self.diag_text_complete = true 
                    if self.diag_post_trigger then self.diag_post_trigger() end
                end
            end,
            shakeInit = function(c) c.anchor_x = c.x; c.anchor_y = c.y end,
            shake = function(dt, c)
                c.x = c.anchor_x + math.random(-3, 3)/2
                c.y = c.anchor_y + math.random(-3, 3)/2
            end
        })
    end

    if command == 'wait' then 
        self.timer:after('wait_text', args[1], function() 
            createText() 
            if args[2] then args[2]() end
        end)
    else createText() end

    if command2 == 'post_trigger' then self.diag_post_trigger = args2[1] 
    else self.diag_post_trigger = nil end
end

function UIDialogue:diagDeactivate()
    self.diag_textbox_tweening = true
    self.timer:tween('diag_textbox', 0.2, self.diag_textbox, {x = fg.screen_width + 20*fg.screen_scale, y = fg.screen_height + 20*fg.screen_scale}, 'in-out-cubic', function()
        self.name_text = nil
        self.diag_text = nil
        self.diag_text_complete = false
        self.diag_textbox_tweening = false
        self.diag_active = false
        if self.diag_info then self.diag_info.script:postDialogue() end
        self.diag_info = nil
    end)
end

return UIDialogue
