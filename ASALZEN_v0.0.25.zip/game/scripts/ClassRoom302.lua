local ClassRoom302 = fg.Object:extend('ClassRoom302')

function ClassRoom302:new(data)
    if data then for k, v in pairs(data) do self[k] = v end end
    self.timer = fg.Timer()
    self.name = 'ClassRoom302'
end

function ClassRoom302:update(dt)
    self.timer:update(dt)
end

function ClassRoom302:initPost()
    local player = SH.getPlayer()
    player.action_locked = true

    local enemy = fg.world.areas['ClassRoom302']:getEntitiesWhere(function() return true end, {'PersonAI'})[1]
    enemy.hp_seq:changeSequence({'r'})

    self.timer:after(1, function()
        enemy:alert(player)
        enemy.agroed = true

        ui:createEntity('InteractPopup', 0, 0, {text = 'ATTACK RIGHT', font_size = 20, action = 'rightAttack', press_action = function(self) 
            self.dead = true 
            player.action_locked = false
        end})
    end)
end

return ClassRoom302
