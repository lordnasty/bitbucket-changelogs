local UI = fg.Object:extend('UI')

-- Require everything that can be required here
local prepaths = {'objects/', 'systems/'}
for _, prepath in ipairs(prepaths) do
    for _, p in ipairs(love.filesystem.getDirectoryItems('ui/' .. prepath)) do
        if love.filesystem.isDirectory('ui/' .. prepath .. p) then
            for _, f in ipairs(love.filesystem.getDirectoryItems('ui/' .. prepath .. p .. '/')) do
                if f:sub(-4) == '.lua' then _G[f:sub(1, -5)] = require('ui/' .. prepath .. p .. '/' .. f:sub(1, -5)) end
            end
        else if p:sub(-4) == '.lua' then _G[p:sub(1, -5)] = require('ui/' .. prepath .. p:sub(1, -5)) end end
    end
end

UI.colors = {
    bg = {16, 11, 9},
    white = {226, 226, 226},
    black = {120, 118, 121},
    violet = {133, 105, 207},
    blue = {13, 159, 216},
    green = {138, 215, 73},
    yellow = {238, 206, 0},
    orange = {248, 152, 31},
    red = {248, 14, 39},
    pink = {246, 64, 174},
}

UI:implement(UIRender)

function UI:new()
    fg.Fonts = {}
    fg.Fonts['helsinki'] = love.graphics.newFont('resources/fonts/helsinki.ttf', 128)
    fg.Fonts['OpenSans'] = love.graphics.newFont('resources/fonts/OpenSans-Semibold.ttf', 64)
    fg.Fonts['helsinki_24'] = love.graphics.newFont('resources/fonts/helsinki.ttf', 24)

    self:UIRenderNew()
end

function UI:update(dt)
    self:UIRenderUpdate(dt)
end

function UI:draw()
    self:UIRenderDraw()
end

function UI:resize(w, h)
    self:UIRenderResize(w, h)
end

function UI:createEntity(type, x, y, settings)
    if self.entities[type] then
        table.insert(self.entities[type], _G[type](x, y, settings))
    else
        self.entities[type] = {}
        table.insert(self.entities[type], _G[type](x, y, settings))
    end
end

return UI
