local TilesetDisplay = fg.Object:extend('TilesetDisplay')

function TilesetDisplay:tilesetDisplayNew(settings)
    local settings = settings or {}

    self.ei:bind('mouse1', 'mouse1')
    self.ei:bind('mouse2', 'mouse2')
    self.ei:bind('escape', 'escape')

    self.tilesets = {}
    for _, t in ipairs(game.tilesets) do
        self.tilesets[t] = fg.Tilemap(0, 0, game.tile_width, game.tile_height, 
                           love.graphics.newImage('resources/tilesets/' .. t .. '.png'), {{0}})
    end
    self.selected_tile = nil
    self.inside_tileset_display = false
    self.tileset_id = 0
    self.tileset_id_sub = 0
end

function TilesetDisplay:tilesetDisplayUpdate(dt)
    if self.menu_current_tileset and not self.inside_properties_frame and not self.map_textinput_selected then
        for i, t in ipairs(game.tilesets) do 
            if t == self.menu_current_tileset then self.tileset_id = i end
        end
        self.tileset_id_sub = game.levels[fg.current_area].tilemaps[self.menu_current_layer].n_tiles_per_tileset[self.tileset_id-1] or 0

        -- Set selected tile on mouse click
        local tilemap = self.tilesets[self.menu_current_tileset]
        local tw, th = tilemap.tilesets[1]:getWidth(), tilemap.tilesets[1]:getHeight()
        local w, h = fg.screen_width, fg.screen_height
        local nw, nh = math.floor(tw/tilemap.tile_width), math.floor(th/tilemap.tile_height)
        local x, y = love.mouse.getPosition()
        local xi, yi = w - tw - 16 - nw, 16 
        for i = 1, tilemap.n_tiles_per_tileset[1] do
            local j = math.floor((i-1)/nw)
            local x1, y1 = xi + (i-1)*(tilemap.tile_width+1) - j*(tw+nw), yi + j*(tilemap.tile_height+1)
            local x2, y2 = x1 + tilemap.tile_width, y1 + tilemap.tile_height
            if x >= x1 and x <= x2 and y >= y1 and y <= y2 then
                if self.ei:pressed('mouse1') then
                    self.selected_tile = i + self.tileset_id_sub
                end
            end
        end

        -- Set inside_tileset_display
        local x1, y1 = w - tw - 16 - nw - 5, 16 - 5
        local x2, y2 = x1 + tw + 16, y1 + th + 16
        if x >= x1 and x <= x2 and y >= y1 and y <= y2 then self.inside_tileset_display = true
        else self.inside_tileset_display = false end
    else self.selected_tile = nil end

    -- Unselect tile on ESC
    if self.selected_tile then
        if self.ei:pressed('escape') then
            self.selected_tile = nil
        end
    end
end

function TilesetDisplay:tilesetDisplayDraw()
    if self.menu_current_tileset then
        -- Draw tileset display
        local tilemap = self.tilesets[self.menu_current_tileset]
        local tw, th = tilemap.tilesets[1]:getWidth(), tilemap.tilesets[1]:getHeight()
        local w, h = fg.screen_width, fg.screen_height
        local nw, nh = math.floor(tw/tilemap.tile_width), math.floor(th/tilemap.tile_height)
        local x, y = love.mouse.getPosition()
        local x1, y1 = w - tw - 16 - nw, 16 
        for i = 1, tilemap.n_tiles_per_tileset[1] do
            local j = math.floor((i-1)/nw)
            local xx, yy = x1 + (i-1)*(tilemap.tile_width+1) - j*(tw+nw), y1 + j*(tilemap.tile_height+1)
            local x2, y2 = xx + tilemap.tile_width, yy + tilemap.tile_width
            if x >= xx and x <= x2 and y >= yy and y <= y2 then
                love.graphics.setShader(fg.Shaders.combine)
                love.graphics.setColor(222, 222, 222, 255)
                love.graphics.draw(tilemap.tilesets[1], tilemap.quads[1][i], xx, yy)
                love.graphics.setColor(255, 255, 255, 255)
                love.graphics.setShader()
            else
                love.graphics.draw(tilemap.tilesets[1], tilemap.quads[1][i], xx, yy)
            end
        end

        -- Draw selected tile on mouse snapped to grid
        if self.selected_tile then
            local tilemap = game.levels[fg.current_area].tilemaps.Default
            local quad = tilemap.quads[self.tileset_id][self.selected_tile - self.tileset_id_sub]
            if self.grid_x and self.grid_y and quad then
                local rx, ry = fg.world.camera:getCameraCoords(-tilemap.w/2 + (self.grid_x-1)*tilemap.tile_width, 
                                                               -tilemap.h/2 + (self.grid_y-1)*tilemap.tile_height)
                love.graphics.setColor(255, 255, 255, 128)
                love.graphics.draw(tilemap.tilesets[self.tileset_id], quad, rx, ry, 0, fg.screen_scale, fg.screen_scale)
            end
        end
    end
    
    love.graphics.setColor(255, 255, 255, 255)
end

return TilesetDisplay
