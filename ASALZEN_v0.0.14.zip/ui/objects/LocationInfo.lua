local LocationInfo = fg.Object:extend('LocationInfo')

LocationInfo.layer = 'UI_Info'

function LocationInfo:new(x, y, settings)
    self.text = settings.text
    self.font = fg.Fonts.helsinki_24
    self.w = self.font:getWidth(self.text) + 20
    self.timer = fg.Timer()
    self.h = 0
    self.timer:tween(0.1, self, {h = self.font:getHeight() + 20}, 'linear')
    self.x, self.y = x, y + (self.font:getHeight() + 20)/2

    self.final_h = self.font:getHeight() + 20
    self.bg_x, self.bg_y = x - 300, y
    self.timer:tween(0.1, self, {bg_x = x - 10}, 'linear')

    self.text_x = x - 250
    self.timer:tween(0.2, self, {text_x = x}, 'linear')
end

function LocationInfo:update(dt)
    self.timer:update(dt)
    self.y = fg.screen_height - 70 + (self.font:getHeight() + 20)/2
    self.bg_y = fg.screen_height - 70
end

function LocationInfo:draw()
    fg.utils.graphics.pushRotate(self.x + self.w/2, self.y, math.pi/24)
    love.graphics.setColor(unpack(UI.colors.yellow))
    fg.utils.graphics.roundedRectangle('fill', self.bg_x, self.bg_y, self.w - 10, self.final_h, 10, 10)
    love.graphics.pop()

    love.graphics.setScissor(self.x, self.y - self.h/2, self.w, self.h)
    love.graphics.setColor(unpack(UI.colors.bg))
    fg.utils.graphics.roundedRectangle('fill', self.x, self.y - self.h/2, self.w, self.h, 10, 10)
    love.graphics.setColor(unpack(UI.colors.white))
    love.graphics.setFont(fg.Fonts.helsinki_24)
    love.graphics.print(self.text, self.text_x + 10, self.y - self.final_h/2 + 10)
    love.graphics.setScissor()
end

return LocationInfo
