local AI = fg.Object:extend('AI')

function AI:AINew(settings)
    local settings = settings or {}

    self.behavior_tree = Root(self, null())
    --[[
        Sequence('attackVulnerableTarget', {
            isVulnerableTarget(),
            alert(),
            wait(1),
            moveToTargetForAttack(),
            meleeAttack(),
        })
    ]]--
end

function AI:AIUpdate(dt)
    self.behavior_tree:update(dt)
end

function AI:AIDraw()

end

function AI:AISave()

end

return AI
