ActiveSelector = Behavior:extend('ActiveSelector')

function ActiveSelector:new(name, behaviors)
    ActiveSelector.super.new(self)
    self.name = name
    self.behaviors = behaviors
end

function ActiveSelector:update(dt, context)
    return ActiveSelector.super.update(self, dt, context)
end

function ActiveSelector:run(dt, context)
    for _, behavior in ipairs(self.behaviors) do
        local status = behavior:update(dt, context)
        if status == 'success' then 
            behavior:finish(status, context)
            return status 
        elseif status == 'running' then
            return status
        end
    end
    return 'failure'
end

function ActiveSelector:start(context)

end

function ActiveSelector:finish(status, context)
    
end
