local Exclamation = fg.Class('Exclamation', 'Entity')

Exclamation.layer = 'Effects'

function Exclamation:new(area, x, y, settings)
    local settings = settings or {}
    Exclamation.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()

    self.visual = self.fg.Assets.exclamation
    self.w, self.h = self.visual:getWidth(), self.visual:getHeight()
    self.timer:after(settings.duration or 1, function() self.dead = true end)
    if self.parent then
        local direction = 1 if self.parent.direction == 'left' then direction = -1 end
        self.x, self.y = self.parent.x + direction*self.offset_x, self.parent.y + self.offset_y
    end
    self.shake_x, self.shake_y = 0, 0
    self.timer:every(0.05, function()
        self.shake_x = fg.utils.math.random(-2, 2)
        self.shake_y = fg.utils.math.random(-2, 2)
        self.angle = fg.utils.math.random(-math.pi/16, math.pi/16)
    end)
end

function Exclamation:update(dt)
    self.timer:update(dt)
    if self.parent then
        local direction = 1 if self.parent.direction == 'left' then direction = -1 end
        self.x, self.y = self.parent.x + direction*self.offset_x + self.shake_x, self.parent.y + self.offset_y + self.shake_y
    end
end

function Exclamation:draw()
    love.graphics.setColor(222, 96, 96)
    love.graphics.draw(self.visual, self.x, self.y, self.angle or 0, self.sx or 1, self.sy or 1, self.w/2, self.h/2)
    love.graphics.setColor(255, 255, 255)
end

return Exclamation
