local Bucket = fg.Class('Bucket', 'Entity')
Bucket:implement(fg.PhysicsBody)
Bucket:implement(Pseudo3D)

function Bucket:new(area, x, y, settings)
    local settings = settings or {}
    self.filled = settings.filled
    settings.w, settings.h = 10, 6
    self.bucket_shadow = love.graphics.newQuad(32, 0, 16, 16, 48, 16)
    if self.filled then self.bucket_quad = love.graphics.newQuad(16, 0, 16, 16, 48, 16)
    else self.bucket_quad = love.graphics.newQuad(0, 0, 16, 16, 48, 16) end
    Bucket.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    self.bucket_visual = self.fg.Assets.bucket
    self:physicsBodyNew(area, x, y, settings)
    self:pseudo3DNew({height_z = 6, settings = settings})
    self.angle = 0
    self.down = false
    self.shadow_offset = {x = 0, y = 0}

    if self.filled then 
        self.area:createEntity('WaterPool', self.x, self.y) 
        self.timer:every('water_drop', {3, 6}, function() self.area:createEntity('WaterDrop', self.x, self.y) end)
    end
end

function Bucket:update(dt)
    self.timer:update(dt)
    self:physicsBodyUpdate(dt)
    self:pseudo3DUpdate(dt)
end

function Bucket:draw()
    local w, h = 16, 16
    local direction = 1; if self.down and self.angle < 0 then direction = -1 end
    -- Shadow
    love.graphics.setColor(255, 255, 255, 128)
    love.graphics.draw(self.bucket_visual, self.bucket_shadow, self.x - w/2 + self.shadow_offset.x*direction, self.y - h/2 - 3 + self.shadow_offset.y)
    love.graphics.setColor(255, 255, 255, 255)
    -- Bucket
    love.graphics.draw(self.bucket_visual, self.bucket_quad, self.x, self.y, self.angle, 1, 1, w/2, h/2 + 4)
    self:physicsBodyDraw()
    self:pseudo3DDraw()
end

function Bucket:highlightDraw()
    local w, h = 16, 16
    love.graphics.draw(self.bucket_visual, self.bucket_quad, self.x, self.y, self.angle, 1, 1, w/2, h/2 + 4)
end

function Bucket:fallDown()
    self.bucket_quad = love.graphics.newQuad(0, 0, 16, 16, 48, 16)
    local angle = self.fg.utils.table.random({math.pi/2, -math.pi/2})
    local d = self.fg.utils.math.random(0.25, 0.35)
    self.timer:tween('fall_down', d, self, {angle = angle}, 'in-out-cubic')
    self.timer:tween('shadow_offset', d, self.shadow_offset, {x = 4, y = 2}, 'in-out-cubic')
    local direction = 1; if angle < 0 then direction = -1 end
    if self.filled then self.area:createEntity('WaterPool', self.x + 24*direction, self.y, {tween_up_duration = self.fg.utils.math.random(0.6, 1)}) end
    self.filled = false
    self.down = true
end

function Bucket:save()
    local pseudo_3d = self:pseudo3DSave()
    local save_data = {}
    for k, v in pairs(pseudo_3d) do save_data[k] = v end
    save_data.filled = self.filled
    save_data.down = self.down
    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y
    save_data.w, save_data.h = self.w, self.h
    save_data.shape = 'Rectangle'
    save_data.angle = self.angle
    return save_data
end

return Bucket
