local UIRender = fg.Object:extend('UIRender')

function UIRender:UIRenderNew(settings)
    local settings = settings or {}

    self.entities = {}

    self.outline_text_canvas = love.graphics.newCanvas(fg.screen_width, fg.screen_height)
    self.ui_info_canvas = love.graphics.newCanvas(fg.screen_width, fg.screen_height)

    self.text_outline = love.graphics.newShader('resources/shaders/default.vert', 'resources/shaders/text_outline.frag')
end

function UIRender:UIRenderUpdate(dt)
    for _, entities in pairs(self.entities) do
        for i = #entities, 1, -1 do
            if entities[i].dead then table.remove(entities, i)
            else entities[i]:update(dt) end
        end
    end
end

function UIRender:UIRenderDraw()
    -- Text outline
    local draw_outline_text = function()
        for k, v in pairs(self.entities) do
            if _G[k].layer == 'Outline_Text' then
                for _, entity in ipairs(v) do
                    entity:draw()
                end
            end
        end
    end
    draw_outline_text()
    self.outline_text_canvas:clear()
    self.outline_text_canvas:renderTo(draw_outline_text)

    love.graphics.setShader(self.text_outline)
    love.graphics.draw(self.outline_text_canvas, 0, 0)
    love.graphics.setShader()

    -- UI Info
    self.ui_info_canvas:clear()
    self.ui_info_canvas:renderTo(function()
        for k, v in pairs(self.entities) do
            if _G[k].layer == 'UI_Info' then
                for _, entity in ipairs(v) do
                    entity:draw()
                end
            end
        end
    end)

    love.graphics.draw(self.ui_info_canvas, 0, 0)
end

function UIRender:UIRenderResize(w, h)
    self.outline_text_canvas = love.graphics.newCanvas(w, h)
    self.ui_info_canvas = love.graphics.newCanvas(w, h)
end

function UIRender:createEntity(type, x, y, settings)
    if self.entities[type] then
        table.insert(self.entities[type], _G[type](x, y, settings))
    else 
        self.entities[type] = {}
        table.insert(self.entities[type], _G[type](x, y, settings))
    end
end

return UIRender
