local anim_struct = function(state, image, size, delay, mode, offset) 
    return {state = state, image = image, size = size, 
            delay = delay, mode = mode, offset = offset} 
end

fg.player_animations = {
    anim_struct('idle', 'player_idle', {32, 32}, 0.1, 'loop', {-16, -18}),
    anim_struct('run', 'player_run', {32, 32}, 0.1, 'loop', {-16, -18}),
    anim_struct('jump', 'player_jump', {32, 32}, 0.1, 'loop', {-16, -18}),
    anim_struct('fall', 'player_fall', {32, 32}, 0.1, 'loop', {-16, -18}),
    anim_struct('light_attack', 'player_basic_attack', {76, 44}, 0.03, 'loop', {-28, -31}),
    anim_struct('heavy_attack', 'player_heavy_attack', {76, 44}, 0.03, 'loop', {-28, -31}),
    anim_struct('light_attack_1', 'player_light_attack_1', {49, 61}, 0.03, 'loop', {-20, -31}),
    anim_struct('light_attack_2', 'player_light_attack_2', {49, 61}, 0.03, 'loop', {-20, -31}),
    anim_struct('light_attack_3', 'player_light_attack_3', {49, 61}, 0.03, 'loop', {-20, -31}),
    anim_struct('light_attack_4', 'player_light_attack_4', {49, 61}, 0.03, 'loop', {-20, -31}),
    anim_struct('light_attack_5', 'player_light_attack_5', {49, 61}, 0.03, 'loop', {-20, -31}),
}

fg.blaster_animations = {
    anim_struct('idle', 'blaster_idle', {32, 32}, 0.1, 'loop', {-16, -16}),
    anim_struct('move', 'blaster_move', {32, 40}, 0.2, 'loop', {-16, -20}),
    anim_struct('hurt', 'blaster_hurt', {32, 40}, 0.1, 'loop', {-16, -20}),
    anim_struct('attack', 'blaster_attack', {32, 40}, 0.2, 'loop', {-16, -20}),
}

fg.effects_animations = {
    explosion_blast_1 = anim_struct('explosion_blast_1', 'explosion_blast_1', {31, 11}, {0.08, 0.14}, 'once'),
    explosion_blast_2 = anim_struct('explosion_blast_2', 'explosion_blast_2', {31, 11}, {0.08, 0.14}, 'once'),
    explosion_flash_1 = anim_struct('explosion_flash_1', 'explosion_flash_1', {22, 20}, 0.05, 'once'),
    explosion_flash_2 = anim_struct('explosion_flash_2', 'explosion_flash_2', {34, 34}, 0.05, 'once'),
    explosion_flash_3 = anim_struct('explosion_flash_3', 'explosion_flash_3', {34, 34}, 0.05, 'once'),
    explosion_flash_4 = anim_struct('explosion_flash_4', 'explosion_flash_4', {34, 34}, 0.05, 'once'),
    hit_effect_1 = anim_struct('hit_effect_1', 'hit_effect_1', {43, 43}, 0.07, 'once'),
    hit_effect_2 = anim_struct('hit_effect_2', 'hit_effect_2', {43, 43}, 0.07, 'once'),
    hit_effect_3 = anim_struct('hit_effect_3', 'hit_effect_3', {19, 19}, 0.07, 'once'),
    hit_effect_4 = anim_struct('hit_effect_4', 'hit_effect_4', {19, 19}, 0.07, 'once'),
}
