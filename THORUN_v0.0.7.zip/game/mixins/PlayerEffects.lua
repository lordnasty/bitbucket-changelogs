local PlayerEffects = fg.Object:extend('PlayerEffects')

function PlayerEffects:playerEffectsNew(settings)
    local settings = settings or {}
end

function PlayerEffects:playerEffectsUpdate(dt)
    if self.disengaging then
        local vx, vy = self.body:getLinearVelocity()
        self.area:createEntity('PlayerDisengageTrail', self.x - vx/100, self.y - vy/100, {parent = self, offset_x = -16, offset_y = -18})
    end
end

function PlayerEffects:playerEffectsDraw()

end

function PlayerEffects:playerEffectsSave()

end

return PlayerEffects
