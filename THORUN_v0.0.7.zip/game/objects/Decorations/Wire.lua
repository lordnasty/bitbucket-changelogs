local Wire = fg.Class('Wire', 'Entity')

Wire.layer = 'Front_1'

function Wire:new(area, x, y, settings)
    local settings = settings or {}
    Wire.super.new(self, area, x, y, settings)
    local n = settings.n or math.random(1, 2)
    self.wire_visual = self.fg.Assets['wire_' .. n]
end

function Wire:update(dt)

end

function Wire:draw()
    local w, h = self.wire_visual:getWidth(), self.wire_visual:getHeight()
    love.graphics.draw(self.wire_visual, self.x, self.y, self.r or 0, 1, 1, w/2, h/2)
end

function Wire:save()
    return {id = self.id, x = self.x, y = self.y, n = self.n, r = self.r}
end

return Wire
