local CapsuleTerminal = fg.Class('CapsuleTerminal', 'Entity')

function CapsuleTerminal:new(area, x, y, settings)
    local settings = settings or {}
    CapsuleTerminal.super.new(self, area, x, y, settings)

    self.capsule_opened = self.fg.Assets.capsule_opened
    self.capsule_closed = self.fg.Assets.capsule_closed
    self.capsule_visual = self.capsule_closed
    self.w, self.h = self.capsule_visual:getWidth(), self.capsule_visual:getHeight()
    self.r = 0
end

function CapsuleTerminal:update(dt)

end

function CapsuleTerminal:draw()
    love.graphics.draw(self.capsule_visual, self.x, self.y, self.r, 1, 1, self.w/2, self.h/2)
end

return CapsuleTerminal
