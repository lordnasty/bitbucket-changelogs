local Editor = fg.Object:extend('Editor')
local font = love.graphics.newFont('resources/fonts/FreePixel.ttf', 16)
Editor:implement(require('editor/Menu'))
Editor:implement(require('editor/TilesetDisplay'))
Editor:implement(require('editor/Grid'))
Editor:implement(require('editor/Camera'))
Editor:implement(require('editor/Tilemap'))
Editor:implement(require('editor/Mouse'))
Editor:implement(require('editor/Object'))
Editor:implement(require('editor/Notifier'))

-- Steps:
-- create new Input and add it everywhere (main, run)
-- define layers that are going to be used by the editor in game.layers
-- define tilesets that are going to be used by the editor in game.tilesets
-- define tile_width, tile_height in game.tile_width, game.tile_height
-- define objects that are going to be used in game.objects, 
-- also define which type of editor object it is (how it should be spawned) and its image

function Editor:new()
    self.ei = editor_input

    love.mouse.setVisible(false)

    self.font = font
    self.active = false
    self.ei:bind('f2', 'activateMem')
    self.ei:bind('f3', 'activate')
    self.inside_properties_frame = false

    self:mouseNew()
    self:cameraNew()
    self:gridNew()
    self:menuNew()
    self:tilesetDisplayNew()
    self:tilemapNew()
    self:objectNew()
    self:notifierNew()
end

function Editor:update(dt)
    if not game.active then return end
    if self.ei:pressed('activate') then self:activate() end
    if self.ei:pressed('activateMem') then self:activateMem() end
    if not self.active then return end

    self:mouseUpdate(dt)
    self:cameraUpdate(dt)
    self:gridUpdate(dt)
    self:menuUpdate(dt)
    self:tilesetDisplayUpdate(dt)
    self:tilemapUpdate(dt)
    self:objectUpdate(dt)
    self:notifierUpdate(dt)
end

function Editor:draw()
    if not self.active then return end
    local previous_font = love.graphics.getFont()
    love.graphics.setFont(font)

    self:cameraDraw()
    self:gridDraw()
    self:tilemapDraw()
    self:objectDraw()
    self:menuDraw()
    self:tilesetDisplayDraw()
    self:notifierDraw()
    self:mouseDraw()

    love.graphics.setFont(previous_font)
end

function Editor:clear()
    self.objects = {}
end

function Editor:activate()
    self.active = true 
    game.levels[fg.current_area]:deactivate()
    fg.current_area = 'Editor'
    game.levels[fg.current_area]:setBackground()
    game.levels[fg.current_area]:activate()
    local tilemap = game.levels[fg.current_area].tilemaps[self.menu_current_layer]
    fg.world.camera.target = nil
    fg.world.camera:moveTo(tilemap.x, tilemap.y)
    self:activateNonEmptyLayers()
    love.mouse.setVisible(false)
end

function Editor:activateMem()
    if not game.levels[fg.current_area].last_loaded_map then return end
    self.active = true
    game.levels[fg.current_area]:deactivate()
    self:clear()
    game.levels['Editor']:setBackground()
    game.levels['Editor']:loadToEditor(game.levels[fg.current_area].last_loaded_map)
    self:addNotification('Loaded map: ' .. game.levels[fg.current_area].last_loaded_map)
    fg.current_area = 'Editor'
    game.levels[fg.current_area]:activate()
    local tilemap = game.levels[fg.current_area].tilemaps[self.menu_current_layer]
    fg.world.camera.target = nil
    fg.world.camera:moveTo(tilemap.x, tilemap.y)
    self:activateNonEmptyLayers()
    love.mouse.setVisible(false)
end

return Editor
