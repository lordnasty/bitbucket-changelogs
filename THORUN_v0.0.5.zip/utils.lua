function padSpritesheet(spritesheet_path, tile_width, tile_height)
    local spritesheet = love.graphics.newImage(spritesheet_path)
    local pad_x = math.floor(spritesheet:getWidth()/tile_width)
    local pad_y = math.floor(spritesheet:getHeight()/tile_height)
    local image = love.image.newImageData(spritesheet:getWidth() + pad_x, 
                                          spritesheet:getHeight() + pad_y)
    local ss_image = love.image.newImageData(spritesheet_path)
    local pad_widths = {tile_width}
    local pad_heights = {tile_height}
    for i = 2*tile_width+1, tile_width*pad_x, tile_width+1 do table.insert(pad_widths, i) end
    for i = 2*tile_height+1, tile_height*pad_y, tile_height+1 do table.insert(pad_heights, i) end
    for i = 0, image:getWidth()-1 do
        for j = 0, image:getHeight()-1 do
            if fg.fn.any(pad_widths, i) then
                local r, g, b, a = ss_image:getPixel(i - math.floor(i/tile_width) - 1,
                                                     j - math.floor(j/tile_height))
                image:setPixel(i, j, r, g, b, a)
            elseif fg.fn.any(pad_heights, j) then
                local r, g, b, a = ss_image:getPixel(i - math.floor(i/tile_width),
                                                     j - math.floor(j/tile_height) - 1)
                image:setPixel(i, j, r, g, b, a)
            else 
                local r, g, b, a = ss_image:getPixel(i - math.floor(i/tile_width), 
                                                     j - math.floor(j/tile_height))
                image:setPixel(i, j, r, g, b, a) 
            end
        end
    end
    image:encode('output.png')
end
