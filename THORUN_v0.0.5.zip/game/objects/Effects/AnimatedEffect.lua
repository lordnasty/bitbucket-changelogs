local AnimatedEffect = fg.Class('AnimatedEffect', 'Entity')

AnimatedEffect.layer = 'Effects'

function AnimatedEffect:new(area, x, y, settings)
    local settings = settings or {}
    AnimatedEffect.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()

    self.r = settings.r or 0
    self.sx, self.sy = settings.sx or 1, settings.sy or 1

    local anim = fg.effects_animations[self.type]
    self.w, self.h = anim.size[1], anim.size[2]
    if type(anim.delay) == 'table' then self.animation = self.fg.Animation(self.fg.Assets[anim.image], anim.size[1], anim.size[2], self.fg.utils.math.random(anim.delay[1], anim.delay[2]))
    else self.animation = self.fg.Animation(self.fg.Assets[anim.image], anim.size[1], anim.size[2], anim.delay) end
    self.animation:setMode(anim.mode)
    self.timer:after(self.animation.delay*self.animation.size, function() self.dead = true end)
end

function AnimatedEffect:update(dt)
    self.timer:update(dt)
    self.animation:update(dt)

    if self.v and self.r then
        self.x = self.x + self.v*math.cos(self.r)*dt
        self.y = self.y + self.v*math.sin(self.r)*dt
    end
    if self.damping then self.v = self.v*self.damping end
end

function AnimatedEffect:draw()
    self.animation:draw(self.x, self.y, self.r, self.sx, self.sy, self.w/2, self.h/2)
end

return AnimatedEffect
