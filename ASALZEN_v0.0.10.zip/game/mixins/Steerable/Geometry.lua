function lineIntersection2D(a, b, c, d, dist, point)
    local r_top = (a.y - c.y) * (d.x - c.x) - (a.x - c.x) * (d.y - c.y)
    local r_bot = (b.x - a.x) * (d.y - c.y) - (b.y - a.y) * (d.x - c.x)
    local s_top = (a.y - c.y) * (b.x - a.x) - (a.x - c.x) * (b.y - a.y)
    local s_bot = (b.x - a.x) * (d.y - c.y) - (b.y - a.y) * (d.x - c.x)

    if r_bot == 0 or s_bot == 0 then return false, dist, point end
    local r, s = r_top / r_bot, s_top / r_bot
    if (r > 0) and (r < 1) and (s > 0) and (s < 1) then return true, a:dist(b) * r, a + (b - a) * r
    else return false, 0, point end
end
