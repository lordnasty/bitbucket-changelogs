return function(x, y, radius, wait_min, wait_max)
    return Sequence('wander', {
        findWanderPoint(x, y, radius),
        moveToPoint(),
        wait({wait_min, wait_max}),
    })
end
