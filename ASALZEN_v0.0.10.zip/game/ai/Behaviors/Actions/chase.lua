local chase = Action:extend('chase')

function chase:new()
    chase.super.new(self, 'chase')
end

function chase:update(dt, context)
    return chase.super.update(self, dt, context)
end

function chase:run(dt, context)
    if context.any_around_entity then
        context.object:arriveOn(mg.Vector(context.any_around_entity.body:getPosition()))
        local angle = mg.Vector(context.any_around_entity.x, context.any_around_entity.y):angleTo(mg.Vector(context.object.body:getPosition()))
        context.object:setDirection(mg.utils.angleToDirection2(angle))
    end
    return 'running'
end

function chase:start(context)
    context.object:separationOn(15, {'Player', 'Student'})
    context.object.chasing = true
end

function chase:finish(status, context)
    context.object:arriveOff()
    context.object:separationOff()
    context.object.chasing = false
end

return chase
