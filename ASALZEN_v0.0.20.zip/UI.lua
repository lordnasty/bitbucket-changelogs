local UI = fg.Object:extend('UI')

-- Require everything that can be required here
local prepaths = {'objects/', 'systems/', 'ui/'}
for _, prepath in ipairs(prepaths) do
    for _, p in ipairs(love.filesystem.getDirectoryItems('ui/' .. prepath)) do
        if love.filesystem.isDirectory('ui/' .. prepath .. p) then
            for _, f in ipairs(love.filesystem.getDirectoryItems('ui/' .. prepath .. p .. '/')) do
                if f:sub(-4) == '.lua' then _G[f:sub(1, -5)] = require('ui/' .. prepath .. p .. '/' .. f:sub(1, -5)) end
            end
        else if p:sub(-4) == '.lua' then _G[p:sub(1, -5)] = require('ui/' .. prepath .. p:sub(1, -5)) end end
    end
end

UI.colors = {
    --[[
    turquoise = {26, 188, 156},
    dark_turquoise = {22, 160, 133},
    green = {46, 204, 113},
    dark_green = {39, 174, 96},
    blue = {52, 152, 219},
    dark_blue = {41, 128, 185},
    violet = {155, 89, 182},
    dark_violet = {142, 68, 173},
    black = {52, 73, 94},
    dark_black = {44, 62, 80},
    yellow = {241, 196, 15},
    dark_yellow = {243, 156, 18},
    orange = {230, 126, 34},
    dark_orange = {211, 84, 0},
    red = {231, 76, 60},
    dark_red = {192, 57, 43},
    white = {236, 240, 241},
    dark_white = {189, 195, 199},
    silver = {149, 165, 166},
    dark_silver = {127, 140, 141},
    ]]--

    bg = {16, 11, 9},
    white = {226, 226, 226},
    black = {120, 118, 121},
    violet = {133, 105, 207},
    blue = {13, 159, 216},
    green = {138, 215, 73},
    yellow = {238, 206, 0},
    orange = {248, 152, 31},
    red = {248, 14, 39},
    pink = {246, 64, 174},
}

UI.UI = require 'libraries/ui/UI'

UI:implement(UIRender)
UI:implement(UIPause)
UI:implement(UIDialogue)

function UI:new()
    fg.Fonts = {}
    fg.Fonts['helsinki'] = love.graphics.newFont('resources/fonts/helsinki.ttf', 256)
    fg.Fonts.helsinki:setFilter('linear', 'linear', 16)

    self.timer = fg.Timer()

    self.main_canvas = love.graphics.newCanvas(fg.screen_width, fg.screen_height, "normal", 8)

    self:UIRenderNew()
    self:UIPauseNew()
    self:UIDialogueNew()
end

function UI:update(dt)
    self.timer:update(dt)
    self:UIRenderUpdate(dt)
    self:UIPauseUpdate(dt)
    self:UIDialogueUpdate(dt)
end

function UI:draw()
    self.main_canvas:clear()
    self.main_canvas:renderTo(function()
        self:UIRenderDraw()
        self:UIDialogueDraw()
        self:UIPauseDraw()
    end)
    love.graphics.draw(self.main_canvas, 0, 0)
end

function UI:resize(w, h)
    self:UIRenderResize(w, h)
    self.main_canvas = love.graphics.newCanvas(w, h, "normal", 8)
end

function UI:createEntity(type, x, y, settings)
    if self.entities[type] then
        table.insert(self.entities[type], _G[type](x, y, settings))
    else
        self.entities[type] = {}
        table.insert(self.entities[type], _G[type](x, y, settings))
    end
end

function UI:transitionTo(scene_type, scene_info)
    if scene_type == 'dialogue' then
        self:diagActivate(scene_info)
    end
end


return UI
