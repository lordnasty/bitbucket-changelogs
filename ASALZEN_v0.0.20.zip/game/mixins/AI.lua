local AI = fg.Object:extend('AI')

function AI:AINew(settings)
    local settings = settings or {}

    self.ai_talk_mouth = nil
    self.behavior_tree = Root(self, null())
    --[[
        Sequence('attackVulnerableTarget', {
            isVulnerableTarget(),
            alert(),
            wait(1),
            moveToTargetForAttack(),
            meleeAttack(),
        })
    ]]--
end

function AI:AIUpdate(dt)
    self.behavior_tree:update(dt)
end

function AI:AIDraw()

end

function AI:moveTo(x, y)
    self:arriveOn(self.fg.Vector(x, y))
end

function AI:talk()
    self.ai_talk_mouth = 7
    self.timer:every('talking_change_mouth', 0.1, function()
        if self.ai_talk_mouth == 9 then
            self.ai_talk_mouth = 7
            self.head:restoreMouth()
            self.head:changeMouth(7)
        elseif self.ai_talk_mouth == 7 then
            self.ai_talk_mouth = 9
            self.head:restoreMouth()
            self.head:changeMouth(9)
        end
    end)
end

function AI:stopTalking()
    self.timer:cancel('talking_change_mouth')
    self.head:restoreMouth()
end

function AI:AISave()

end

return AI
