local null = Action:extend('null')

function null:new()
    null.super.new(self, 'null')
end

function null:update(dt, context)
    return null.super.update(self, dt, context)
end

function null:run(dt, context)
    
end

function null:start(context)

end

function null:finish(status, context)

end

return null
