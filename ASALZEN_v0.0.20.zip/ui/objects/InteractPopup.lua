local InteractPopup = fg.Object:extend('InteractPopup')

InteractPopup.layer = 'Outline_Text'

function InteractPopup:new(x, y, settings)
    self.fs = 24*fg.screen_scale/512 
    self.text = settings.text
    self.action = settings.action
    self.font = fg.Fonts.helsinki
    self.w = self.fs*self.font:getWidth(self.text)
    self.door = settings.parent
    self.x, self.y = fg.world.camera:getCameraCoords(self.door.x, self.door.y)
    self.timer = fg.Timer()
    self.black_key = false 
    self.timer:every(0.4, function() self.black_key = not self.black_key end)
    self.x_offset = settings.x_offset
    self.y_offset = settings.y_offset
end

function InteractPopup:update(dt)
    self.timer:update(dt)
    self.x, self.y = fg.world.camera:getCameraCoords(self.door.x + self.x_offset, self.door.y + self.y_offset)
    if self.door.dead then self.dead = true end

    self.fs = 24*fg.screen_scale/512
    self.w = self.fs*self.font:getWidth(self.text)
end

function InteractPopup:draw()
    local s = self.fs
    local bs = 0.2*fg.screen_scale
    if self.door.highlighted then
        love.graphics.setFont(self.font)
        love.graphics.setColor(unpack(UI.colors.white))
        love.graphics.print(self.text, self.x - self.w/2, self.y + 3*fg.screen_scale, 0, s, s)
        if self.action == 'use' then
            if last_pressed == 'Keyboard' then
                if self.black_key then love.graphics.draw(fg.Assets.kb_black_e, self.x + self.w/2 - 2*fg.screen_scale, self.y, 0, bs, bs)
                else love.graphics.draw(fg.Assets.kb_white_e, self.x + self.w/2 - 2*fg.screen_scale, self.y, 0, bs, bs) end
            elseif last_pressed == 'Gamepad' then
                love.graphics.draw(fg.Assets.ps3_square, self.x + self.w/2 - 2*fg.screen_scale, self.y, 0, bs, bs)
            end
        end
    end
end

return InteractPopup
