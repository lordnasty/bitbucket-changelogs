local Menu = fg.Object:extend('Menu')
local EditorObject = require 'editor/EditorObject'
local EditorUITheme = require('editor/EditorUITheme')

function Menu:menuNew(settings)
    local settings = settings or {}

    for i = 0, 9 do self.ei:bind(tostring(i), tostring(i)); self.ei:bind('kp' .. tostring(i), tostring(i)) end
    self.ei:bind('return', 'enter')

    self.choosing_first_key = nil
    self.choosing_second_key = nil

    self.ei:bind('t', 'tileset_choose')
    self.menu_current_tileset = nil
    self.choosing_tileset = false
    self.menu_tilesets = game.tilesets

    self.ei:bind('e', 'layer_choose')
    self.menu_current_layer = 'Default'
    self.choosing_layer = false
    self.menu_layers = {}
    local current_layer = nil
    local layers = fg.utils.table.copy(game.layers)
    for i, l in ipairs(layers) do 
        self.menu_layers[i] = {layer = l, active = false} 
        fg.world:deactivateLayer(l)
    end

    self.ei:bind('b', 'object_choose')
    self.choosing_object = false
    self.menu_objects = {}
    for k, v in pairs(game.objects) do 
        table.insert(self.menu_objects, {name = v.name, type = v.editor_type, image = v.image, color = v.color}) 
    end
    self.last_object = nil

    self.ei:bind('s', 'select')
    self.selecting = false

    self.ei:bind(' ', 'space')

    self.ei:bind('f', 'fill')
    self.filling = false

    self.ei:bind('i', 'collision')
    self.colliding = false

    self.ei:bind('l', 'load')
    self.loading = false
    self.map_load_list = {}
    for _, file in ipairs(love.filesystem.getDirectoryItems('resources/maps')) do
        table.insert(self.map_load_list, file)
    end
    self.to_be_loaded_map = self.map_load_list[#self.map_load_list]

    self.ei:bind('m', 'map_name')
    self.map_textinput = fg.ui.Textinput(10, 220, 100, 30, {text_max_length = 24, theme = EditorUITheme, font = self.font})
    self.map_textinput_selected = false
    self.map_textinput:setText('StartArea')
end

function Menu:menuUpdate(dt)
    if not self.inside_properties_frame and not self.map_textinput_selected then
        if self.ei:pressed('tileset_choose') then self:tilesetChoose() end
        if self.ei:pressed('layer_choose') then self:layerChoose() end
        if self.ei:pressed('object_choose') then self:objectChoose() end
        if self.ei:pressed('select') and not self.ei:down('lctrl') then self:select() end
        if self.ei:pressed('fill') then self:fill() end
        if self.ei:pressed('collision') then self:collision() end
        if self.ei:pressed('load') and not self.ei:down('lctrl') then self:load() end
    end

    self.map_textinput:update(dt)
    if self.map_textinput.selected then self.map_textinput_selected = true else self.map_textinput_selected = false end 

    if self.choosing_tileset and not self.inside_properties_frame and not self.map_textinput_selected then
        for i = 0, 9 do 
            if self.ei:pressed(tostring(i)) then
                if self.choosing_first_key then 
                    self.menu_current_tileset = self.menu_tilesets[tonumber(self.choosing_first_key .. i)]
                    if self.menu_current_tileset then self:addNotification('Current tileset: ' .. self.menu_current_tileset) end
                    self:tilesetChoose()
                    return
                end
                if not self.choosing_first_key then 
                    self.choosing_first_key = i 
                    local unique = true
                    for j, tileset in ipairs(self.menu_tilesets) do
                        if (math.floor(j/10) % 10) == self.choosing_first_key then
                            unique = false
                        end
                    end
                    if unique then
                        self.menu_current_tileset = self.menu_tilesets[tonumber(self.choosing_first_key)]
                        if self.menu_current_tileset then self:addNotification('Current tileset: ' .. self.menu_current_tileset) end
                        self:tilesetChoose()
                        return
                    end
                end
            end
            if self.ei:pressed('enter') then
                if self.choosing_first_key then
                    self.menu_current_tileset = self.menu_tilesets[tonumber(self.choosing_first_key)]
                    if self.menu_current_tileset then self:addNotification('Current tileset: ' .. self.menu_current_tileset) end
                    self:tilesetChoose()
                    return
                end
            end
        end
    end

    -- Doesn't work for double digits, fix whenever needed
    if self.choosing_layer and not self.inside_properties_frame and not self.map_textinput_selected then
        for i = 0, 9 do 
            if self.ei:pressed(tostring(i)) then
                self.choosing_first_key = i
            end
        end
        if self.ei:pressed('space') then
            if self.choosing_first_key then
                self.menu_layers[tonumber(self.choosing_first_key)].active = not self.menu_layers[tonumber(self.choosing_first_key)].active
                if self.menu_layers[tonumber(self.choosing_first_key)].active then
                    fg.world:activateLayer(self.menu_layers[tonumber(self.choosing_first_key)].layer)
                    self:addNotification('Layer activated: ' .. self.menu_layers[tonumber(self.choosing_first_key)].layer)
                else 
                    fg.world:deactivateLayer(self.menu_layers[tonumber(self.choosing_first_key)].layer) 
                    self:addNotification('Layer deactivated: ' .. self.menu_layers[tonumber(self.choosing_first_key)].layer)
                end
            end
        end
        if self.ei:pressed('enter') then
            if self.choosing_first_key then
                self.menu_current_layer = self.menu_layers[tonumber(self.choosing_first_key)].layer
                self.menu_layers[tonumber(self.choosing_first_key)].active = true
                fg.world:activateLayer(self.menu_layers[tonumber(self.choosing_first_key)].layer)
                if self.menu_current_layer then self:addNotification('Current layer: ' .. self.menu_current_layer) end
                self:layerChoose()
                return
            end
        end
    end

    if self.choosing_object and not self.inside_properties_frame and not self.map_textinput_selected then
        local x, y = love.mouse.getPosition()
        for i = 0, 9 do 
            if self.ei:pressed(tostring(i)) then
                if self.choosing_first_key then 
                    local object = self.menu_objects[tonumber(self.choosing_first_key .. i)]
                    self.last_object = object
                    self.menu_current_object = EditorObject(self, x, y, {name = object.name, type = object.type, color = object.color, z = object.z,
                                                                         image = object.image, properties = object.properties, w = object.w, h = object.h})
                    self:addNotification('Object to be spawned: ' .. object.name)
                    self:objectChoose()
                    return
                end
                if not self.choosing_first_key then 
                    self.choosing_first_key = i 
                    local unique = true
                    for j, object in ipairs(self.menu_objects) do
                        if (math.floor(j/10) % 10) == self.choosing_first_key then
                            unique = false
                        end
                    end
                    if unique then
                        local object = self.menu_objects[tonumber(self.choosing_first_key)]
                        self.last_object = object
                        self.menu_current_object = EditorObject(self, x, y, {name = object.name, type = object.type, color = object.color, z = object.z,
                                                                             image = object.image, properties = object.properties, w = object.w, h = object.h})
                        self:addNotification('Object to be spawned: ' .. object.name)
                        self:objectChoose()
                        return
                    end
                end
            end
            if self.ei:pressed('enter') then
                if self.choosing_first_key then
                    local object = self.menu_objects[tonumber(self.choosing_first_key)]
                    self.last_object = object
                    self.menu_current_object = EditorObject(self, x, y, {name = object.name, type = object.type, color = object.color, z = object.z,
                                                                         image = object.image, properties = object.properties, w = object.w, h = object.h})
                    self:addNotification('Object to be spawned: ' .. object.name)
                    self:objectChoose()
                    return
                end
            end
        end
    end

    if self.loading and not self.inside_properties_frame and not self.map_textinput_selected then
        for i = 0, 9 do 
            if self.ei:pressed(tostring(i)) then
                if self.choosing_first_key then 
                    self.to_be_loaded_map = self.map_load_list[tonumber(self.choosing_first_key .. i)]
                    self:addNotification('Map to be loaded: ' .. self.to_be_loaded_map)
                    self:load()
                    return
                end
                if not self.choosing_first_key then 
                    self.choosing_first_key = i 
                    local unique = true
                    for j, map in ipairs(self.map_load_list) do
                        if (math.floor(j/10) % 10) == self.choosing_first_key then
                            unique = false
                        end
                    end
                    if unique then
                        self.to_be_loaded_map = self.map_load_list[tonumber(self.choosing_first_key)]
                        self:addNotification('Map to be loaded: ' .. self.to_be_loaded_map)
                        self:load()
                        return
                    end
                end
            end
            if self.ei:pressed('enter') then
                if self.choosing_first_key then
                    self.to_be_loaded_map = self.map_load_list[tonumber(self.choosing_first_key)]
                    self:addNotification('Map to be loaded: ' .. self.to_be_loaded_map)
                    self:load()
                    return
                end
            end
        end
    end

    if self.ei:down('lctrl') and self.ei:pressed('select') and not self.inside_properties_frame and not self.map_textinput_selected then
        if #self.map_textinput.text > 0 then
            local save_data = {}
            for _, object in ipairs(self.objects) do
                local properties = object:getProperties()
                local target_id, source_id = nil, nil
                if object.target then target_id = object.target.id end
                if object.source then source_id = object.source.id end
                table.insert(save_data, {x = object.x, y = object.y, r = object.r, name = object.name, type = object.type, id = object.id, color = object.color,
                                         image = object.image, active = true, properties = properties, w = object.w, h = object.h, z = object.z,
                                         target_id = target_id, source_id = source_id, link_target_id = object.link_target_id, link_source_id = object.link_source_id})
            end
            game.levels[fg.current_area]:saveFromEditor(save_data, self.map_textinput.text)
            self:addNotification('Saved map: ' .. self.map_textinput.text)
            -- Refresh map load list
            self.map_load_list = {}
            for _, file in ipairs(love.filesystem.getDirectoryItems('resources/maps')) do table.insert(self.map_load_list, file) end
            self.to_be_loaded_map = self.map_textinput.text
            -- Refresh all maps list
            local map = self.map_textinput.text
            if not game.levels[map] then
                game.levels[map] = Level(game, map, 0, 0)
                for _, file in ipairs(love.filesystem.getDirectoryItems('resources/maps')) do table.insert(game.all_maps, file) end
            end
        end
    end

    if self.ei:down('lctrl') and self.ei:pressed('load') and not self.inside_properties_frame and not self.map_textinput_selected then
        if self.to_be_loaded_map then
            self:clear()
            self.map_textinput:setText(self.to_be_loaded_map)
            game.levels[fg.current_area]:loadToEditor(self.to_be_loaded_map)
            self:addNotification('Loaded map: ' .. self.to_be_loaded_map)
            self:activateNonEmptyLayers()
        end
    end
end

function Menu:menuDraw()
    if self.choosing_tileset then
        love.graphics.print('TileseT - ', 10, 10)
        for i, tileset in ipairs(self.menu_tilesets) do
            local j = math.floor((i-1)/10)
            if self.choosing_first_key then
                if i == self.choosing_first_key or 
                (math.floor(i/10) % 10) == self.choosing_first_key then
                    love.graphics.setColor(128, 128, 128, 128)
                    love.graphics.rectangle('fill', 85 + 140*j, 10 + 20*(i-1) - 200*j, 140, 20)
                end
            end
            love.graphics.setColor(255, 255, 255, 255)
            love.graphics.print(i .. ' ' .. tileset, 90 + 140*j, 10 + 20*(i-1) - 200*j)
        end

    elseif self.choosing_layer then
        love.graphics.print('layEr - ', 10, 40)
        for i, layer in ipairs(self.menu_layers) do
            local j = math.floor((i-1)/10)
            if self.choosing_first_key then
                if i == self.choosing_first_key or 
                (math.floor(i/10) % 10) == self.choosing_first_key then
                    love.graphics.setColor(128, 128, 128, 128)
                    love.graphics.rectangle('fill', 70 + 140*j, 40 + 20*(i-1) - 200*j, 140, 20)
                end
            end
            love.graphics.setColor(255, 255, 255, 255)
            love.graphics.print(i .. ' ' .. layer.layer, 75 + 140*j, 40 + 20*(i-1) - 200*j)
            if layer.active then love.graphics.rectangle('fill', 197 + 140*j, 40 + 20*(i-1) - 200*j + 5, 10, 10)
            else love.graphics.rectangle('line', 197 + 140*j, 40 + 20*(i-1) - 200*j + 5, 10, 10) end
        end

    elseif self.choosing_object then
        love.graphics.print('oBject - ', 10, 70)
        for i, object in ipairs(self.menu_objects) do
            local j = math.floor((i-1)/10)
            if self.choosing_first_key then
                if i == self.choosing_first_key or
                (math.floor(i/10) % 10) == self.choosing_first_key then
                    love.graphics.setColor(128, 128, 128, 128)
                    love.graphics.rectangle('fill', 83 + 140*j, 70 + 20*(i-1) - 200*j, 140, 20)
                end
            end
            love.graphics.setColor(255, 255, 255, 255)
            love.graphics.print(i .. ' ' .. object.name, 83 + 140*j, 70 + 20*(i-1) - 200*j)
        end
    elseif self.loading then
        love.graphics.print('Load - ', 10, 190)
        for i, map in ipairs(self.map_load_list) do
            local j = math.floor((i-1)/10)
            if self.choosing_first_key then
                if i == self.choosing_first_key or
                (math.floor(i/10) % 10) == self.choosing_first_key then
                    love.graphics.setColor(128, 128, 128, 128)
                    love.graphics.rectangle('fill', 66 + 140*j, 190 + 20*(i-1) - 200*j, 140, 20)
                end
            end
            love.graphics.setColor(255, 255, 255, 255)
            love.graphics.print(i .. ' ' .. map, 66 + 140*j, 190 + 20*(i-1) - 200*j)
        end
    else
        love.graphics.print('TileseT - ', 10, 10)
        love.graphics.print('layEr - ', 10, 40)
        love.graphics.print('oBject - ', 10, 70)
        if self.selecting then love.graphics.setColor(128, 128, 128, 128) love.graphics.rectangle('fill', 5, 100, 60, 20) end
        love.graphics.setColor(255, 255, 255, 255)
        love.graphics.print('Select', 10, 100)
        if self.filling then love.graphics.setColor(128, 128, 128, 128) love.graphics.rectangle('fill', 5, 130, 43, 20) end
        love.graphics.setColor(255, 255, 255, 255)
        love.graphics.print('Fill', 10, 130)
        if self.colliding then love.graphics.setColor(128, 128, 128, 128) love.graphics.rectangle('fill', 5, 160, 80, 20) end
        love.graphics.setColor(255, 255, 255, 255)
        love.graphics.print('collIsIon', 10, 160)
        love.graphics.print('Load - ', 10, 190)
        if self.menu_current_tileset then love.graphics.print(self.menu_current_tileset, 90, 10) end
        if self.menu_current_layer then love.graphics.print(self.menu_current_layer, 75, 40) end
        if self.menu_current_object then love.graphics.print(self.menu_current_object.name, 83, 70) end
        if self.to_be_loaded_map then love.graphics.print(self.to_be_loaded_map, 66, 190) end

        self.map_textinput:draw()
    end
end

function Menu:tilesetChoose()
    if self.choosing_layer or self.choosing_object or self.loading then return end
    self.choosing_tileset = not self.choosing_tileset
    if self.choosing_tileset then self:addNotification('Choosing tileset') end
    self.choosing_first_key = nil
    self.selecting = false 
    self.filling = false
    self:cancelFill()
    self:cancelSelection()
    self:cancelState()
end

function Menu:layerChoose()
    if self.choosing_tileset or self.choosing_object or self.loading then return end
    self.choosing_layer = not self.choosing_layer
    if self.choosing_layer then self:addNotification('Choosing layer') end
    self.choosing_first_key = nil
    self.selecting = false 
    self.filling = false
    self:cancelFill()
    self:cancelSelection()
    self:cancelState()
end

function Menu:objectChoose()
    if self.choosing_layer or self.choosing_tileset or self.loading then return end
    self.choosing_object = not self.choosing_object
    if self.choosing_object then self:addNotification('Choosing object') end
    self.choosing_first_key = nil
    self.selecting = false
    self.filling = false
    self:cancelFill()
    self:cancelSelection()
    self:cancelState()
end

function Menu:select()
    self:addNotification('Selecting')
    self.selected_tile = nil
    self.selecting = true
    self.filling = false
    self.colliding = false
end

function Menu:fill()
    self:addNotification('Filling')
    self.selecting = false
    self.filling = true 
    self.colliding = false
end

function Menu:collision()
    self.colliding = not self.colliding
    self.filling = false
    self.selecting = false
    if self.colliding then 
        self:addNotification('Entered collision mode')
        self:setLayersOpacity('Collision', 128)
        self.selected_tile = 1
        self.menu_current_layer = self.menu_layers[1].layer
        self.menu_layers[1].active = true
        fg.world:activateLayer(self.menu_layers[1].layer)
        if self.menu_current_layer then self:addNotification('Current layer: ' .. self.menu_current_layer) end
    else 
        self:addNotification('Exited collision mode')
        self:setLayersOpacity(nil, 255) 
        self.selected_tile = nil
        self.menu_current_layer = self.menu_layers[4].layer
        self.menu_layers[1].active = false
        fg.world:deactivateLayer(self.menu_layers[1].layer)
        self.menu_layers[4].active = true 
        fg.world:activateLayer(self.menu_layers[4].layer)
        if self.menu_current_layer then self:addNotification('Current layer: ' .. self.menu_current_layer) end
    end
end

function Menu:load()
    if self.choosing_layer or self.choosing_object or self.choosing_tileset then return end
    self.loading = not self.loading
    if self.loading then self:addNotification('Choosing map to load') end
    self.choosing_first_key = nil
    self.selecting = false
    self.filling = false
    self:cancelFill()
    self:cancelSelection()
    self:cancelState()
end

function Menu:activateNonEmptyLayers()
    -- Make sure only tilemaps that are not empty are shown
    for k, layer in ipairs(self.menu_layers) do
        local tilemap = game.levels[fg.current_area].tilemaps[layer.layer]
        local empty = true
        for i = 1, #tilemap.tile_grid do
            for j = 1, #tilemap.tile_grid[i] do
                if tilemap.tile_grid[i][j] ~= 0 then
                    empty = false
                end
            end
        end
        if not empty then
            self.menu_layers[k].active = true 
            fg.world:activateLayer(layer.layer)
            self.menu_current_layer = layer.layer
        end
    end
end

function Menu:setLayersOpacity(layer, opacity)
    for k, l in ipairs(self.menu_layers) do
        if layer then
            if l.layer ~= layer then fg.world:setLayerOpacity(l.layer, opacity) end
        else fg.world:setLayerOpacity(l.layer, 255) end
    end
end

return Menu
