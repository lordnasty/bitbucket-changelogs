local PlayerDisengageTrail = fg.Class('PlayerDisengageTrail', 'Entity')

function PlayerDisengageTrail:new(area, x, y, settings)
    local settings = settings or {}
    PlayerDisengageTrail.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    self.visual = self.fg.Assets.player_disengage_trail
    self.w, self.h = self.visual:getWidth()/2, self.visual:getHeight()/2
    self.alpha = 255
    self.timer:after(0.13, function() self.dead = true end)
    self.timer:tween(0.13, self, {alpha = 0}, 'in-out-cubic')
end

function PlayerDisengageTrail:update(dt)
    self.timer:update(dt)
end

function PlayerDisengageTrail:draw()
    love.graphics.setColor(32, 32, 32, self.alpha)
    love.graphics.draw(self.visual, self.x, self.y, self.r or 0, self.parent.animation_flip*1, 1, self.w/2 - self.offset_x/2, self.h/2 - self.offset_y/2)
    love.graphics.setColor(255, 255, 255, 255)
end

return PlayerDisengageTrail
