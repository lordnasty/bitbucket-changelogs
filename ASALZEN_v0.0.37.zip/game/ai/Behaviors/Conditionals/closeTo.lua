local closeTo = Action:extend('closeTo')

function closeTo:new(object_types, radius)
    closeTo.super.new(self, 'closeTo')

    self.object_types = object_types
    self.radius = radius
end

function closeTo:update(dt, context)
    return closeTo.super.update(self, dt, context)
end

function closeTo:run(dt, context)
    if context.any_around_entity then
        if mg.utils.logic.equalsAny(context.any_around_entity.class_name, self.object_types) then
            local x, y = context.any_around_entity.x, context.any_around_entity.y
            local distance = mg.Vector(context.object.body:getPosition()):dist(mg.Vector(x, y))
            if distance < self.radius then 
                return 'success'
            else 
                context.move_to_point_target = mg.Vector(x, y)
                return 'failure' 
            end
        end
    else return 'failure' end
end

function closeTo:start(context)

end

function closeTo:finish(status, context)

end

return closeTo
