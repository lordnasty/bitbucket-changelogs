require 'game/ai/BehaviorTree/Behavior'
require 'game/ai/BehaviorTree/Action'
require 'game/ai/BehaviorTree/Decorator'
require 'game/ai/BehaviorTree/Selector'
require 'game/ai/BehaviorTree/ActiveSelector'
require 'game/ai/BehaviorTree/Parallel'
require 'game/ai/BehaviorTree/Sequence'

Root = Behavior:extend('Root')

function Root:new(object, behavior)
    Root.super.new(self)
    self.behavior = behavior
    self.o = o
    self.c = {o = self.o}
end

function Root:update(dt)
    return Root.super.update(self, dt)
end

function Root:run(dt)
    return self.behavior:update(dt, self.c)
end

function Root:start()
    self.c = {o = self.o}
end

function Root:finish(status)
    
end

function Root:setObject(o)
    self.o = o
    self.c = {o = self.o}
end
