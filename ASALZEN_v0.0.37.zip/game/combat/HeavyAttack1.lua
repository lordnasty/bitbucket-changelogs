local HeavyAttack1 = fg.Object:extend('HeavyAttack1')

function HeavyAttack1:new(settings)
    local settings = settings or {}
    for k, v in pairs(settings) do self[k] = v end
    self.type = 'Attack'
    self.attacking = false
    self.down_value = fg.obv(0)
    self.first_hit_successful = false
    self.can_attack = true
    self.attack_cooldown = 0.4
end

function HeavyAttack1:update(dt)

end

function HeavyAttack1:interrupt()
    self.parent.movement_locked = false
    self.attacking = false
    self.parent['strong_punch_right_anticipation'] = false
    self.can_attack = true
    self.parent.timer:cancel('HeavyAttack1_cooldown')
    self.first_hit_successful = false
end

function HeavyAttack1:pressed()
    if not self.can_attack or self.attacking then return end
    self.can_attack = false
    self.parent.timer:after('HeavyAttack1_cooldown', self.attack_cooldown, function() self.can_attack = true end)
    self.pressed_time = love.timer.getTime()

    self.parent:interruptAttack()
    self.attacking = true
    self.parent.movement_locked = true
    self.parent:setAnimationDelay('strong_punch_right_anticipation', 0.06)
    self.parent:setAnimationDelay('strong_punch_right_anticipation_arm', 0.06)
    self.parent:playAnimationHoldFrame('strong_punch_right_anticipation', 4)
end

function HeavyAttack1:down(dt, down_value)
    if down_value and type(down_value) == 'number' then
        self.down_value:set(down_value)
        if self.down_value:ge(0.4) then self:pressed()
        elseif self.down_value:le(0.4) then self:released() end
    end
end

function HeavyAttack1:released()
    if love.timer.getTime() - self.pressed_time >= 0.3 then
        self.pressed_time = 1000000000
        self.parent['strong_punch_right_anticipation'] = false
        self.parent:playAnimFromFrame('strong_punch_right_anticipation', 4, {
            {0, function()
                self.attacking = false
                self.parent.movement_locked = false
                self.parent:setAnimationDelay('strong_punch_right_anticipation', 0.08)
                self.parent:setAnimationDelay('strong_punch_right_anticipation_arm', 0.08)
                self.first_hit_successful = false
            end},
            {5, function()
                local d = self.parent.animation_flip
                self.parent:push(d*1200, 0)
                self.parent.area:createEntity('MeleeArea', self.parent.x + 24*d, self.parent.y, {attack = self, source = self.parent, w = 32, h = 12, first_hit = true})
            end},
            {7, function()
                if self.first_hit_successful then
                    self.parent.timer:after('strong_punch_right_anticipation_8_int', 0.06, function()
                        local d = self.parent.animation_flip
                        self.parent.area:createEntity('MeleeArea', self.parent.x + 24*d, self.parent.y, {attack = self, source = self.parent, w = 32, h = 12})
                    end)
                else
                    local d = self.parent.animation_flip
                    self.parent.area:createEntity('MeleeArea', self.parent.x + 24*d, self.parent.y, {attack = self, source = self.parent, w = 32, h = 12})
                end
            end},
        })
    else self:interrupt() end
end

return HeavyAttack1
