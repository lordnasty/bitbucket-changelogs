local Person = fg.Class('Person', 'Entity')
Person:implement(fg.PhysicsBody)
Person:implement(Pseudo3D)
Person:implement(Shadow)
Person:implement(Animated)
Person:implement(Hittable)
Person:implement(Stats)
Person:implement(Combat)

function Person:new(area, x, y, settings)
    local settings = settings or {}
    Person.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    self:statsNew({settings = settings})
    self:physicsBodyNew(area, x, y, settings)
    self:pseudo3DNew({height_z = 50, settings = settings})
    self:animatedNew({animations = self.fg.person_animations, settings = settings})
    self.head = self.fg.world.areas[self.fg.current_area]:createEntityImmediate('PersonHead', self.x, self.y, {parent = self, no_layer = true, settings = settings})
    self:hittableNew({settings = settings})
    self:combatNew({settings = settings})

    self.type_coloring = love.graphics.newShader('resources/shaders/default.vert', 'resources/shaders/type_coloring.frag')
end

function Person:update(dt)
    self.timer:update(dt)
    self:physicsBodyUpdate(dt)
    self:pseudo3DUpdate(dt)
    self:animatedUpdate(dt)
    self.head:update(dt)
    self:hittableUpdate(dt)
    self:statsUpdate(dt)
    self:combatUpdate(dt)
end

function Person:draw()
    self:shadowDraw()

    if self.animation_state == 'kick' or self.animation_state == 'block' then
        self.head:draw()
        love.graphics.setShader(self.type_coloring)
        self:animatedDraw()
        love.graphics.setShader()

    elseif self.animation_state == 'uppercut' then
        local frame = self.animations.uppercut.animation.current_frame
        if frame >= 3 then
            self.head:draw()
            love.graphics.setShader(self.type_coloring)
            self:animatedDraw()
            love.graphics.setShader()
        elseif frame < 3 then
            love.graphics.setShader(self.type_coloring)
            self:animatedDraw()
            love.graphics.setShader()
            self.head:draw()
        end

    else
        love.graphics.setShader(self.type_coloring)
        self:animatedDraw()
        love.graphics.setShader()
        self.head:draw()
    end

    local animation = nil
    if self.animation_state == 'strong_punch_left' then animation = self.animations.strong_punch_left_arm 
    elseif self.animation_state == 'strong_punch_right' then animation = self.animations.strong_punch_right_arm end
    if self.animation_state == 'strong_punch_left_anticipation' then animation = self.animations.strong_punch_left_anticipation_arm 
    elseif self.animation_state == 'strong_punch_right_anticipation' then animation = self.animations.strong_punch_right_anticipation_arm end
    if animation then 
        love.graphics.setShader(self.type_coloring)
        animation.animation:draw(self.x, self.y, 0, self.animation_flip*(self.sx or 1), (self.sy or 1), -animation.x_offset, self.z - animation.y_offset) 
        love.graphics.setShader()
    end

    self:physicsBodyDraw()
    self:pseudo3DDraw()
end

function Person:highlightDraw()
    if self.animation_state == 'kick' or self.animation_state == 'block' then
        self.head:highlightDraw()
        self:animatedHighlightDraw()
    else
        self:animatedHighlightDraw()
        self.head:highlightDraw()
    end

    local animation = nil
    if self.animation_state == 'strong_punch_left' then animation = self.animations.strong_punch_left_arm 
    elseif self.animation_state == 'strong_punch_right' then animation = self.animations.strong_punch_right_arm end
    if self.animation_state == 'strong_punch_left_anticipation' then animation = self.animations.strong_punch_left_anticipation_arm 
    elseif self.animation_state == 'strong_punch_right_anticipation' then animation = self.animations.strong_punch_right_anticipation_arm end
    if animation then animation.animation:draw(self.x, self.y, 0, self.animation_flip*(self.sx or 1), (self.sy or 1), -animation.x_offset, self.z - animation.y_offset) end
end

function Person:onCollisionEnter(other, contact)

end

function Person:save()
    local pseudo_3d = self:pseudo3DSave()
    local hittable = self:hittableSave()
    local animated = self:animatedSave()
    local stats = self:statsSave()
    local combat = self:combatSave()
    local head = self.head:save()
    local save_data = {}
    for k, v in pairs(pseudo_3d) do save_data[k] = v end
    for k, v in pairs(hittable) do save_data[k] = v end
    for k, v in pairs(animated) do save_data[k] = v end
    for k, v in pairs(stats) do save_data[k] = v end
    for k, v in pairs(combat) do save_data[k] = v end
    for k, v in pairs(head) do save_data[k] = v end
    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y
    save_data.w, save_data.h = self.w, self.h
    save_data.shape = 'BSGRectangle'
    save_data.s = self.s
    return save_data
end

return Person
