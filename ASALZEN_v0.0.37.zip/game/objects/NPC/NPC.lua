local NPC = fg.Class('NPC', 'Person')
NPC:implement(Steerable)
NPC:implement(Agro)
NPC:implement(Fashion)

NPC.ignores = {'Table'}

function NPC:new(area, x, y, settings)
    local settings = settings or {}
    NPC.super.new(self, area, x, y, settings)

    self:steerableNew({settings = settings})
    self:agroNew({settings = settings})
    self:fashionNew({settings = settings})

    self.behavior_tree = (settings.character and settings.character.tree)
    self:bindActions(settings.character and settings.character.actions)
end

function NPC:update(dt)
    NPC.super.update(self, dt)

    if self.behavior_tree then self.behavior_tree:update(dt) end
    self:steerableUpdate(dt)
    self:agroUpdate(dt)
    self:fashionUpdate(dt)
end

function NPC:draw()
    NPC.super.draw(self)
end

function NPC:save()
    local save_data = NPC.super.save(self)
    local steerable = self:steerableSave()
    local agro = self:agroSave()
    for k, v in pairs(steerable) do save_data[k] = v end
    for k, v in pairs(agro) do save_data[k] = v end
    return save_data
end

return NPC
