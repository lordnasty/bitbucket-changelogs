local Fashion = fg.Object:extend('Fashion')

function Fashion:fashionNew(settings)
    local settings = settings or {}
end

function Fashion:fashionUpdate(dt)
    local r, g, b = unpack(self.head.hair_color)
    self.type_coloring:send('enemy_color', {math.min(r+48, 255)/255, math.min(g+48, 255)/255, math.min(b+48, 255)/255})
end

function Fashion:fashionDraw()

end

function Fashion:fashionSave()

end

return Fashion
