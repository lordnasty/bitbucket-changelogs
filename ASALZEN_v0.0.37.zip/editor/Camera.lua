local Camera = fg.Object:extend('Camera')

function Camera:cameraNew(settings)
    local settings = settings or {}

    self.just_pressed = 0
    self.ei:bind('left', 'camera_left')
    self.ei:bind('right', 'camera_right')
    self.ei:bind('up', 'camera_up')
    self.ei:bind('down', 'camera_down')
    self.ei:bind('wheelup', 'zoom_in')
    self.ei:bind('wheeldown', 'zoom_out')
    self.ei:bind('mouse2', 'right_click')

    self.border_move = false
    self.moving_left = false
    self.moving_right = false
    self.moving_up = false
    self.moving_down = false

    self.v = fg.Vector(0, 0)
    self.press_position = nil 
    self.moving_camera = false
end

function Camera:cameraUpdate(dt)
    local x, y = fg.world.camera:getPosition()

    if not self.inside_properties_frame and not self.map_textinput_selected then 
        if self.ei:pressed('camera_left') then
            fg.world.camera:moveTo(x - game.tile_width, y)
            self.just_pressed = love.timer.getTime()
        end
        if self.ei:pressed('camera_right') then
            fg.world.camera:moveTo(x + game.tile_width, y)
            self.just_pressed = love.timer.getTime()
        end
        if self.ei:pressed('camera_up') then
            fg.world.camera:moveTo(x, y - game.tile_height)
            self.just_pressed = love.timer.getTime()
        end
        if self.ei:pressed('camera_down') then
            fg.world.camera:moveTo(x, y + game.tile_height)
            self.just_pressed = love.timer.getTime()
        end

        if self.ei:down('camera_left') then
            local dx = love.timer.getTime() - self.just_pressed
            if dx > 0.2 then fg.world.camera:moveTo(x - game.tile_width, y) end
        end
        if self.ei:down('camera_right') then
            local dx = love.timer.getTime() - self.just_pressed
            if dx > 0.2 then fg.world.camera:moveTo(x + game.tile_width, y) end
        end
        if self.ei:down('camera_up') then
            local dx = love.timer.getTime() - self.just_pressed
            if dx > 0.2 then fg.world.camera:moveTo(x, y - game.tile_height) end
        end
        if self.ei:down('camera_down') then
            local dx = love.timer.getTime() - self.just_pressed
            if dx > 0.2 then fg.world.camera:moveTo(x, y + game.tile_height) end
        end
    end

    if not self.ei:down('lctrl') and self.ei:pressed('zoom_in') then
        fg.zoomIn(0.05)
    end
    if not self.ei:down('lctrl') and self.ei:pressed('zoom_out') then
        fg.zoomOut(0.05)
    end

    if self.ei:pressed('right_click') then
        self.press_position = fg.Vector(love.mouse.getPosition())
        self.moving_camera = true
    end

    local x, y = love.mouse.getPosition()
    if self.ei:down('right_click') and self.press_position then
        local dx, dy = self.press_position.x - x, self.press_position.y - y
        self.v.x = math.max(math.min(self.v.x + 0.1*dx*dt, 16), -16)
        self.v.y = math.max(math.min(self.v.y + 0.1*dy*dt, 16), -16)
    end

    if self.ei:released('right_click') then
        self.press_position = nil
        self.moving_camera = false
    end

    if self.border_move then
        self.moving_right = false
        self.moving_left = false
        self.moving_up = false
        self.moving_down = false

        local x, y = love.mouse.getPosition()
        local w, h = love.graphics.getWidth(), love.graphics.getHeight()
        local edge_size = 60
        if x >= w - edge_size and x <= w and y >= 0 and y <= h then
            local dx = x - (w - edge_size)
            self.v.x = math.min(self.v.x + dx*dt, 16)
            self.moving_right = true
        end
        if x >= 0 and x <= edge_size and y >= 0 and y <= h then
            local dx = edge_size - x
            self.v.x = math.max(self.v.x - dx*dt, -16)
            self.moving_left = true
        end
        if x >= 0 and x <= w and y >= 0 and y <= edge_size then
            local dy = edge_size - y
            self.v.y = math.max(self.v.y - dy*dt, -16)
            self.moving_up = true
        end
        if x >= 0 and x <= w and y >= h - edge_size and y <= h then
            local dy = y - (h - edge_size) 
            self.v.y = math.min(self.v.y + dy*dt, 16)
            self.moving_down = true
        end
    end

    fg.world.camera:move(self.v.x, self.v.y)
    self.v.x = self.v.x*0.90
    self.v.y = self.v.y*0.90
end

function Camera:cameraDraw()

end

return Camera
