local WaterDrop = fg.Class('WaterDrop', 'Entity')

function WaterDrop:new(area, x, y, settings)
    local settings = settings or {}
    WaterDrop.super.new(self, area, x, y, settings)
    self.water_drop = self.fg.Assets.sweatdrop
    self.z = self.fg.utils.math.random(200, 400)
    self.sx, self.sy = 0.35, 0.35
    self.gravity = self.fg.utils.math.random(350, 500)
end

function WaterDrop:update(dt)
    self.z = self.z - self.gravity*dt
    if self.z < 10 then self.dead = true end
end

function WaterDrop:draw()
    local w, h = self.water_drop:getWidth(), self.water_drop:getHeight()
    love.graphics.draw(self.water_drop, self.x, self.y - self.z, 0, self.sx, self.sy, w/2, h/2)
end

return WaterDrop
