local InteractPopup = fg.Object:extend('InteractPopup')

InteractPopup.layer = 'Outline_Text_Front'

function InteractPopup:new(x, y, settings)
    self.font_size = settings.font_size
    self.fs = (self.font_size or 24)*fg.screen_scale/512 
    self.text = settings.text
    self.action = settings.action
    self.font = fg.Fonts.helsinki
    self.w = self.fs*self.font:getWidth(self.text)
    self.parent = settings.parent
    if self.parent then self.x, self.y = fg.world.camera:getCameraCoords(self.parent.x, self.parent.y)
    else self.x, self.y = x, y end
    self.timer = fg.Timer()
    self.white_key = false 
    self.timer:every(0.4, function() self.white_key = not self.white_key end)
    self.x_offset = settings.x_offset
    self.y_offset = settings.y_offset
    self.r = settings.r or 0
    self.press_action = settings.press_action
    self.press_action_pressed = 0
    if self.action == 'skip' then ui.diag_skip = self end
end

function InteractPopup:update(dt)
    self.timer:update(dt)

    -- Door, LevelTransition
    if self.parent and (self.parent.class_name == 'Door' or self.parent.class_name == 'LevelTransition') then
        self.x, self.y = fg.world.camera:getCameraCoords(self.parent.x + self.x_offset, self.parent.y + self.y_offset)
        if self.parent.dead then self.dead = true end
    end

    self.fs = (self.font_size or 24)*fg.screen_scale/512
    self.w = self.fs*self.font:getWidth(self.text)

    if not self.parent then
        if self.action == 'skip' then
            self.x, self.y = fg.screen_width - self.w + 7*fg.screen_scale, fg.screen_height - self.fs*self.font:getHeight() - 16*fg.screen_scale
            if self.press_action then
                if fg.input:pressed(self.action) then 
                    self.press_action_pressed = love.timer.getTime()
                end
                if fg.input:down(self.action) then
                    if self.press_action_pressed ~= 0 then
                        if love.timer.getTime() - self.press_action_pressed >= 0.5 then
                            self:press_action()
                            self.press_action_pressed = 0
                        end
                    end
                end
                if fg.input:released(self.action) then
                    self.press_action_pressed = 0
                end
            end
        elseif self.text == 'ATTACK LEFT' then
            self.x, self.y = fg.screen_width/2 + 100*fg.screen_scale, fg.screen_height/2 - 20*fg.screen_scale
            if self.press_action then
                if fg.input:pressed(self.action) then
                    self:press_action()
                end
            end
        end
    end
end

function InteractPopup:draw()
    local s = self.fs
    local bs = 0.2*fg.screen_scale
    local gs = 0.1*fg.screen_scale
    local ts = 0.3*fg.screen_scale
    -- Door, LevelTransition
    if self.parent and self.parent.highlighted then
        love.graphics.setFont(self.font)
        love.graphics.setColor(unpack(UI.colors.white))
        love.graphics.print(self.text, self.x - self.w/2, self.y + 3*fg.screen_scale, self.r, s, s)
        if self.action == 'action' then
            if last_pressed == 'Keyboard' then
                if self.white_key then love.graphics.draw(fg.Assets.kb_white_e, self.x + self.w/2 - 2*fg.screen_scale, self.y, 0, bs, bs) 
                else love.graphics.draw(fg.Assets.kb_black_e, self.x + self.w/2 - 2*fg.screen_scale, self.y, 0, bs, bs) end
            elseif last_pressed == 'Gamepad' then
                ui:drawFaceButtons(self.x + self.w/2 + 12*fg.screen_scale, self.y + 12*fg.screen_scale, math.pi/12, {'down'}, {self.white_key or fg.input:down(self.action)})
            end
        end
    end

    -- Skip
    if not self.parent then
        love.graphics.setFont(self.font)
        love.graphics.setColor(unpack(UI.colors.white))
        love.graphics.print(self.text, self.x - self.w/2, self.y, self.r, s, s)
        if self.action == 'skip' then
            if last_pressed == 'Keyboard' then
                love.graphics.setColor(unpack(UI.colors.white))
                local d, xo, yo = 0, 0, 0
                if self.press_action_pressed ~= 0 then d = 2*(love.timer.getTime() - self.press_action_pressed) end
                if d >= 1 then xo, yo = fg.screen_scale*fg.utils.math.random(-0.5, 0.5), fg.screen_scale*fg.utils.math.random(-0.5, 0.5) end
                fg.utils.graphics.pushRotate(self.x, self.y, self.r)
                love.graphics.rectangle('fill', self.x - self.w/2 - 14*fg.screen_scale + xo, self.y + 12*fg.screen_scale + yo, 
                                        math.max(0, math.min(d*self.w, self.w)), 2*fg.screen_scale)
                love.graphics.pop()
                love.graphics.draw(fg.Assets.kb_black_k, self.x - self.w/2 - 18*fg.screen_scale, self.y + 5*fg.screen_scale, self.r, bs, bs)
            elseif last_pressed == 'Gamepad' then
                local d = 0
                if self.press_action_pressed ~= 0 then d = 2*(love.timer.getTime() - self.press_action_pressed) end
                ui:drawFaceButtons(self.x - self.w/2 - 2*fg.screen_scale, self.y + 16*fg.screen_scale, 0, {'right'}, {self.white_key or fg.input:down(self.action)}, d)
            end
        elseif self.text == 'ATTACK LEFT' then
            love.graphics.setColor(189, 90, 90, 255)
            love.graphics.draw(fg.Assets.triangle, self.x - self.w/2 - 3*fg.screen_scale, self.y + 6*fg.screen_scale, math.pi, 0.5*fg.screen_scale, 0.5*fg.screen_scale, 0, fg.Assets.triangle:getHeight()/2)
            love.graphics.setColor(255, 255, 255, 255)
            if self.white_key then love.graphics.draw(fg.Assets.gp_left_white, self.x + self.w/2 + 3*fg.screen_scale, self.y, 0, bs, bs, 0, fg.Assets.gp_left_white:getHeight()/4) 
            else love.graphics.draw(fg.Assets.gp_left_black, self.x + self.w/2 + 3*fg.screen_scale, self.y, 0, bs, bs, 0, fg.Assets.gp_left_black:getHeight()/4) end
        end
    end
end

return InteractPopup
