local UIButton = fg.Object:extend('UIButton')

function UIButton:new(x, y, w, h, settings)
    self.button = UI.UI.Button(x, y, w, h, {extensions = {UITheme.Button}, text = settings.text, font = settings.font, color = settings.color})
    self.button.fs = 36*fg.screen_scale/512
    self.button.w = self.button.fs*self.button.font:getWidth(self.button.text) + 250*fg.screen_scale
end

function UIButton:update(dt)
    self.button:update(dt)
    self.button.fs = 36*fg.screen_scale/512
    self.button.w = self.button.fs*self.button.font:getWidth(self.button.text) + 250*fg.screen_scale
end

function UIButton:draw()
    self.button:draw()
end

return UIButton
