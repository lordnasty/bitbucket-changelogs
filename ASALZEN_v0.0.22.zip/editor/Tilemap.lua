local Tilemap = fg.Object:extend('Tilemap')
local EditorObject = require 'editor/EditorObject'

function Tilemap:tilemapNew(settings)
    local settings = settings or {}

    self.ei:bind('lctrl', 'lctrl')
    self.ei:bind('delete', 'delete')
    self.ei:bind('c', 'copy')
    self.ei:bind('x', 'cut')
    self.ei:bind('v', 'paste')
    self.ei:bind('z', 'undo')

    self.current_selected_tiles = {}
    self.saved_selected_tiles = {}
    self.selected_tiles = {}
    self.selection_start = nil
    self.tiles_copy_buffer = {}
    self.pasting = false
    self.copying = false
    self.cutting = false
    self.fill_tiles = {}

    self.state_stack = {}
    self.stack_pointer = 1
end

function Tilemap:tilemapUpdate(dt)
    if self.menu_current_layer and not self.inside_properties_frame then
        local tilemap = game.levels[fg.current_area].tilemaps[self.menu_current_layer]

        -- Tile change
        if self.selected_tile and not self.inside_tileset_display and self.inside_grid and not self.filling then
            if self.ei:pressed('mouse1') then
                self:pushToStack({grid = fg.utils.table.copy(tilemap.tile_grid)})
            end
            if self.ei:down('mouse1') then
                tilemap:changeTile(self.grid_y, self.grid_x, self.selected_tile)
            end
        end

        -- Selection
        if not self.selected_tile and not self.inside_tileset_display and self.inside_grid and self.selecting then
            if self.ei:pressed('mouse1') and not self.ei:down('lctrl') then 
                self.selection_start = fg.Vector(fg.world.camera:getWorldCoords(love.mouse.getPosition()))
                self.saved_selected_tiles = {}
            end

            if self.ei:pressed('mouse1') and self.ei:down('lctrl') then
                self.selection_start = fg.Vector(fg.world.camera:getWorldCoords(love.mouse.getPosition()))
            end

            if self.ei:released('mouse1') then
                self.current_selected_tiles = {}
                local x, y = fg.world.camera:getWorldCoords(love.mouse.getPosition())
                local x1, y1 = self.selection_start.x + tilemap.w/2, self.selection_start.y + tilemap.h/2
                local x2, y2 = x + tilemap.w/2, y + tilemap.h/2
                local x1g, y1g = math.floor(x1/tilemap.tile_width)+1, math.floor(y1/tilemap.tile_height)+1
                local x2g, y2g = math.floor(x2/tilemap.tile_width)+1, math.floor(y2/tilemap.tile_height)+1
                local temp = x1g; if x1g > x2g then x1g = x2g; x2g = temp end
                local temp = y1g; if y1g > y2g then y1g = y2g; y2g = temp end
                for i = x1g, x2g do
                    for j = y1g, y2g do
                        table.insert(self.current_selected_tiles, {x = i, y = j, n = tilemap:getTile(j, i)})
                    end
                end
                self.selection_start = nil
                for _, t in ipairs(self.current_selected_tiles) do
                    table.insert(self.saved_selected_tiles, t)
                end
                self.current_selected_tiles = {}
                self.selected_tiles = fg.fn.unique(fg.fn.append(self.current_selected_tiles, self.saved_selected_tiles))
            end
        end

        --[[
        -- Stop when out of grid
        if not self.inside_grid and self.selection_start then
            self.selection_start = nil
            for _, t in ipairs(self.current_selected_tiles) do
                table.insert(self.saved_selected_tiles, t)
            end
            self.current_selected_tiles = {}
        end
        ]]--

        -- Cancel selection on ESC
        if (self.selecting or self.selection_start) and self.ei:pressed('escape') then
            self:cancelSelection()
        end

        -- Cancel fill on ESC
        if self.filling and self.ei:pressed('escape') then
            self:cancelFill()
        end

        -- Undo
        if self.ei:down('lctrl') and self.ei:pressed('undo') then
            self.selected_tiles = fg.fn.unique(fg.fn.append(self.current_selected_tiles, self.saved_selected_tiles))
            self:readFromStackUndo()
            self:cancelState()
        end
    end

    if self.selecting and not self.inside_properties_frame and not self.map_textinput_selected then
        -- Delete selected tiles
        if self.ei:pressed('delete') then 
            self.selected_tiles = fg.fn.unique(fg.fn.append(self.current_selected_tiles, self.saved_selected_tiles))
            self:delete() 
        end

        -- Copy selected tiles
        if self.ei:down('lctrl') and self.ei:pressed('copy') then 
            self.selected_tiles = fg.fn.unique(fg.fn.append(self.current_selected_tiles, self.saved_selected_tiles))
            self:copy() 
        end

        -- Cut selected tiles
        if self.ei:down('lctrl') and self.ei:pressed('cut') then 
            self.selected_tiles = fg.fn.unique(fg.fn.append(self.current_selected_tiles, self.saved_selected_tiles))
            self:cut() 
        end

        -- Pre-paste selected tiles
        if self.ei:down('lctrl') and self.ei:pressed('paste') then 
            self:paste() 
        end
    end

    -- Paste selected tiles
    if self.pasting and not self.inside_properties_frame and not self.map_textinput_selected then
        local tilemap = game.levels[fg.current_area].tilemaps[self.menu_current_layer]
        if self.ei:pressed('mouse1') then
            local min_xy, min_i = 10000, 0
            for i, t in ipairs(self.tiles_copy_buffer) do
                local xy = t.x + t.y
                if xy < min_xy then min_xy = xy; min_i = i end
            end
            self:pushToStack({grid = fg.utils.table.copy(tilemap.tile_grid)})
            local mx, my = self.tiles_copy_buffer[min_i].x, self.tiles_copy_buffer[min_i].y
            for _, t in ipairs(self.tiles_copy_buffer) do
                local x, y = self.grid_x + t.x - mx, self.grid_y + t.y - my
                tilemap:changeTile(y, x, t.n)
            end

            -- If was cutting then end cut+paste operation
            if self.cutting then 
                self.tiles_copy_buffer = {} 
                self.cutting = false
                self.pasting = false
                self.copying = false
            end
        end

        -- Only way to get out of copy+paste operation
        if self.ei:pressed('escape') then
            self.pasting = false
            self.cutting = false
            self.copying = false
        end
    end

    -- Fill
    if self.filling and self.grid_x and self.grid_y and not self.inside_properties_frame and not self.map_textinput_selected then
        self:findFillTiles(self.grid_x, self.grid_y)
        local tilemap = game.levels[fg.current_area].tilemaps[self.menu_current_layer]
        if self.ei:pressed('mouse1') then
            self:pushToStack({grid = fg.utils.table.copy(tilemap.tile_grid)})
            for _, ft in ipairs(self.fill_tiles) do
                tilemap:changeTile(ft.y, ft.x, self.selected_tile)
            end
            self.fill_tiles = {}
        end
        if self.ei:pressed('escape') then self:cancelFill() end
    end
end

function Tilemap:tilemapDraw()
    local x, y = love.mouse.getPosition()
    local tilemap = game.levels[fg.current_area].tilemaps[self.menu_current_layer]

    -- Draw selected tiles
    love.graphics.setColor(160, 160, 160, 64)
    for _, st in ipairs(self.selected_tiles) do
        local x1, y1 = fg.world.camera:getCameraCoords((st.x-1)*tilemap.tile_width + tilemap.x - tilemap.w/2, (st.y-1)*tilemap.tile_height + tilemap.y - tilemap.h/2)
        love.graphics.rectangle('fill', x1, y1, fg.screen_scale*tilemap.tile_width, fg.screen_scale*tilemap.tile_height)
    end

    love.graphics.setColor(255, 255, 255, 128)
    -- Draw paste tiles on mouse
    if self.pasting then
        local min_xy, min_i = 10000, nil
        for i, t in ipairs(self.tiles_copy_buffer) do
            local xy = t.x + t.y
            if xy < min_xy then min_xy = xy; min_i = i end
        end
        local mx, my = self.tiles_copy_buffer[min_i].x, self.tiles_copy_buffer[min_i].y
        for _, t in ipairs(self.tiles_copy_buffer) do
            if self.tileset_id ~= 0 then
                local quad = tilemap.quads[self.tileset_id][t.n - self.tileset_id_sub]
                if self.grid_x and self.grid_y and quad then
                    local rx, ry = fg.world.camera:getCameraCoords(-tilemap.w/2 + (self.grid_x-1+t.x-mx)*tilemap.tile_width, 
                                                                   -tilemap.h/2 + (self.grid_y-1+t.y-my)*tilemap.tile_height)
                    love.graphics.draw(tilemap.tilesets[self.tileset_id], quad, rx, ry, 0, fg.screen_scale, fg.screen_scale)
                end
            end
        end
    end

    -- Draw fill tiles
    if self.filling and self.selected_tile then
        for _, ft in ipairs(self.fill_tiles) do
            local quad = tilemap.quads[self.tileset_id][self.selected_tile - self.tileset_id_sub]
            local rx, ry = fg.world.camera:getCameraCoords((ft.x-1)*tilemap.tile_width - tilemap.w/2, (ft.y-1)*tilemap.tile_height - tilemap.h/2)
            love.graphics.draw(tilemap.tilesets[self.tileset_id], quad, rx, ry, 0, fg.screen_scale, fg.screen_scale)
        end
    end

    love.graphics.setColor(255, 255, 255, 255)
end

function Tilemap:cancelSelection()
    self.selecting = false
    self.selection_start = nil
    self.current_selected_tiles = {}
    self.saved_selected_tiles = {}
    self.selected_tiles = {}
end

function Tilemap:cancelFill()
    self.filling = false
    self.fill_tiles = {}
end

function Tilemap:delete()
    local tilemap = game.levels[fg.current_area].tilemaps[self.menu_current_layer]
    self:pushToStack({grid = fg.utils.table.copy(tilemap.tile_grid)})
    for _, t in ipairs(self.selected_tiles) do tilemap:removeTile(t.y, t.x) end
    self:cancelSelection()
    self.selecting = true
end

function Tilemap:copy()
    self.copying = true
    self.tiles_copy_buffer = {}
    self.tiles_copy_buffer = fg.utils.table.copy(self.selected_tiles)
    self:cancelFill()
end

function Tilemap:cut()
    self.cutting = true
    self:copy()
    self:delete()
    self:cancelFill()
end

function Tilemap:paste()
    self.pasting = true
    self:cancelSelection()
    self:cancelFill()
    if not self.menu_current_tileset then
        self.menu_current_tileset = self.menu_tilesets[1]
    end
end

function Tilemap:fill()
    self.filling = true
    self:cancelSelection()
end

function Tilemap:findFillTiles(x, y)
    local tilemap = game.levels[fg.current_area].tilemaps[self.menu_current_layer]
    local w, h = math.floor(tilemap.w/tilemap.tile_width), math.floor(tilemap.h/tilemap.tile_height)
    self.fill_tiles = {}
    local function floodFill(x, y)
        if tilemap.tile_grid[y] then
            if tilemap.tile_grid[y][x] then
                if tilemap.tile_grid[y][x] == 0 then 
                    local out = nil
                    for _, t in ipairs(self.fill_tiles) do
                        if t.x == x and t.y == y then
                            out = true
                        end
                    end
                    if out then return end
                    table.insert(self.fill_tiles, {x = x, y = y}) 
                    floodFill(x-1, y)
                    floodFill(x+1, y)
                    floodFill(x, y-1)
                    floodFill(x, y+1)
                end
            end
        end
    end
    floodFill(x, y)
end

function Tilemap:pushToStack(pushed)
    fg.fn.addTop(self.state_stack, pushed)
end

function Tilemap:readFromStackUndo()
    local tilemap = game.levels[fg.current_area].tilemaps[self.menu_current_layer]
    local element = self.state_stack[1]
    if not element then return end
    for k, v in pairs(element) do
        if element.grid then
            for i = 1, #element.grid do
                for j = 1, #element.grid[i] do
                    tilemap:removeTile(i, j)
                end
            end
            for i = 1, #element.grid do
                for j = 1, #element.grid[i] do
                    tilemap:changeTile(i, j, element.grid[i][j])
                end
            end
        elseif element.objects then
            for i, state in ipairs(element.objects) do
                local object = unpack(fg.fn.select(self.objects, function(key, value) 
                    if value.id == state.object.id then return true end 
                end))
                if state.object.position then
                    object.x, object.y = state.object.position.x, state.object.position.y
                end
                if state.object.rotation then
                    object.r = state.object.rotation.r
                end
                if state.object.object then
                    local object = state.object.object
                    table.insert(self.objects, EditorObject(self, object.x, object.y, 
                    {id = object.id, name = object.name, type = object.type, color = object.color, w = object.w, h = object.h, z = object.z,
                     image = object.image, r = object.r, active = true, selected = true, properties = object.properties,
                     source = object.source, target = object.target, x1 = object.x1, y1 = object.y1, x2 = object.x2, y2 = object.y2}))
                end
            end
        else 
            self[k] = v 
        end
    end
    table.remove(self.state_stack, 1)
end

return Tilemap
