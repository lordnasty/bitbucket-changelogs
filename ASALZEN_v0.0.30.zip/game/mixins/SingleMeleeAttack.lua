local SingleMeleeAttack = fg.Object:extend('SingleMeleeAttack')

local lock_targets = {'PersonAI'}

function SingleMeleeAttack:singleMeleeAttackNew(settings)
    local settings = settings or {}

    for _, key_action in ipairs(settings.keys) do self.fg.input:bind(key_action[1], key_action[2]) end
    self.attack_locked = false
    self.melee_attack_entity_queue = {}
    self.melee_attack_closest_entity = nil
    self.melee_attack_next_closest_entity = nil
    self.melee_attack_locked = false -- external, when the player is locked to an enemy radius-wise, not after it attempts a hit
    self.melee_attack_hit_locked = false
    self.melee_attack_movement_locked = false -- external, after the player starts actual combat with an enemy and he can't move until that enemy dies
    self.melee_attack_line_locked = false
    self.melee_attack_lock_radius = settings.settings.melee_attack_lock_radius or 200
    self.melee_attack_new_p = nil
    self.melee_attack_first_hit = true
    self.vulnerable_to_attack = false -- external, first miss vulnerability
    self.light_punch_left = settings.settings.light_punch_left or false
    self.light_punch_right = settings.settings.light_punch_right or false
    self.strong_punch_left = settings.settings.strong_punch_left or false
    self.strong_punch_right = settings.settings.strong_punch_right or false
    self.kick = settings.settings.kick or false
    self.low_dash = settings.settings.low_dash or false
    self.dash = settings.settings.dash or false
    self.backdash = settings.settings.backdash or false
    self.block = settings.settings.block or false

    self.melee_attack_left_select = self.fg.obv(false)
    self.melee_attack_right_select = self.fg.obv(false)
    self.melee_attack_queue_index = 1
    self.attack_line = self.area:createEntityImmediate('AttackLineVisual', -10000, -10000)
    self.closest_attack_lock = self.area:createEntityImmediate('AttackLockVisual', -10000, -10000)
end

function SingleMeleeAttack:singleMeleeAttackUpdate(dt)
    -- Lock logic
    local entities = self.fg.fn.select(self.fg.world.areas[self.fg.current_area]:queryAreaCircle(self.x, self.y, self.melee_attack_lock_radius, lock_targets), function(k, v) 
        if v.id ~= self.id and not v.dying and not v.stage_decreasing then return true end 
    end)

    -- Sort entities based on proximity to player
    table.sort(entities, function(a, b)
        local d1 = self.fg.mlib.line.getDistance(self.x, self.y, a.body:getPosition())
        local d2 = self.fg.mlib.line.getDistance(self.x, self.y, b.body:getPosition())
        if d1 < d2 then return true end
    end)

    -- Insert closest and second closest if they're not already in the array
    for i = 1, #entities do
        if entities[i] then
            if not self.fg.fn.contains(self.melee_attack_entity_queue, function(v) if v.id == entities[i].id then return true end end) then
                table.insert(self.melee_attack_entity_queue, entities[i])
            end
        end
    end

    -- Remove entities that are far away enough
    for i = #self.melee_attack_entity_queue, 1, -1 do
        local d = self.fg.mlib.line.getDistance(self.x, self.y, self.melee_attack_entity_queue[i].x, self.melee_attack_entity_queue[i].y)
        if d > 1.5*self.melee_attack_lock_radius or self.melee_attack_entity_queue[i].dying or self.melee_attack_entity_queue[i].stage_decreasing then 
            self.melee_attack_entity_queue[i].lock_selected_for_combat = false
            table.remove(self.melee_attack_entity_queue, i) 
        end
    end

    if self.melee_attack_queue_index < 1 then self.melee_attack_queue_index = 1 end
    if self.melee_attack_queue_index > #self.melee_attack_entity_queue then self.melee_attack_queue_index = #self.melee_attack_entity_queue end
    self.melee_attack_closest_entity = self.melee_attack_entity_queue[self.melee_attack_queue_index]
    local next_index = self.melee_attack_queue_index + 1
    if next_index > #self.melee_attack_entity_queue then next_index = 1 end
    self.melee_attack_next_closest_entity = self.melee_attack_entity_queue[next_index]

    -- Set lock selected for combat
    for _, entity in ipairs(self.melee_attack_entity_queue) do entity.lock_selected_for_combat = false end
    if self.melee_attack_closest_entity then self.melee_attack_closest_entity.lock_selected_for_combat = true end
    if self.melee_attack_next_closest_entity then self.melee_attack_next_closest_entity.lock_selected_for_combat = true end

    -- Set melee attack locked
    if self.melee_attack_locked and not self.melee_attack_closest_entity then self.melee_attack_locked = false
    elseif not self.melee_attack_locked and self.melee_attack_closest_entity then self.melee_attack_locked = true end
    if not self.melee_attack_locked then self.melee_attack_first_hit = true end

    -- Attack logic
    if self.melee_attack_closest_entity and not self.attack_locked then
        local attack_type = nil
        if self.fg.input:pressed('leftAttack') then attack_type = 'left' end
        if self.fg.input:pressed('rightAttack') then attack_type = 'right' end

        -- If attack pressed...
        if attack_type and not self.vulnerable_to_attack then
            -- First attack
            if self.melee_attack_first_hit then
                self.melee_attack_first_hit = false 
                self.melee_attack_line_locked = true
                self.melee_attack_hit_locked = true
                self.melee_attack_movement_locked = true
                local hit = self.melee_attack_closest_entity.hp_seq:hitOrMiss(attack_type)
                -- First hit
                if hit then
                    self.melee_attack_closest_entity.engaged_in_single_combat = true
                    self:singleMeleeAttackTweenTo(self.melee_attack_closest_entity.x, self.melee_attack_closest_entity.y, 30, 0)
                    self.timer:after(0.08, function() 
                        self:singleMeleeAttack(attack_type) 
                        self.melee_attack_hit_locked = false
                    end)
                -- First miss
                else
                    self:singleMeleeAttackTweenTo((self.melee_attack_closest_entity.x + self.x)/2, (self.melee_attack_closest_entity.y + self.y)/2)
                    self.vulnerable_to_attack = true
                    self.area:createEntity('SweatDrop', self.x, self.y, {parent = self, x_offset = 12, y_offset = -45})
                    self.melee_attack_closest_entity.o_vulnerable_target:setd(self)
                    self.timer:after(0.06, function() 
                        self:playAnimation('strong_punch_' .. attack_type, function()
                            local animation = self.animations['strong_punch_' .. attack_type].animation
                            self['strong_punch_' .. attack_type] = true
                            animation:seek(animation.size)
                            animation:stop()
                            self.timer:after(1.5, function()
                                self.vulnerable_to_attack = false
                                self.melee_attack_movement_locked = false
                                self.melee_attack_hit_locked = false
                                self.melee_attack_line_locked = false
                                self.melee_attack_first_hit = true
                                self['strong_punch_' .. attack_type] = false
                                animation:reset()
                                animation:play()
                            end)
                        end)
                    end)
                end
            -- Not first attack, just attack
            else 
                self.melee_attack_closest_entity.engaged_in_single_combat = true
                self.melee_attack_hit_locked = true
                self:singleMeleeAttackTweenTo(self.melee_attack_closest_entity.x, self.melee_attack_closest_entity.y, 30, 0)
                self.timer:after(0.06, function()
                    self:singleMeleeAttack(attack_type) 
                    self.melee_attack_hit_locked = false
                end)
            end
        end
    end

    -- Set camera follow
    if self.melee_attack_closest_entity then
        self.fg.world.camera:follow({x = (self.x + self.melee_attack_closest_entity.x)/2, y = (self.y + self.melee_attack_closest_entity.y)/2}, {follow_style = 'lockon', lerp = 20})
    else self.fg.world.camera:follow(self, {follow_style = 'lockon', lerp = 10}) end

    -- Fix player's position if he has started attack on enemy
    if self.melee_attack_hit_locked then self.body:setPosition(self.melee_attack_new_p.x, self.melee_attack_new_p.y) end

    -- Attack lock selection
    if not self.melee_attack_hit_locked then
        self.melee_attack_left_select:set(self.fg.input:down('leftSelect'))
        self.melee_attack_right_select:set(self.fg.input:down('rightSelect'))
        if last_pressed == 'Gamepad' then
            if self.melee_attack_left_select.v and self.melee_attack_left_select.prev_v and self.melee_attack_left_select:ge(0.5) then self:singleMeleeAttackChoosePrevious() end
            if self.melee_attack_right_select.v and self.melee_attack_right_select.prev_v and self.melee_attack_right_select:ge(0.5) then self:singleMeleeAttackChooseNext() end
        elseif last_pressed == 'Keyboard' then
            if self.fg.input:pressed('leftSelect') then self:singleMeleeAttackChoosePrevious() end
            if self.fg.input:pressed('rightSelect') then self:singleMeleeAttackChooseNext() end
        end
    end

    -- Set attack lock parents
    if self.melee_attack_closest_entity then self.closest_attack_lock.parent = self.melee_attack_closest_entity
    else self.closest_attack_lock.parent = nil end
    self.closest_attack_lock:update(dt)

    -- Set attack line targets
    if self.melee_attack_closest_entity and not self.melee_attack_line_locked then
        self.attack_line.target_1 = self
        self.attack_line.target_2 = self.melee_attack_closest_entity
    end
    if self.melee_attack_line_locked and not self.melee_attack_hit_locked then
        if self.melee_attack_next_closest_entity then
            self.attack_line.target_1 = self
            self.attack_line.target_2 = self.melee_attack_next_closest_entity
        else
            self.attack_line.target_1 = nil
            self.attack_line.target_2 = nil
        end
    end
    if not self.melee_attack_closest_entity then 
        self.attack_line.target_1 = nil
        self.attack_line.target_2 = nil
    end
end

function SingleMeleeAttack:singleMeleeAttackDraw()
    --[[
    love.graphics.setColor(244, 244, 64)
    love.graphics.circle('line', self.x, self.y, self.melee_attack_lock_radius)
    love.graphics.setColor(64, 244, 244)
    love.graphics.circle('line', self.x, self.y, 1.5*self.melee_attack_lock_radius)
    ]]--
end

function SingleMeleeAttack:singleMeleeAttackChooseNext()
    self.melee_attack_queue_index = self.melee_attack_queue_index + 1
    if self.melee_attack_queue_index > #self.melee_attack_entity_queue then self.melee_attack_queue_index = 1 end
end

function SingleMeleeAttack:singleMeleeAttackChoosePrevious()
    self.melee_attack_queue_index = self.melee_attack_queue_index - 1
    if self.melee_attack_queue_index < 1 then self.melee_attack_queue_index = #self.melee_attack_entity_queue end
end

function SingleMeleeAttack:singleMeleeAttack(attack_side)
    local object = self.melee_attack_closest_entity.entity or self.melee_attack_closest_entity
    if not object then return end
    local random = self.fg.utils.math.random
    local dx, dy = object.x - self.x, object.y - self.y
    if dx < 0 then dx = -1 else dx = 1 end
    if dy < 0 then dy = -1 else dy = 1 end

    -- Blood particles
    local spawnBloodEnemy = function()
        local z = object.z + object.height_z - 6
        local n = math.random(2, 4)
        for i = 1, n do self.area:createEntity('BloodParticle', object.x + 4*dx, object.y, {v = fg.Vector(dx*random(150, 250), random(-25, 25)), z = z, v_z = -random(0, 50)}) end
    end
    local spawnBloodSelf = function()
        local z = self.z + self.height_z - 6
        local n = math.random(2, 4)
        for i = 1, n do self.area:createEntity('BloodParticle', self.x - 4*dx, self.y, {v = fg.Vector(-dx*random(150, 250), random(-25, 25)), z = z, v_z = -random(0, 50)}) end
    end

    -- Hit Effect
    local hitEffectEnemy = function() self.area:createEntity('HitEffect', self.x + dx*24 + random(-4, 4), self.y - 20 + random(-4, 4)) end
    local hitEffectSelf = function() self.area:createEntity('HitEffect', object.x - dx*24 + random(-4, 4), object.y - 20 + random(-4, 4)) end

    -- Star Hit Effect
    local angle = 0
    if dx > 0 then angle = random(-math.pi/4, math.pi/4) else angle = random(3*math.pi/4, 5*math.pi/4) end
    local starHitEffectEnemy = function() self.area:createEntity('StarHitEffect', 0, 0, {angle = angle, v = random(25, 100), parent = object, offset_x = dx*8, offset_y = -36 + random(-2, 2)}) end
    local starHitEffectSelf = function() self.area:createEntity('StarHitEffect', 0, 0, {angle = angle, v = -random(25, 100), parent = self, offset_x = -dx*8, offset_y = -36 + random(-2, 2)}) end

    -- Juice
    local juice = function()
        self.sx, self.sy = self.fg.utils.math.random(1.06, 1.18), self.fg.utils.math.random(1.06, 1.18)
        local r = self.fg.utils.math.random(0.2, 0.4)
        self.timer:tween('hit_scale_tween', r, self, {sx = 1, sy = 1}, 'in-out-cubic')
        self.timer:after('hit_scale_after', r, function() self.sx = 1; self.sy = 1 end)
    end

    -- Attack visual logic
    local hit = object.hp_seq:hitOrMiss(attack_side)

    -- Hit
    if hit then
        -- Hit
        local hp = object.hp_seq:getHP()
        local attack_types = {}
        local attack_chances = {}
        if hp == 1 or hp == object.max_hp then 
            attack_types = {'light_punch', 'strong_punch', 'kick'}
            attack_chances = {0.33, 0.33, 0.34}
        else 
            attack_types = {'low_dash', 'dash', 'light_punch', 'strong_punch', 'block', 'kick'} 
            attack_chances = {0.11, 0.11, 0.20, 0.20, 0.18, 0.20}
        end
        local attack_type = self.fg.utils.math.chooseWithProbability(attack_types, attack_chances)

        if hp == 1 then 
            self.melee_attack_queue_index = self.melee_attack_queue_index - 1 
            if self.melee_attack_queue_index < 1 then self.melee_attack_queue_index = 1 end
        end

        if attack_type == 'low_dash' then
            self:push(80*dx, 0, 0.1)
            object:steerablePush(400*dx, 0)
            spawnBloodEnemy()
            hitEffectEnemy()
            starHitEffectEnemy()
            juice()
            object:hitATK(self, attack_type) 

        elseif attack_type == 'dash' then
            self:push(40*dx, 0, 0.2)
            object:steerablePush(200*dx, 0)
            spawnBloodEnemy()
            hitEffectEnemy()
            starHitEffectEnemy()
            juice()
            object:hitATK(self, attack_type) 

        elseif attack_type == 'block' then
            object:hitATK(self, attack_type) 
            self:push(-100*dx, 0)
            local animations = {'light_punch_left', 'light_punch_right', 'strong_punch_left', 'strong_punch_right', 'kick'}
            object:playAnimation(animations[math.random(1, #animations)])
            hitEffectSelf()
            juice()

        else
            object:steerablePush(100*dx, 0)
            spawnBloodEnemy()
            hitEffectEnemy()
            starHitEffectEnemy()
            juice()
            object:hitATK(self, attack_type) 
        end

        -- Animation
        if attack_type == 'light_punch' or attack_type == 'strong_punch' then self:playAnimation(attack_type .. '_' .. attack_side)
        elseif attack_type == 'kick' then self:playAnimation(attack_type)
        elseif attack_type == 'low_dash' or attack_type == 'dash' then
            self:setAnimationState(attack_type)
            self.timer:after(attack_type, 0.4, function() self[attack_type] = false end)
        else
            self:setAnimationState(attack_type)
            self.timer:after(attack_type, 0.8, function() self[attack_type] = false end)
        end

        -- Unset
        if object.dying or object.stage_decreasing then
            self.melee_attack_movement_locked = false
            self.melee_attack_line_locked = false
            self.melee_attack_first_hit = true
            self.melee_attack_entity_queue[self.melee_attack_queue_index].lock_selected_for_combat = false
            table.remove(self.melee_attack_entity_queue, self.melee_attack_queue_index)
        end

    -- Miss
    else
        local attack_types = {'low_dash', 'dash', 'light_punch', 'strong_punch', 'kick'}
        local attack_chances = {0.10, 0.09, 0.27, 0.27, 0.27}
        local attack_type = self.fg.utils.math.chooseWithProbability(attack_types, attack_chances)
        object:reactATK(self)
        fg.world.camera:shake(2, 0.3)

        if attack_type == 'low_dash' then
            object:steerablePush(-80*dx, 0)
            self:push(-400*dx, 0)
            spawnBloodSelf()
            hitEffectSelf()
            starHitEffectSelf()
            juice()
            self:hitATK(object, attack_type)

        elseif attack_type == 'dash' then
            object:steerablePush(-40*dx, 0)
            self:push(-200*dx, 0)
            spawnBloodSelf()
            hitEffectSelf()
            starHitEffectSelf()
            juice()
            self:hitATK(object, attack_type) 

        else 
            self:push(-100*dx, 0)
            spawnBloodSelf()
            hitEffectSelf()
            starHitEffectSelf()
            juice()
            self:hitATK(object, attack_type) 
        end

        -- Animation
        if attack_type == 'light_punch' or attack_type == 'strong_punch' then object:playAnimation(attack_type .. '_' .. attack_side)
        elseif attack_type == 'kick' then object:playAnimation(attack_type)
        elseif attack_type == 'low_dash' or attack_type == 'dash' then
            object:setAnimationState(attack_type)
            object.timer:after(attack_type, 0.4, function() object[attack_type] = false end)
        end
    end
end

function SingleMeleeAttack:singleMeleeAttackTweenTo(x, y, dx, dy)
    self.melee_attack_new_p = self.fg.Vector(self.x, self.y)
    local angle = 0
    local direction = self.fg.utils.angleToDirection2(self.fg.Vector(self.x, self.y):angleTo(self.fg.Vector(self.melee_attack_closest_entity.x, self.melee_attack_closest_entity.y)))
    if direction == 'left' then angle = math.pi; self.direction = 'right' else self.direction = 'left' end
    self.timer:tween(0.06, self.melee_attack_new_p, {x = x + (dx or 0)*math.cos(angle), y = y + 0.1 + (dy or 0)*math.sin(angle)}, 'linear')
end

function SingleMeleeAttack:singleMeleeAttackSave()
    return {
        melee_attack_lock_radius = self.melee_attack_lock_radius, vulnerable_to_attack = self.vulnerable_to_attack,
        light_punch_left = self.light_punch_left, light_punch_right = self.light_punch_right,
        strong_punch_left = self.strong_punch_left, strong_punch_right = self.strong_punch_right,
        kick = self.kick, dash = self.dash, backdash = self.backdash, low_dash = self.low_dash, block = self.block,
    }
end

return SingleMeleeAttack
