require 'game/mixins/Steerable/Transformation'

local Steerable = fg.Object:extend('Steerable')

function Steerable:steerableNew(settings)
    local settings = settings or {}

    if settings.settings.position then self.position = self.fg.Vector(settings.settings.position.x, settings.settings.position.y) 
    else self.position = self.fg.Vector(self.body:getPosition()) end
    if settings.settings.velocity then self.velocity = self.fg.Vector(settings.settings.velocity.x, settings.settings.velocity.y) 
    else self.velocity = self.fg.Vector(0, 0) end
    if settings.settings.heading then self.heading = self.fg.Vector(settings.settings.heading.x, settings.settings.heading.y) 
    else self.heading = self.fg.Vector(0, 0) end
    if settings.settings.side then self.side = self.fg.Vector(settings.settings.side.x, settings.settings.side.y)
    else self.side = self.fg.Vector(0, 0) end
    self.mass = settings.settings.mass or settings.mass or 1
    self.max_speed = settings.settings.max_v or settings.max_v or 100
    self.init_max_v = settings.settings.max_speed or self.max_speed
    self.max_force = settings.settings.max_force or settings.max_force or 1000
    self.max_turn_rate = settings.settings.max_turn_rate or settings.max_turn_rate or 2*math.pi
    self.turn_multiplier = settings.settings.turn_multiplier or settings.turn_multiplier or 2
    self.damping = settings.settings.damping or 0.95
    if settings.settings.push_velocity then self.push_velocity = self.fg.Vector(settings.settings.push_velocity.x, settings.settings.push_velocity.y) 
    else self.push_velocity = self.fg.Vector(0, 0) end
    self.push_velocity_damping = settings.settings.push_velocity_damping or false

    self.behavior_on = {}
    self.behavior_on['seek'] = false 
    self.behavior_on['flee'] = false 
    self.behavior_on['arrive'] = false 
    self.behavior_on['pursuit'] = false 
    self.behavior_on['evade'] = false
    self.behavior_on['wander'] = false 
    self.behavior_on['obstacle_avoidance'] = false
    self.behavior_on['wall_avoidance'] = false 
    self.behavior_on['hide'] = false 
    self.behavior_on['offset_pursuit'] = false
    self.behavior_on['offset_arrive'] = false
    self.behavior_on['separation'] = false
    self.behavior_on['alignment'] = false
    self.behavior_on['cohesion'] = false

    -- Seek
    self.seek_target = settings.seek_target or self.fg.Vector(0, 0)
    self.seek_weight = settings.seek_weight or 1

    -- Flee
    self.flee_target = settings.flee_target or self.fg.Vector(0, 0)
    self.flee_weight = settings.flee_weight or 1
    self.flee_radius = settings.flee_radius or 100

    -- Arrive
    self.arrive_target = settings.arrive_target or self.fg.Vector(0, 0)
    self.arrive_weight = settings.arrive_weight or 1
    self.arrive_deceleration = settings.arrive_deceleration or 3

    -- Pursuit
    self.pursuit_target = settings.pursuit_target
    self.pursuit_weight = settings.pursuit_weight or 1

    -- Evade
    self.evade_target = settings.evade_target or self.fg.Vector(0, 0)
    self.evade_weight = settings.evade_weight or 1

    -- Wander
    self.wander_weight = settings.wander_weight or 1
    self.wander_radius = settings.wander_radius or 40
    local r = self.fg.utils.math.random(0, 2*math.pi)
    self.wander_target = self.fg.Vector(self.wander_radius*math.cos(r), self.wander_radius*math.sin(r))
    self.wander_distance = settings.wander_distance or 40
    self.wander_jitter = settings.wander_jitter or 20 

    -- Obstacle Avoidance (oa)
    self.oa_weight = settings.oa_weight or 10
    self.oa_box_length = 0
    self.oa_min_detection_box_length = settings.oa_min_detection_box_length or 40

    -- Wall Avoidance (wa)
    self.wa_weight = settings.wa_weight or 10
    self.wa_feelers = {}
    self.wa_walls = {}
    self.wa_wall_detection_feeler_length =  settings.wa_wall_detection_feeler_length or 40

    -- Hide
    self.hide_target = settings.hide_target or self.fg.Vector(0, 0)
    self.hide_weight = settings.hide_weight or 1

    -- Offset Pursuit (op)
    self.op_leader = settings.op_leader or self.fg.Vector(0, 0)
    self.op_weight = settings.op_weight or 1
    self.op_offset = settings.op_offset or self.fg.Vector(0, 0)

    -- Offset Arrive (oa)
    self.oa_target = settings.oa_target or self.fg.Vector(0, 0)
    self.oa_weight = settings.oa_weight or 1
    self.oa_offset = settings.oa_offset or self.fg.Vector(0, 0)

    -- Separation
    self.separation_weight = settings.separation_weight or 1
    self.separation_radius = settings.separation_radius or 25
    self.separation_targets = settings.separation_targets or {self.class_name}

    -- Alignment
    self.alignment_weight = settings.alignment_weight or 1

    -- Cohesion
    self.cohesion_weight = settings.cohesion_weight or 0.5
end

function Steerable:changeMaxV(new_maxv, change_delay)
    self.timer:tween('change_max_v', change_delay or 0.2, self, {max_speed = new_maxv}, 'in-out-cubic')
end

function Steerable:seekOn(target)
    self.behavior_on['seek'] = true
    self.seek_target = target
end

function Steerable:seekOff()
    self.behavior_on['seek'] = false 
    self.seek_target = self.fg.Vector(0, 0)
end

function Steerable:arriveOn(target)
    self.behavior_on['arrive'] = true
    self.arrive_target = target
end

function Steerable:arriveOff()
    self.behavior_on['arrive'] = false
    self.arrive_target = self.fg.Vector(0, 0)
end

function Steerable:pursuitOn(target)
    self.behavior_on['pursuit'] = true
    self.pursuit_target = target
end

function Steerable:pursuitOff()
    self.behavior_on['pursuit'] = false
    self.pursuit_target = nil
end

function Steerable:wanderOn(radius, distance, jitter)
    self.behavior_on['wander'] = true
    self.wander_radius = radius or self.wander_radius
    self.wander_distance = distance or self.wander_distance
    self.wander_jitter = jitter or self.wander_jitter
end

function Steerable:wanderOff()
    self.behavior_on['wander'] = false
end

function Steerable:separationOn(radius, targets)
    self.behavior_on['separation'] = true
    self.separation_radius = radius or self.separation_radius   
    self.separation_targets = targets or {self.class_name}
end

function Steerable:separationOff()
    self.behavior_on['separation'] = false
end

function Steerable:wallAvoidanceOn()
    self.behavior_on['wall_avoidance'] = true
end

function Steerable:wallAvoidanceOff()
    self.behavior_on['wall_avoidance'] = false
end

function Steerable:steerableUpdate(dt)
    -- If being pushed then ignore Steerable calculations
    if math.abs(self.push_velocity.x) > 0 or math.abs(self.push_velocity.y) > 0 then
        if self.push_velocity_damping then self.push_velocity = self.push_velocity*0.9 end
        self.body:setLinearVelocity(self.push_velocity.x, self.push_velocity.y)
        return
    end

    local steering_force = self:calculate(dt)
    local acceleration = steering_force/self.mass
    self.velocity = self.velocity + acceleration*dt
    self.velocity:truncate(self.max_speed)
    self.body:setLinearVelocity(self.velocity.x, self.velocity.y)

    self.position = self.fg.Vector(self.body:getPosition())

    if (self.velocity:len2() > 0.00001) then
        self.heading = self.velocity:normalized()
        self.side = self.heading:perpendicular()
    end

    if steering_force:len2() < 10 then
        self.velocity = self.velocity*self.damping
    end
end

function Steerable:steerableDraw()
    if self.behavior_on.obstacle_avoidance then
        love.graphics.setColor(244, 160, 128)
        self.fg.utils.graphics.pushRotate(self.x, self.y, self.velocity:angle())
        love.graphics.rectangle('line', self.x, self.y - 20, self.oa_box_length, 40)
        love.graphics.pop()
        love.graphics.setColor(255, 255, 255)
    end
end

function Steerable:calculate(dt)
    local steering_force = self.fg.Vector(0, 0)

    if self.behavior_on.seek then steering_force = steering_force + self:seek(self.seek_target) * self.seek_weight end
    if self.behavior_on.flee then steering_force = steering_force + self:flee(self.flee_target, self.flee_radius) * self.flee_weight end
    if self.behavior_on.arrive then steering_force = steering_force + self:arrive(self.arrive_target, self.arrive_deceleration) * self.arrive_weight end
    if self.behavior_on.pursuit then steering_force = steering_force + self:pursuit(self.pursuit_target) * self.pursuit_weight end
    if self.behavior_on.evade then steering_force = steering_force + self:evade(self.evade_target) * self.evade_weight end
    if self.behavior_on.wander then steering_force = steering_force + self:wander(dt, self.wander_radius, self.wander_distance, self.wander_jitter) * self.wander_weight end
    if self.behavior_on.obstacle_avoidance then steering_force = steering_force + self:obstacleAvoidance() * self.oa_weight end
    if self.behavior_on.wall_avoidance then steering_force = steering_force + self:wallAvoidance() * self.wa_weight end
    if self.behavior_on.hide then steering_force = steering_force + self:hide(self.hide_target) * self.hide_weight end
    if self.behavior_on.offset_pursuit then steering_force = steering_force + self:offsetPursuit(self.op_leader, self.op_offset) * self.op_weight end
    if self.behavior_on.offset_arrive then steering_force = steering_force + self:offsetArrive(self.oa_target, self.oa_offset) * self.oa_weight end
    if self.behavior_on.separation then steering_force = steering_force + self:separation() * self.separation_weight end
    if self.behavior_on.alignment then steering_force = steering_force + self:alignment() * self.alignment_weight end
    if self.behavior_on.cohesion then steering_force = steering_force + self:cohesion() * self.cohesion_weight end

    return steering_force:truncate(self.max_force)
end

function Steerable:steerablePush(fx, fy)
    local t1 = (-self.v_z + math.sqrt(self.v_z*self.v_z + 2*self.fg.gravity_z*self.z))/self.fg.gravity_z
    local t2 = (-self.v_z - math.sqrt(self.v_z*self.v_z + 2*self.fg.gravity_z*self.z))/self.fg.gravity_z
    local t = math.max(t1, t2)
    self.timer:during('pushing', t, function() self.push_velocity.x = fx; self.push_velocity.y = fy end)
    self.timer:after('pushing_after', t, function()
        self.push_velocity_damping = true
        self.timer:after('pushing_damp', 1, function()
            self.push_velocity_damping = false
            self.push_velocity = self.fg.Vector(0, 0)
        end)
    end)
end

function Steerable:seek(target)
    local desired_velocity = (target - self.position):normalized() * self.max_speed
    return (desired_velocity - self.velocity) * self.turn_multiplier
end

function Steerable:flee(target, radius)
    local radius = radius or self.flee_radius

    local flee_distance = radius * radius
    if (self.position:dist2(target) > flee_distance) then
        return self.fg.Vector(0, 0) 
    end
    local desired_velocity = (self.position - target):normalized() * self.max_speed
    return (desired_velocity - self.velocity) * self.turn_multiplier
end

function Steerable:arrive(target, deceleration)
    local deceleration = deceleration or self.arrive_deceleration

    local to_target = target - self.position
    local dist = to_target:len()
    if (dist > 0) then
        local deceleration_tweaker = 0.3
        local speed = dist / (deceleration * deceleration_tweaker)
        speed = math.min(speed, self.max_speed)
        local desired_velocity = to_target * speed / dist
        return (desired_velocity - self.velocity) * self.turn_multiplier
    end
    return self.fg.Vector(0, 0)
end

function Steerable:pursuit(evader)
    local evader_position = self.fg.Vector(evader.body:getPosition())
    local to_evader = evader_position - self.position

    local evader_velocity = self.fg.Vector(evader.body:getLinearVelocity())
    local evader_heading = evader_velocity:normalized()
    local relative_heading = self.heading:dot(evader_heading)
    if (to_evader:dot(self.heading) > 0) and (relative_heading < -0.95) then
        return self:seek(evader_position)
    end

    local look_ahead_time = to_evader:len() / (self.max_speed + self.fg.Vector(evader.body:getLinearVelocity()):len())
    return self:seek(evader_position + evader_velocity * look_ahead_time)
end

function Steerable:evade(pursuer)
    local pursuer_position = self.fg.Vector(pursuer.body:getPosition())
    local to_pursuer = pursuer_position - self.position

    local pursuer_velocity = self.fg.Vector(pursuer.body:getLinearVelocity())
    local look_ahead_time = to_pursuer:len() / (self.max_speed + self.fg.Vector(pursuer.body:getLinearVelocity()):len())
    return self:flee(pursuer_position + pursuer_velocity * look_ahead_time)
end

function Steerable:wander(dt, radius, distance, jitter)
    local radius = radius or self.wander_radius
    local distance = distance or self.wander_distance
    local jitter = jitter or self.wander_jitter
    local jitter_dt = jitter * dt

    self.wander_target = self.wander_target + self.fg.Vector(self.fg.utils.math.random(-1, 1) * jitter, self.fg.utils.math.random(-1, 1) * jitter)
    self.wander_target = self.wander_target:normalized()
    self.wander_target = self.wander_target * radius

    local target_local = self.wander_target + self.fg.Vector(distance, 0)
    local target_world = pointToWorldSpace(target_local, self.heading, self.side, self.position)
    return (target_world - self.position)
end

function Steerable:obstacleAvoidance()
    self.oa_box_length = self.oa_min_detection_box_length + (self.velocity:len()/self.max_speed) * self.oa_min_detection_box_length
    local obstacles = self.area:queryAreaCircle(self.position.x, self.position.y, self.oa_box_length, {'Table', 'Box'})
    local closest_intersecting_obstacle = nil
    local distance_to_closest_ip = 10000
    local local_position_of_closest_obstacle = self.fg.Vector(0, 0)

    for _, obstacle in ipairs(obstacles) do
        local local_position = pointToLocalSpace(self.fg.Vector(obstacle.x, obstacle.y), self.heading, self.side, self.position)
        if local_position.x >= 0 then
            local expanded_radius = math.min(obstacle.w, obstacle.h) + math.min(self.w, self.h)
            if math.abs(local_position.y) < expanded_radius then
                local cx, cy = local_position.x, local_position.y
                local sqrt_part = math.sqrt(expanded_radius * expanded_radius - cy * cy)
                local ip = cx - sqrt_part
                if ip <= 0 then ip = cx + sqrt_part end
                if ip < distance_to_closest_ip then
                    distance_to_closest_ip = ip
                    closest_intersecting_obstacle = obstacle
                    local_position_of_closest_obstacle = local_position
                end
            end
        end
    end

    local steering_force = self.fg.Vector(0, 0)
    if closest_intersecting_obstacle then
        local multiplier = 1 + (self.oa_box_length - local_position_of_closest_obstacle.x) / self.oa_box_length
        steering_force.y = (math.min(closest_intersecting_obstacle.w, closest_intersecting_obstacle.h) - local_position_of_closest_obstacle.y) * multiplier
        local braking_weight = 0.2
        steering_force.x = (math.min(closest_intersecting_obstacle.w, closest_intersecting_obstacle.h) - local_position_of_closest_obstacle.x) * braking_weight 
    end

    return vectorToWorldSpace(steering_force, self.heading, self.side)
end

function Steerable:createFeelers()
    self.wa_feelers = {}
    table.insert(self.wa_feelers, self.position + self.heading * self.wa_wall_detection_feeler_length)
    local temp1 = self.heading:clone()
    temp1 = vec2DRotateAroundOrigin(temp1, 3.5 * math.pi/2)
    table.insert(self.wa_feelers, self.position + temp1 * (self.wa_wall_detection_feeler_length / 2))
    local temp2 = self.heading:clone()
    temp2 = vec2DRotateAroundOrigin(temp2, 0.5 * math.pi/2)
    table.insert(self.wa_feelers, self.position + temp2 * (self.wa_wall_detection_feeler_length / 2))
end

function Steerable:wallAvoidance()
    self:createFeelers()
    local solids = self.area:queryAreaCircle(self.x, self.y, 400, {'Solid'})
    self.wa_walls = {}
    for _, solid in ipairs(solids) do
        local solid_x1, solid_y1, solid_x2, solid_y2 = solid.x - solid.w/2, solid.y - solid.h/2, solid.x + solid.w/2, solid.y + solid.h/2
        local wall_left = {a = self.fg.Vector(solid_x1, solid_y1), b = self.fg.Vector(solid_x1, solid_y2), 
                           n = self.fg.Vector(solid_y1 - solid_y2, solid_x1 - solid_x1)}
        local wall_right = {a = self.fg.Vector(solid_x2, solid_y1), b = self.fg.Vector(solid_x2, solid_y2), 
                            n = self.fg.Vector(solid_y2 - solid_y1, solid_x2 - solid_x2)}
        local wall_up = {a = self.fg.Vector(solid_x1, solid_y1), b = self.fg.Vector(solid_x2, solid_y1), 
                         n = self.fg.Vector(solid_y1 - solid_y1, solid_x1 - solid_x2)}
        local wall_down = {a = self.fg.Vector(solid_x1, solid_y2), b = self.fg.Vector(solid_x2, solid_y2), 
                           n = self.fg.Vector(solid_y2 - solid_y2, solid_x2 - solid_x1)}
        table.insert(self.wa_walls, wall_left)
        table.insert(self.wa_walls, wall_right)
        table.insert(self.wa_walls, wall_up)
        table.insert(self.wa_walls, wall_down)
    end
    local distance_to_this_ip, distance_to_closest_ip, closest_wall = 0, 10000, nil
    local steering_force, point, closest_point = self.fg.Vector(0, 0), self.fg.Vector(0, 0), self.fg.Vector(0, 0)

    for _, feeler in ipairs(self.wa_feelers) do
        for _, wall in ipairs(self.wa_walls) do
            local intersecting = false
            intersecting, distance_to_this_ip, point = lineIntersection2D(self.position, feeler, wall.a, wall.b, distance_to_this_ip, point) 
            if intersecting then
                if distance_to_this_ip < distance_to_closest_ip then
                    distance_to_closest_ip = distance_to_this_ip
                    closest_wall = wall
                    closest_point = point
                end
            end
        end
        if closest_wall then
            local over_shoot = feeler - closest_point
            steering_force = closest_wall.n * over_shoot:len()
        end
    end

    return steering_force
end

function Steerable:getHidingPosition(object_position, object_radius, target_position)
    local distance_from_boundary = 40
    local distance_away = object_radius + distance_from_boundary
    local to_object = (object_position - target_position):normalized()
    return (to_object * distance_away) + object_position
end

function Steerable:hide(target)
    local distance_to_closest = 100000000
    local best_hiding_spot = self.fg.Vector(0, 0)

    local obstacles = self.area:queryAreaCircle(self.position.x, self.position.y, 1000, {'Table', 'Box'})
    for _, obstacle in ipairs(obstacles) do
        local hiding_spot = self:getHidingPosition(self.fg.Vector(obstacle.body:getPosition()), math.min(obstacle.w, obstacle.h), target)
        local distance = hiding_spot:dist2(self.position)
        if distance < distance_to_closest then
            distance_to_closest = distance
            best_hiding_spot = hiding_spot
        end
    end

    if distance_to_closest == 100000000 then return self:evade(target_position)
    else return self:arrive(best_hiding_spot) end
end

function Steerable:offsetArrive(target, offset)
    local to_offset = (target + offset) - self.position
    return self:arrive(to_offset)
end

function Steerable:offsetPursuit(leader, offset)
    local leader_velocity = self.fg.Vector(leader.body:getLinearVelocity())
    local leader_heading = leader_velocity:normalized()
    local leader_side = leader_heading:perpendicular()
    local world_offset_position = pointToWorldSpace(offset, leader_heading, leader_side, self.fg.Vector(leader.body:getPosition()))
    local to_offset = world_offset_position - self.position

    local look_ahead_time = to_offset:len() / (self.max_speed + leader_velocity:len())
    return self:arrive(world_offset_position + leader_velocity * look_ahead_time) 
end

function Steerable:separation()
    local steering_force = self.fg.Vector(0, 0)
    local neighbors = self.area:queryAreaCircle(self.position.x, self.position.y, 2*self.separation_radius, self.separation_targets)
    for _, neighbor in ipairs(neighbors) do
        if neighbor.id ~= self.id then
            local to_agent = self.position - self.fg.Vector(neighbor.body:getPosition())
            steering_force = steering_force + self.separation_radius*(to_agent:normalized() / to_agent:normalized():len())
        end
    end

    return steering_force
end

function Steerable:alignment()
    local average_heading = self.fg.Vector(0, 0)
    local neighbors = self.area:queryAreaCircle(self.position.x, self.position.y, 400, {self.class_name})
    for _, neighbor in ipairs(neighbors) do
        if neighbor.id ~= self.id then
            average_heading = average_heading + (neighbor.heading or self.fg.Vector(neighbor.body:getLinearVelocity()):normalized())
        end
    end

    if #neighbors > 0 then 
        average_heading = average_heading / #neighbors
        average_heading = average_heading - self.heading
    end
    return average_heading
end

function Steerable:cohesion()
    local center_of_mass, steering_force = self.fg.Vector(0, 0), self.fg.Vector(0, 0)
    local neighbors = self.area:queryAreaCircle(self.position.x, self.position.y, 400, {self.class_name})
    for _, neighbor in ipairs(neighbors) do
        if neighbor.id ~= self.id then
            center_of_mass = center_of_mass + self.fg.Vector(neighbor.body:getPosition())
        end
    end

    if #neighbors > 0 then
        center_of_mass = center_of_mass / #neighbors
        steering_force = self:seek(center_of_mass)
    end
    return steering_force
end

function Steerable:steerableSave()
    return {
        position = {x = self.position.x, y = self.position.y}, velocity = {x = self.velocity.x, y = self.velocity.y},
        heading = {x = self.heading.x, y = self.heading.y}, side = {x = self.side.x, y = self.side.y},
        mass = self.mass, max_v = self.max_speed, max_speed = self.init_max_v, max_force = self.max_force, 
        max_turn_rate = self.max_turn_rate, turn_multiplier = self.turn_multiplier, damping = self.damping,
        push_velocity = {x = self.push_velocity.x, y = self.push_velocity.y}, push_velocity_damping = self.push_velocity_damping
    }
end

return Steerable
