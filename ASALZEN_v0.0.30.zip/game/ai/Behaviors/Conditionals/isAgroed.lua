local isAgroed = Action:extend('isAgroed')

function isAgroed:new()
    isAgroed.super.new(self, 'isAgroed')
end

function isAgroed:update(dt, context)
    return isAgroed.super.update(self, dt, context)
end

function isAgroed:run(dt, context)
    if context.object.agroed and not context.object.dying and not context.object.stage_decreasing and not context.object.attacker and not context.object.engaged_in_single_combat then return 'success'
    else return 'failure' end
end

function isAgroed:start(context)

end

function isAgroed:finish(status, context)

end

return isAgroed
