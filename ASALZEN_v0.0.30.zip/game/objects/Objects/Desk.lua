local Desk = fg.Class('Desk', 'Entity')
Desk:implement(fg.PhysicsBody)
Desk:implement(Pseudo3D)

function Desk:new(area, x, y, settings)
    local settings = settings or {}
    Desk.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    settings.w, settings.h = 22, 12
    self:physicsBodyNew(area, x, y, settings)
    self:pseudo3DNew({height_z = 20, stand = true, stand_z = 20, settings = settings})
    self.desk_visual = self.fg.Assets.desk
    self.desk_quad = love.graphics.newQuad(0, 0, 32, 48, 64, 48)
    self.desk_shadow = love.graphics.newQuad(32, 0, 32, 48, 64, 48)
end

function Desk:update(dt)
    self.timer:update(dt)
    self:physicsBodyUpdate(dt)
    self:pseudo3DUpdate(dt)
end

function Desk:draw()
    local w, h = 32, 48
    -- Shadow
    love.graphics.setColor(255, 255, 255, 128)
    love.graphics.draw(self.desk_visual, self.desk_shadow, math.floor(self.x - w/2), math.floor(self.y - h + 10))
    love.graphics.setColor(255, 255, 255, 255)
    -- Desk
    love.graphics.draw(self.desk_visual, self.desk_quad, math.floor(self.x - w/2), math.floor(self.y - h + 10))
    self:physicsBodyDraw()
    self:pseudo3DDraw()
end

function Desk:highlightDraw()
    local w, h = 32, 48
    love.graphics.draw(self.desk_visual, self.desk_quad, self.x - w/2, self.y - h + 10)
end

function Desk:save()
    local pseudo_3d = self:pseudo3DSave()
    local save_data = {}
    for k, v in pairs(pseudo_3d) do save_data[k] = v end
    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y
    save_data.w, save_data.h = self.w, self.h
    save_data.shape = 'Rectangle'
    return save_data
end

return Desk
