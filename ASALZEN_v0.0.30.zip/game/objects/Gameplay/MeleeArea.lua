local MeleeArea = fg.Class('MeleeArea', 'Entity')
MeleeArea:implement(fg.PhysicsBody)

MeleeArea.ignores = {'All'}

function MeleeArea:new(area, x, y, settings)
    local settings = settings or {}
    MeleeArea.super.new(self, area, x, y, settings)

    if self.parent then
        if self.parent.class_name == 'PersonAI' then
            if self.parent.enemy_type == 'MeleeEasy' then
                settings.w = 16
                settings.h = 12
            end
        end
    end
    self:physicsBodyNew(area, x, y, settings)
end

function MeleeArea:update(dt)
    self:physicsBodyUpdate(dt)

    self.dead = true

    if self.parent.class_name == 'PersonAI' then
        local entities = self.area:queryAreaRectangle(self.x, self.y, self.w, self.h, {'Person'})
        local player = entities[1]
        if player then
            local angle = self.fg.Vector(player.x, player.y):angleTo(self.fg.Vector(self.parent.x, self.parent.y))
            player:hitATK(self)
            player.v_z = -100
            player:push(150*math.cos(angle), 50*math.sin(angle))
            self.area:hitFrameStopAdd(10, {'All', except = {'HitEffect', 'BloodPool'}}, function()
                self.fg.world.camera:shake(2, 0.3)
            end)

            local dx, dy = player.x - self.parent.x, player.y - self.parent.y
            if dx < 0 then dx = -1 else dx = 1 end
            if dy < 0 then dy = -1 else dy = 1 end
            local random = self.fg.utils.math.random

            -- Hit effect
            self.area:createEntity('HitEffect', self.parent.x + dx*24 + random(-4, 4), self.parent.y - 20 + random(-4, 4))

            -- Star Hit Effect
            local angle = 0
            if dx > 0 then angle = random(-math.pi/4, math.pi/4) else angle = random(3*math.pi/4, 5*math.pi/4) end
            self.area:createEntity('StarHitEffect', 0, 0, {angle = angle, v = random(25, 100), parent = player, offset_x = dx*8, offset_y = -36 + random(-2, 2)})

            -- Particles
            local z = player.z + player.height_z - 6
            local n = math.random(2, 4)
            for i = 1, n do self.area:createEntity('BloodParticle', player.x + 4*dx, player.y, {v = self.fg.Vector(dx*random(150, 250), random(-25, 25)), z = z, v_z = -random(0, 50)}) end

            -- Juice
            self.parent.sx, self.parent.sy = self.fg.utils.math.random(1.02, 1.1), self.fg.utils.math.random(1.02, 1.1)
            local r = self.fg.utils.math.random(0.1, 0.6)
            self.parent.timer:tween('hit_scale_tween', r, self.parent, {sx = 1, sy = 1}, 'in-out-cubic')
            self.parent.timer:after('hit_scale_after', r, function() self.parent.sx = 1; self.parent.sy = 1 end)
        end
    end
end

function MeleeArea:draw()
    self:physicsBodyDraw()
end

function MeleeArea:save()
    local save_data = {}

    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y
    save_data.w, save_data.h = self.w, self.h
    save_data.shape = 'Rectangle'
    return save_data
end

return MeleeArea
