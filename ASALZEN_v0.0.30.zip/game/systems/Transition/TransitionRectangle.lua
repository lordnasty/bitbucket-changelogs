local TransitionRectangle = fg.Object:extend('TransitionRectangle')

function TransitionRectangle:new(x, y, r, tr, sx, sy, w, h, duration)
    self.fg = fg
    self.timer = self.fg.Timer()
    self.x, self.y = x, y
    self.r, self.tr = r, tr
    self.sx, self.sy = sx, sy
    self.w, self.h = w, h
    if self.sx == 0 then self.timer:tween(duration, self, {sx = 1, sy = 1}, 'in-out-cubic')
    elseif self.sx == 1 then self.timer:tween(duration, self, {sx = 0, sy = 0}, 'in-out-cubic') end
    if self.tr then self.timer:tween(duration, self, {r = self.tr}, 'in-out-cubic') end
end

function TransitionRectangle:update(dt)
    self.timer:update(dt)
end

function TransitionRectangle:draw()
    love.graphics.setColor(0, 0, 0, 255)
    self.fg.utils.graphics.pushRotateScale(self.x, self.y, self.r, self.sx, self.sy)
    love.graphics.rectangle('fill', self.x - self.w/2, self.y - self.h/2, self.w, self.h)
    love.graphics.pop()
    love.graphics.setColor(255, 255, 255, 255)
end

return TransitionRectangle
