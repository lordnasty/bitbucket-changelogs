local UI = {}

UI.Textinput = {}
UI.Textinput.draw = function(self)
    love.graphics.setFont(self.font)

    love.graphics.setColor(32, 32, 32)
    love.graphics.rectangle('fill', self.x, self.y, self.w, self.h)

    if self.selected then 
        love.graphics.setColor(48, 48, 48)
        love.graphics.rectangle('fill', self.x, self.y, self.w, self.h)
    end

    love.graphics.setScissor(self.x, self.y, self.w - self.text_margin, self.h)

    love.graphics.setColor(255, 255, 255)
    love.graphics.print(self.text, self.text_x, self.text_y + 1)

    love.graphics.setColor(192, 192, 192, 64)
    if self.selection_position and self.selected then
        love.graphics.rectangle('fill', self.selection_position.x, self.selection_position.y + 1, self.selection_size.w, self.selection_size.h)
    end

    love.graphics.setScissor()
    if self.selected then love.graphics.setColor(255, 255, 255)
    else love.graphics.setColor(128, 128, 128) end
    love.graphics.rectangle('line', self.x, self.y, self.w, self.h)
    love.graphics.setColor(255, 255, 255, 255)
end

UI.Frame = {}
UI.Frame.draw = function(self)
    love.graphics.setColor(64, 64, 64, 255)
    love.graphics.rectangle('fill', self.x, self.y, self.w, self.h)

    love.graphics.setColor(255, 255, 255)
end

UI.Button = {}
UI.Button.draw = function(self)
    love.graphics.setColor(92, 92, 92, 255)
    love.graphics.rectangle('fill', self.x, self.y, self.w, self.h)

    if self.hot then
        love.graphics.setColor(112, 112, 112, 255)
        love.graphics.rectangle('fill', self.x, self.y, self.w, self.h)
    end

    if self.down then
        love.graphics.setColor(72, 72, 72, 255)
        love.graphics.rectangle('fill', self.x, self.y, self.w, self.h)
    end

    if self.text then
        love.graphics.setColor(255, 255, 255)
        local w, h = self.font:getWidth(self.text), self.font:getHeight()
        love.graphics.print(self.text, self.x + self.w/2 - w/2, self.y + self.h/2 - h/2)
    end

    love.graphics.setColor(255, 255, 255)
end

return UI 
