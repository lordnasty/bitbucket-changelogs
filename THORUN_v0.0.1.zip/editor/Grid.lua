local Grid = fg.Object:extend('Grid')

function Grid:gridNew(settings)
    local settings = settings or {}
    self.inside_grid = false
end

function Grid:gridUpdate(dt)
    -- Set inside_grid
    local tilemap = game.levels[fg.current_area].tilemaps.Default
    local cx, cy = fg.world.camera:getWorldCoords(love.mouse.getPosition())
    local x1, y1, x2, y2 = tilemap.x1, tilemap.y1, tilemap.x2, tilemap.y2
    if cx >= x1 and cx <= x2 and cy >= y1 and cy <= y2 then self.inside_grid = true
    else self.inside_grid = false end
end

function Grid:gridDraw()
    local tilemap = game.levels[fg.current_area].tilemaps.Default
    love.graphics.setLineStyle('rough')
    love.graphics.setColor(128, 128, 128, 2)
    local x1, y1 = fg.world.camera:getCameraCoords(tilemap.x1, tilemap.y1)
    local x2, y2 = fg.world.camera:getCameraCoords(tilemap.x2, tilemap.y2)
    love.graphics.rectangle('line', x1, y1, x2 - x1, y2 - y1)

    -- Draw grid
    for i = 1, math.floor(tilemap.w/tilemap.tile_width) do
        for j = 0, tilemap.h, tilemap.tile_height do
            local x1, y1 = fg.world.camera:getCameraCoords(-tilemap.w/2, j - tilemap.h/2)
            local x2, y2 = fg.world.camera:getCameraCoords(-tilemap.w/2 + tilemap.w, j - tilemap.h/2)
            love.graphics.line(x1, y1, x2, y2) 
        end
    end
    for i = 1, math.floor(tilemap.h/tilemap.tile_height) do
        for j = 0, tilemap.w, tilemap.tile_width do
            local x1, y1 = fg.world.camera:getCameraCoords(j - tilemap.w/2, -tilemap.h/2)
            local x2, y2 = fg.world.camera:getCameraCoords(j - tilemap.w/2, -tilemap.h/2 + tilemap.h)
            love.graphics.line(x1, y1, x2, y2) 
        end
    end

    love.graphics.setColor(255, 255, 255, 255)
    if self.object then return end

    -- Draw mouse hover rectangle
    local x1, y1, x2, y2 = tilemap.x1, tilemap.y1, tilemap.x2, tilemap.y2
    local cx, cy = fg.world.camera:getWorldCoords(love.mouse.getPosition())
    if cx >= x1 and cx <= x2 and cy >= y1 and cy <= y2 and not self.selection_start then
        local x = math.floor(cx/tilemap.tile_width) + math.floor(math.floor(tilemap.w/tilemap.tile_width)/2) + 1
        local y = math.floor(cy/tilemap.tile_height) + math.floor(math.floor(tilemap.h/tilemap.tile_height)/2) + 1
        self.grid_x, self.grid_y = x, y
        local rx, ry = fg.world.camera:getCameraCoords(-tilemap.w/2 + (x-1)*tilemap.tile_width, -tilemap.h/2 + (y-1)*tilemap.tile_height)
        love.graphics.setColor(128, 128, 128, 32)
        love.graphics.rectangle('fill', rx, ry, tilemap.tile_width*fg.screen_scale, tilemap.tile_height*fg.screen_scale)
    else self.grid_x, self.grid_y = nil, nil end

    love.graphics.setColor(255, 255, 255, 255)
end

return Grid
