local meleeEasyAttack = Action:extend('meleeEasyAttack')

function meleeEasyAttack:new()
    meleeEasyAttack.super.new(self, 'meleeEasyAttack')
end

function meleeEasyAttack:update(dt, context)
    return meleeEasyAttack.super.update(self, dt, context)
end

function meleeEasyAttack:run(dt, context)
    
end

function meleeEasyAttack:start(context)

end

function meleeEasyAttack:finish(status, context)

end

return meleeEasyAttack
