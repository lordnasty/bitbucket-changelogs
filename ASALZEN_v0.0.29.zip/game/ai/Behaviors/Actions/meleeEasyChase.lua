local chase = Action:extend('chase')

function chase:new(success_radius, separation_radius)
    chase.super.new(self, 'chase')

    self.success_radius = success_radius
    self.separation_radius = separation_radius
end

function chase:update(dt, context)
    return chase.super.update(self, dt, context)
end

function chase:run(dt, context)
    if context.any_around_entity then
        if context.object.stage_decreasing or context.object.dying then 
            return 'failure'
        else
            context.object:arriveOn(self.fg.Vector(context.any_around_entity.body:getPosition()))
            local distance = self.fg.mlib.line.getDistance(context.object.x, context.object.y, context.any_around_entity.body:getPosition())
            if distance < self.success_radius then return 'success' end
        end
    end 
    return 'running'
end

function chase:start(context)
    context.object:separationOn(self.separation_radius, {'PersonAI'})
end

function chase:finish(status, context)
    context.object:arriveOff()
    context.object:separationOff()
end

return chase
