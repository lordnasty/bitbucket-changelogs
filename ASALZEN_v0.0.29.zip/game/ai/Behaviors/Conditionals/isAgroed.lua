local isAgroed = Action:extend('isAgroed')

function isAgroed:new()
    isAgroed.super.new(self, 'isAgroed')
end

function isAgroed:update(dt, context)
    return isAgroed.super.update(self, dt, context)
end

function isAgroed:run(dt, context)
    if context.object.agroed then return 'success'
    else return 'failure' end
end

function isAgroed:start(context)

end

function isAgroed:finish(status, context)

end

return isAgroed
