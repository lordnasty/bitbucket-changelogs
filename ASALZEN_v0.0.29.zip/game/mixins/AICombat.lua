local AICombat = fg.Object:extend('AICombat')

function AICombat:AICombatNew(settings)
    local settings = settings or {}
    
    self.agroed = false
    self.reaction_time = 0.3
    self.melee_attack_locked = false
    self.melee_attack_new_p = nil
    self.melee_attack_moving_to_target = false
    self.vulnerable_attack_delay = 1
    self.o_vulnerable_target = self.fg.obv(nil)
    self.attacker = nil
    self.lock_selected_for_combat = false

    self.light_punch_left = settings.settings.light_punch_left or false
    self.light_punch_right = settings.settings.light_punch_right or false
    self.strong_punch_left = settings.settings.strong_punch_left or false
    self.strong_punch_right = settings.settings.strong_punch_right or false
    self.kick = settings.settings.kick or false
    self.low_dash = settings.settings.low_dash or false
    self.dash = settings.settings.dash or false
    self.backdash = settings.settings.backdash or false
    self.block = settings.settings.block or false

    -- Agro types:
    -- Proximity = starts attacking the player when he comes too close
    -- Attack = starts attacking the player only after he attacks first
    -- Friend = starts attacking the player when warned from other NPCs, also warns other NPCs when attacked by the player
    self.agro_type = settings.settings.agro_type or 'attack'

    self.enemy_type = settings.settings.enemy_type or 'MeleeEasy'
    self.enemy_type_colors = {
        MeleeEasy = {241, 128, 91},
    }

    self.enemy_type_coloring = love.graphics.newShader('resources/shaders/default.vert', 'resources/shaders/enemy_type_coloring.frag')

    -- MeleeEasy
    if self.enemy_type == 'MeleeEasy' then
        self.head.hair_color = self.fg.utils.table.random({self.enemy_type_colors[self.enemy_type], {241, 128, 241}})
        self:wallAvoidanceOn()
        self.max_speed = 50
        self.behavior_tree = Root(self, 
            Sequence('attackPlayer', {
                isAgroed(), 
                anyAround({'Person'}, 250),
                meleeEasyChase(30, 30),
                meleeEasyAttack(),
            })
        )
    end

    local r, g, b = unpack(self.head.hair_color)
    self.enemy_type_coloring:send('enemy_color', {math.min(r+48, 255)/255, math.min(g+48, 255)/255, math.min(b+48, 255)/255})
end

function AICombat:AICombatUpdate(dt)
    self.behavior_tree:update(dt)

    -- Set vulnerable_target
    if self.o_vulnerable_target.v then if not self.o_vulnerable_target.v.vulnerable_to_attack then self.o_vulnerable_target:set(nil) end end
    if not self.o_vulnerable_target.v then self.melee_attack_locked = false end

    -- If player misses first hit and is vulnerable
    if self.o_vulnerable_target-nil then
        local object = self.o_vulnerable_target.v

        if self.agro_type == 'attack' then
            self.agroed = true
            self:alert(object)
        end
    end

    if self.melee_attack_moving_to_target then self.body:setPosition(self.melee_attack_new_p.x, self.melee_attack_new_p.y) end
end

function AICombat:AICombatDraw()

end

function AICombat:hitATK(attacker, attack_type)
    self.agroed = true
    self:reactATK(attacker)
end

function AICombat:reactATK(attacker)
    self.attacker = attacker
    self.timer:after('reaction', self.reaction_time, function()
        if self.dying or self.stage_decreasing then return end
        self:meleeAttack('single hit')
        self:reactATK(attacker)
    end)
end

function AICombat:meleeAttack(attack_type)
    local object = self.o_vulnerable_target.v or self.attacker
    if not object then return end
    local random = self.fg.utils.math.random
    local dx, dy = object.x - self.x, object.y - self.y
    if dx < 0 then dx = -1 else dx = 1 end
    if dy < 0 then dy = -1 else dy = 1 end

    self:moveToTarget(object)
    self.timer:after('hit_atk', 0.06, function()
        object:hitATK(self, attack_type)
        object:push(100*dx, 0)
        fg.world.camera:shake(2, 0.3)
    end)

    -- Animation
    if attack_type == 'single hit' then
        local animations = {'light_punch_left', 'light_punch_right', 'strong_punch_left', 'strong_punch_right', 'kick'}
        self:playAnimation(animations[math.random(1, #animations)])
    end

    -- Hit effect
    self.area:createEntity('HitEffect', self.x + dx*24 + random(-4, 4), self.y - 20 + random(-4, 4))

    -- Star Hit Effect
    local angle = 0
    if dx > 0 then angle = random(-math.pi/4, math.pi/4) else angle = random(3*math.pi/4, 5*math.pi/4) end
    self.area:createEntity('StarHitEffect', 0, 0, {angle = angle, v = random(25, 100), parent = object, offset_x = dx*8, offset_y = -36 + random(-2, 2)})

    -- Particles
    local z = object.z + object.height_z - 6
    local n = math.random(2, 4)
    for i = 1, n do
        self.area:createEntity('BloodParticle', object.x + 4*dx, object.y, {v = fg.Vector(dx*random(150, 250), random(-25, 25)), z = z, v_z = -random(0, 50)})
    end

    -- Juice
    self.sx, self.sy = self.fg.utils.math.random(1.02, 1.1), self.fg.utils.math.random(1.02, 1.1)
    local r = self.fg.utils.math.random(0.1, 0.6)
    self.timer:tween('hit_scale_tween', r, self, {sx = 1, sy = 1}, 'in-out-cubic')
    self.timer:after('hit_scale_after', r, function() self.sx = 1; self.sy = 1 end)
end

function AICombat:setVulnerableTarget(target, attack_delay)
    self.o_vulnerable_target(target)
    self.vulnerable_attack_delay = attack_delay or self.vulnerable_attack_delay
end

function AICombat:moveToTarget(object)
    local angle = 0
    if self.direction == 'right' then angle = math.pi end
    self.melee_attack_moving_to_target = true
    self.melee_attack_new_p = self.fg.Vector(self.x, self.y)
    self.timer:tween('attack_move_tween', 0.06, self.melee_attack_new_p, {x = object.x + 30*math.cos(angle), y = object.y + 0.1}, 'linear')
    self.timer:after('attack_move_after', 0.06, function()
        self.melee_attack_moving_to_target = false
        self.melee_attack_new_p = nil
    end)
end

function AICombat:alert(object)
    local dx = 1
    local direction = self.fg.utils.angleToDirection2(self.fg.Vector(object.body:getPosition()):angleTo(self.fg.Vector(self.body:getPosition())))
    self.direction = direction
    if direction == 'right' then dx = -1 end
    self.v_z = -70
    self.melee_attack_locked = true
    fg.world.areas[fg.current_area]:createEntity('Exclamation', self.x, self.y, {parent = self, duration = 0.8, offset_x = dx*12, offset_y = -42})
end

function AICombat:AICombatSave()
    return {
        light_punch_left = self.light_punch_left, light_punch_right = self.light_punch_right,
        strong_punch_left = self.strong_punch_left, strong_punch_right = self.strong_punch_right,
        kick = self.kick, dash = self.dash, backdash = self.backdash, low_dash = self.low_dash, block = self.block,
        agro_type = self.agro_type,
    }
end

return AICombat
