local DoorOpener = fg.Object:extend('DoorOpener')

function DoorOpener:doorOpenerNew(settings)
    local settings = settings or {}

    self.door_opener_closest_door = nil
    -- self.area:createEntity('Instruction', self.x, self.y, {parent = self, text = 'E to open door', offset_x = 0, offset_y = 0})
end

function DoorOpener:doorOpenerUpdate(dt)
    self.door_opener_closest_door = self.area:queryClosestAreaCircle({self.id}, self.x, self.y, 50, {'Door', 'LevelTransition'})
    if self.door_opener_closest_door then self.door_opener_closest_door.highlighted = true 
    else self.area:applyEntitiesWhere(function() return true end, {'Door', 'LevelTransition'}, function(door) door.highlighted = false end) end

    if self.fg.input:pressed('action') and self.door_opener_closest_door and not self.action_locked then
        if self.door_opener_closest_door.changeDoorState then
            self.door_opener_closest_door:changeDoorState()
        else self.door_opener_closest_door:changeLevel() end
    end
end

function DoorOpener:doorOpenerDraw()

end

return DoorOpener
