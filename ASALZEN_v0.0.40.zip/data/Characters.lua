fg.characters = {
    {
        name = 'Udseth',
        playable = true,
        hair_index = 8,
        hp = 100,
        damage = 10,
        stamina = 100,
        defense = 5,
        item_find = 0,
        lock_type = 'Auto',
        actions = {
            left_button = 'Block',
            left_shoulder = 'Lock',
            right_button = 'LightAttack1',
            right_shoulder = 'HeavyAttack1',
            fright = 'Dodge',
        },
        passives = {
            'Flashstep',
        }
    },

    {
        name = 'NoviceBrawler',
        hair_color = {241, 128, 91},
        hp = {40, 50},
        damage = {6, 10},
        stamina = 30,
        defense = 3,
        agro_type = 'Self',
        actions = {
            left_button = 'Block',
            right_button = 'LightAttack1',
            right_shoulder = 'HeavyAttack1',
            fright = 'Dodge',
        }
    },
}
