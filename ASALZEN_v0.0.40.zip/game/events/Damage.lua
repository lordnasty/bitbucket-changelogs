game.events['Damage'] = function(source, target, s)
    local s = s or {}
    local damage = math.floor(s.damage_multiplier*source.damage - target.defense)
    return damage
end
