game.events['RandomLightAttackMAEvent'] = function(random_light_attack, source, target)

end
