local HP = fg.Class('HP', 'Entity')

HP.layer = 'UI'

function HP:new(area, x, y, settings)
    local settings = settings or {}
    HP.super.new(self, area, x, y, settings)
end

function HP:update(dt)

end

function HP:draw()
    if self.parent.class_name == 'NPC' then
        local l, r = -8, 10
        if self.parent.animation_flip == -1 then l, r = -10, 8 end
        love.graphics.setColor(64, 64, 64, 192)
        love.graphics.line(self.parent.x + l, self.parent.y - 56, self.parent.x + r, self.parent.y - 56)
        love.graphics.setColor(222, 64, 64, 255)
        love.graphics.line(self.parent.x + l, self.parent.y - 56, self.parent.x + l + r*self.parent.current_hp/self.parent.hp, self.parent.y - 56)
    end
end

return HP
