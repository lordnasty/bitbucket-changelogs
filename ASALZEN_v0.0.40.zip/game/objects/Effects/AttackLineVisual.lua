local AttackLineVisual = fg.Class('AttackLineVisual', 'Entity')

AttackLineVisual.layer = 'Floor'

function AttackLineVisual:new(area, x, y, settings)
    local settings = settings or {}
    AttackLineVisual.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    self.sx, self.sy = 0.5, 0.5
    self.visual = self.fg.Assets.triangle
    self.target_1 = settings.target_1
    self.target_2 = settings.target_2
    self.last_target_1 = nil
    self.last_target_2 = nil
end

function AttackLineVisual:update(dt)
    self.timer:update(dt)

    -- Enter
    if self.target_2 and self.last_target_2 then
        if self.target_2.id ~= self.last_target_2.id then
            self.sx, self.sy = 1, 1
            self.timer:tween('scale_down', 0.3, self, {sx = 0.5, sy = 0.5}, 'linear')
        end
    end

    self.last_target_2 = self.target_2
end

function AttackLineVisual:draw()
    --[[
    local pointEquality = function(x1, y1, x2, y2, e) if math.sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1)) <= e then return true end end
    love.graphics.setColor(172, 107, 142, 255)
    if self.target_1 and self.target_2 then
        local x1, y1 = self.target_1.x, self.target_1.y
        local x2, y2 = self.target_2.x, self.target_2.y
        local angle = math.atan2(y2 - y1, x2 - x1)
        local cx, cy = x1 + (x2 - x1)*0.1, y1 + (y2 - y1)*0.1
        local fx, fy = x1 + (x2 - x1)*0.9, y1 + (y2 - y1)*0.9
        love.graphics.draw(self.visual, cx, cy, angle, self.sx, self.sy, 8, 8)
        while not pointEquality(cx, cy, fx, fy, 10) do
            cx, cy = cx + 10*math.cos(angle), cy + 10*math.sin(angle)
            love.graphics.draw(self.visual, cx, cy, angle, self.sx, self.sy, 8, 8)
        end
    end
    love.graphics.setColor(255, 255, 255, 255)
    ]]--
end

function AttackLineVisual:highlightDraw()
    local pointEquality = function(x1, y1, x2, y2, e) if math.sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1)) <= e then return true end end
    love.graphics.setColor(172, 107, 142, 255)
    if self.target_1 and self.target_2 then
        local x1, y1 = self.target_1.x, self.target_1.y
        local x2, y2 = self.target_2.x, self.target_2.y
        local angle = math.atan2(y2 - y1, x2 - x1)
        local cx, cy = x1 + (x2 - x1)*0.1, y1 + (y2 - y1)*0.1
        local fx, fy = x1 + (x2 - x1)*0.9, y1 + (y2 - y1)*0.9
        love.graphics.draw(self.visual, cx, cy, angle, self.sx, self.sy, 8, 8)
        while not pointEquality(cx, cy, fx, fy, 10) do
            cx, cy = cx + 10*math.cos(angle), cy + 10*math.sin(angle)
            love.graphics.draw(self.visual, cx, cy, angle, self.sx, self.sy, 8, 8)
        end
    end
    love.graphics.setColor(255, 255, 255, 255)
end

return AttackLineVisual
