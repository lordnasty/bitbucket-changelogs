local Player = fg.Class('Player', 'Person')
Player:implement(PersonMovement)
Player:implement(DoorOpener)

Player.ignores = {'Table'}

function Player:new(area, x, y, settings)
    local settings = settings or {}
    Player.super.new(self, area, x, y, settings)

    for key, action in pairs(fg.player_controls) do self.fg.input:bind(key, action) end

    self:doorOpenerNew()
    self:personMovementNew({settings = settings})
    self:bindActions(settings.character and settings.character.actions)
    self:setPassives(settings.character and settings.character.passives)

    game.player = self
    fg.world.camera:follow(self, {lerp = 2})
end

function Player:update(dt)
    Player.super.update(self, dt)

    self:personMovementUpdate(dt)
    self:doorOpenerUpdate(dt)
end

function Player:draw()
    Player.super.draw(self)
end

function Player:save()
    local save_data = Player.super.save(self)
    local movement = self:personMovementSave()
    for k, v in pairs(movement) do save_data[k] = v end
    return save_data
end

return Player
