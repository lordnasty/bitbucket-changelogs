local MagneticAdmiration = fg.Object:extend('MagneticAdmiration')

function MagneticAdmiration:new(settings)
    local settings = settings or {}
    for k, v in pairs(settings) do self[k] = v end

end

function MagneticAdmiration:update(dt)

end

function MagneticAdmiration:init()
    self.parent:bindAction('left_button', 'RandomLightAttackMA')
    self.parent:bindAction('right_button', 'RandomLightAttackMA')
    self.parent:bindAction('right_shoulder', 'Empty')
end

return MagneticAdmiration
