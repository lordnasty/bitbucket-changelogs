local Passives = fg.Object:extend('Passives')

function Passives:passivesNew(settings)
    local settings = settings or {}

    self.passive_list = {
        Flashstep = Flashstep({parent = self}),
        MagneticAdmiration = MagneticAdmiration({parent = self}),
    }

    self.passives = {}
    self:setPassives(settings.settings.passives or (settings.settings.character and settings.settings.character.passives))
end

function Passives:passivesUpdate(dt)

end

function Passives:setPassives(passives)
    if not passives then return end
    for _, passive in ipairs(passives) do 
        self.passives[passive] = self.passive_list[passive] 
        if self.passives[passive].init then self.passives[passive]:init() end
    end
end

function Passives:applyPreActionPassives(action_object, action)
    for _, passive in pairs(self.passives) do
        if passive.trigger_type == 'Pre Attack' and passive.combat_type == action_object.type and 
           passive.combat_class == action_object.class and passive.combat_range == action_object.range then
            if passive.apply then passive:apply(action) end
        end
    end
end

function Passives:passivesSave()
    local passives = {}
    for k, v in pairs(self.passives) do table.insert(passives, k) end
    return {passives = passives}
end

return Passives
