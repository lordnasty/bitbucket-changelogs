local Stats = fg.Object:extend('Stats')

function Stats:statsNew(settings)
    local settings = settings or {}

    -- Status
    self.knockdback = settings.settings.knockdback
    self.dodging = settings.settings.dodging
    self.blocking = settings.settings.blocking
    self.attacking = settings.settings.attacking
    self.locked = settings.settings.locked
    self.flashstep = settings.settings.flashstep

    -- Stats
    self.hp = self:setHP(settings.settings.hp or (settings.settings.character and settings.settings.character.hp)) 
    self.stamina = self:setStamina(settings.settings.stamina or (settings.settings.character and settings.settings.character.stamina))
    self.damage = self:setDamage(settings.settings.damage or (settings.settings.character and settings.settings.character.damage))
    self.defense = self:setDefense(settings.settings.defense or (settings.settings.character and settings.settings.character.defense))
    self.item_find = self:setItemFind(settings.settings.item_find or (settings.settings.character and settings.settings.character.item_find))

    -- Resource
    self.current_hp = settings.settings.current_hp or 0
    self.current_stamina = settings.settings.current_stamina or self.stamina
end

function Stats:statsUpdate(dt)

end

function Stats:statsDraw()

end

function Stats:setHP(hp)
    if hp then self.base_hp = self:RIT(hp) end

    if self.base_hp then
        self.hp = self.base_hp
    end

    return self.hp
end

function Stats:dealDamage(damage)
    self.current_hp = self.current_hp + damage
    if self.current_hp > self.hp then self.current_hp = self.hp end
end

function Stats:setStamina(stamina)
    if stamina then self.base_stamina = self:RIT(stamina) end
    
    if self.base_stamina then
        self.stamina = self.base_stamina
    end

    return self.stamina
end

function Stats:setDamage(damage)
    if damage then self.base_damage = self:RIT(damage) end
    
    if self.base_damage then
        self.damage = self.base_damage
    end

    return self.damage
end

function Stats:setDefense(defense)
    if defense then self.base_defense = self:RIT(defense) end

    if self.base_defense then 
        self.defense = self.base_defense 
    end

    return self.defense
end

function Stats:setItemFind(item_find)
    if item_find then self.base_item_find = self:RIT(item_find) end

    if self.base_item_find then 
        self.item_find = self.base_item_find 
    end

    return self.item_find
end

function Stats:RIT(value)
    if type(value) == 'table' then return math.random(value[1], value[2])
    else return value end
end

function Stats:statsSave()
    return {
        base_damage = self.base_damage, current_hp = self.current_hp, base_hp = self.base_hp, base_defense = self.base_defense,
        base_item_find = self.base_item_find, base_stamina = self.base_stamina, current_stamina = self.current_stamina,
        damage = self.damage, hp = self.hp, defense = self.defense, item_find = self.item_find, stamina = self.stamina,
        knockdback = self.knockdback, dodging = self.dodging, blocking = self.blocking, attacking = self.attacking, locked = self.locked,
        flashstep = self.flashstep,
    }
end

return Stats
