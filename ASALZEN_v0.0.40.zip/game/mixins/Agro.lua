local Agro = fg.Object:extend('Agro')

function Agro:agroNew(settings)
    local settings = settings or {}

    self.agro_type = (settings.settings.character and settings.settings.character.agro_type) or settings.settings.agro_type or 'Passive'
    self.agroed = self.fg.obv(settings.settings.agroed)
    self.agro_attacker = nil -- the entity that attacked this NPC
end

function Agro:agroUpdate(dt)
    if self.agroed:enter(true) then
        if self.agro_type == 'Passive' then 
            self.agroed:set(false)

        elseif self.agro_type == 'Self' then
            self.timer:after('alert', 0.1, function() self:alert(self.agro_attacker) end)

        elseif self.agro_type == 'Alert' then
            self.timer:after('alert', 0.1, function() self:alert(self.agro_attacker) end)
            -- TODO: alert nearby friends
        end
    end
end

function Agro:agroDraw()

end

function Agro:alert(attacker)
    local dx = 1
    local direction = self.fg.utils.angleToDirection2(self.fg.Vector(attacker.body:getPosition()):angleTo(self.fg.Vector(self.body:getPosition())))
    self.direction = direction
    if direction == 'right' then dx = -1 end
    self.area:createEntity('Exclamation', self.x, self.y, {parent = self, duration = 0.8, offset_x = dx*12, offset_y = -42})
end

function Agro:hitATK(attacker)
    self.agroed:setd(true)
    self.agro_attacker = attacker
end

function Agro:agroSave()
    return {agro_type = self.agro_type, agroed = self.agroed}
end

return Agro
