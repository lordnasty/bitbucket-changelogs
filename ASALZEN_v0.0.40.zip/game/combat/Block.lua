local Block = fg.Object:extend('Block')

function Block:new(settings)
    local settings = settings or {}
    for k, v in pairs(settings) do self[k] = v end
    self.type = 'Block'
end

function Block:update(dt)

end

function Block:pressed()

end

function Block:down(dt)
    -- while attacking can't block
    -- while dodging can't block
    if self.parent.attacking or self.parent.dodging then return end 
    self.parent.movement_locked = true -- while blocking can't move
    self.parent.blocking = true
    self.parent:setAnimationState('block')
end

function Block:released()
    self.parent.movement_locked = false
    self.parent.blocking = false
    self.parent['block'] = false
end

return Block
