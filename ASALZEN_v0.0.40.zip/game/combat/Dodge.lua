local Dodge = fg.Object:extend('Dodge')

function Dodge:new(settings)
    local settings = settings or {}
    for k, v in pairs(settings) do self[k] = v end
    self.type = 'Dodge'
    self.dodge_cooldown = 0.5
    self.can_dodge = true
end

function Dodge:update(dt)

end

function Dodge:pressed()
    -- while dodging can't dodge
    -- while attacking can't dodge
    if not self.can_dodge or self.parent.attacking then return end 
    self.can_dodge = false
    self.parent.timer:after('Dodge_cooldown', self.dodge_cooldown, function() self.can_dodge = true end)
    self.parent:interruptAttack()
    -- dodge interrupts knockback
    self.parent:interruptKnockback()

    local fx, fy = 0, 0
    if self.parent.fg.input:down('moveLeft') then fx = -350 end
    if self.parent.fg.input:down('moveRight') then fx = 350 end
    if self.parent.fg.input:down('moveUp') then fy = -200 end
    if self.parent.fg.input:down('moveDown') then fy = 200 end
    local gpx, gpy = self.parent.fg.input:down('moveHorizontal'), self.parent.fg.input:down('moveVertical')
    if math.abs(gpx or 0) > 0.1 or math.abs(gpy or 0) > 0.1 then fx = 350*gpx; fy = 200*gpy end

    self.parent.dodging = true
    self.parent:changeCollisionClass('main', 'PlayerIgnoresNPC')

    -- Static backdash
    if fx == 0 and fy == 0 then
        self.parent:push(-self.parent.animation_flip*150, 0, 0.3)
        self.parent.v_z = -60
        self.parent:setAnimationState('backdash')
        self.parent.timer:after('Dodge_undash', 0.4, function() 
            self.parent.dodging = false
            self.parent.backdash = false 
            self.parent:changeCollisionClass('main', 'Person')
        end)

    -- Front or backdash...
    elseif fx ~= 0 or fy ~= 0 then
        if self.parent.locked and ((self.parent.animation_flip == 1 and fx < 0) or (self.parent.animation_flip == -1 and fx > 0)) then
            self.parent:push(-self.parent.animation_flip*150, 0, 0.3)
            self.parent.v_z = -60
            self.parent:setAnimationState('backdash')
            self.parent.timer:after('Dodge_undash', 0.4, function() 
                self.parent.dodging = false
                self.parent.backdash = false 
                self.parent:changeCollisionClass('main', 'Person')
            end)
        else
            self.parent:push(fx, fy, 0.15)
            self.parent.v_z = -40
            self.parent:setAnimationState('dash')
            self.parent.timer:after('Dodge_undash', 0.4, function() 
                self.parent.dodging = false
                self.parent.dash = false 
                self.parent.backdash = false
                self.parent:changeCollisionClass('main', 'Person')
            end)
        end
    end
end

function Dodge:down()

end

function Dodge:released()

end

return Dodge
