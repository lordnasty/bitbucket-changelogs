local RandomLightAttackMA = fg.Object:extend('RandomLightAttackMA')

function RandomLightAttackMA:new(settings)
    local settings = settings or {}
    for k, v in pairs(settings) do self[k] = v end

end

function RandomLightAttackMA:update(dt)

end

function RandomLightAttackMA:interrupt()
    
end

function RandomLightAttackMA:pressed()

end

function RandomLightAttackMA:down(dt)

end

function RandomLightAttackMA:released()

end

return RandomLightAttackMA
