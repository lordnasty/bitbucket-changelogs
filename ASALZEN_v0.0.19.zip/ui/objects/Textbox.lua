local Textbox = fg.Object:extend('Textbox')

function Textbox:new()
    self.fs = 24*fg.screen_scale/512
    self.text = settings.text
    self.font = fg.Fonts.helsinki
    self.timer = fg.Timer()

end

function Textbox:update(dt)
    self.timer:update(dT)

end

function Textbox:draw()

end

return Textbox
