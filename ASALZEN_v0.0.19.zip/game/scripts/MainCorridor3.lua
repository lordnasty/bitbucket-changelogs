local MainCorridor3 = fg.Object:extend('MainCorridor3')

function MainCorridor3:new(data)
    if data then for k, v in pairs(data) do self[k] = v end end
end

function MainCorridor3:update(dt)

end

function MainCorridor3:initPost()
    if self.ran_once then return end
    self.ran_once = true

    local player = SH.getPlayer()
    player.movement_locked = true
    local x, y = player.body:getPosition()
    player:moveTo(x + 30, y - 30)
end

function MainCorridor3:save()
    return {ran_once = self.ran_once}
end

return MainCorridor3
