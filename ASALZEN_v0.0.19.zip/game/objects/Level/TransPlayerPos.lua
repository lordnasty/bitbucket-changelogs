local TransPlayerPos = fg.Class('TransPlayerPos', 'Entity')

function TransPlayerPos:new(area, x, y, settings)
    local settings = settings or {}
    TransPlayerPos.super.new(self, area, x, y, settings)
end

function TransPlayerPos:update(dt)

end

function TransPlayerPos:draw()

end

function TransPlayerPos:save()
    return {id = self.id, x = self.x, y = self.y, linked_object_target_level = self.linked_object_target_level}
end

return TransPlayerPos
