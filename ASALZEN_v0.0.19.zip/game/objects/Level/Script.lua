local Script = fg.Class('Script', 'Entity')

function Script:new(area, x, y, settings)
    local settings = settings or {}
    Script.super.new(self, area, x, y, settings)

    if settings.script_data then self.script = Scripts[self.script_name](settings.script_data)
    else self.script = Scripts[self.script_name]() end
end

function Script:update(dt)
    if self.script.update then self.script:update(dt) end
end

function Script:draw()
    if self.script.draw then self.script:draw() end
end

function Script:init()
    if self.script.init then self.script:init() end
end

function Script:initPost()
    if self.script.initPost then self.script:initPost() end
end

function Script:save()
    local script_data = nil
    if self.script then if self.script.save then script_data = self.script:save() end end
    return {id = self.id, x = self.x, y = self.y, script_name = self.script_name, script_data = script_data}
end

return Script
