local LevelTransition = fg.Class('LevelTransition', 'Entity')
LevelTransition:implement(fg.PhysicsBody)

LevelTransition.ignores = {'All'}

function LevelTransition:new(area, x, y, settings)
    local settings = settings or {}
    LevelTransition.super.new(self, area, x, y, settings)
    self:physicsBodyNew(area, x, y, settings)
end

function LevelTransition:update(dt)
    self:physicsBodyUpdate(dt)
end

function LevelTransition:draw()
    self:physicsBodyDraw(192, 128, 64)
end

function LevelTransition:save()
    local x, y = self.body:getPosition()
    return {id = self.id, x = x, y = y, w = self.w, h = self.h, body_type = 'static'}
end

return LevelTransition
