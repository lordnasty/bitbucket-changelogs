local SnowBlock = fg.Class('SnowBlock', 'Entity')
SnowBlock:implement(fg.PhysicsBody)

function SnowBlock:new(area, x, y, settings)
    local settings = settings or {}
    SnowBlock.super.new(self, area, x, y, settings)
    settings.w, settings.h = 32, 32
    self:physicsBodyNew(area, x, y, settings)
    self.body:setFixedRotation(false)

    self.snow_breakable_visual = self.fg.Assets.snow_breakable
    local w, h = self.snow_breakable_visual:getWidth(), self.snow_breakable_visual:getHeight()
    self.snow_block_quad_1 = love.graphics.newQuad(0, 0, 32, 32, w, h)
    self.snow_block_quad_2 = love.graphics.newQuad(0, 32, 32, 32, w, h)
    self.snow_block_quad_3 = love.graphics.newQuad(0, 64, 32, 32, w, h)
    self.snow_block_id = 'snow_block_quad_' .. settings.block_id

    self.hp = 5
end

function SnowBlock:update(dt)
    self:physicsBodyUpdate(dt)
    self.r = self.body:getAngle()
end

function SnowBlock:draw()
    self:physicsBodyDraw()
    love.graphics.draw(self.snow_breakable_visual, self[self.snow_block_id], self.x, self.y, self.r, self.sx, self.sy, 16, 16)
end

function SnowBlock:hitATK(attacker, attack_type)
    self.area.world.camera:shake(0.5, 0.2)
    self.hp = self.hp - 1
    for i = 1, 2 do self.area:createEntity('SnowRock', self.x, self.y, {size_id = self.fg.utils.table.random({'8L', '8R', '4L', '4R', '2L', '2R'})}) end
    if self.hp <= 0 then
        self.dead = true
        for i = 1, 2 do self.area:createEntity('SnowRock', self.x, self.y, {size_id = self.fg.utils.table.random({'16L1', '16R1'})}) end
    end
end

function SnowBlock:trigger()
    print(1)
end

function SnowBlock:save()
    local save_data = {}
    save_data.block_id = self.block_id
    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y
    save_data.w, save_data.h = self.w, self.h
    save_data.shape = 'Rectangle'
    return save_data
end

return SnowBlock
