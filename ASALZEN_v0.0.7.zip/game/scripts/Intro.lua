local Intro = fg.Object:extend('Intro')

function Intro:new(data)
    if data then for k, v in pairs(data) do self[k] = v end end
    self.timer = fg.Timer()
end

function Intro:update(dt)
    self.timer:update(dt)
end

function Intro:init()
    game:screenTransition('rectangle up', 0)
    game:screenTransition('rectangle lr down', 1.5)

    local player = SH.getPlayer()
    player:setAnimationState('down_idle')
    player.movement_locked = true

    -- Blood
    for i = 1, 8 do fg.world.areas['Intro']:createEntity('BloodPool', player.x + fg.utils.math.random(-16, 16), player.y + fg.utils.math.random(-16, 16)) end

    local shake_after = 8

    -- Big shake
    self.timer:after(shake_after, function()
        fg.world.camera:shake(8, 1, {tween_down = true})
        -- Move objects around a bit
        self.timer:every(0.1, function()
            fg.world.areas['Intro']:applyEntitiesWhere(function() return true end, {'Box', 'Chair', 'Desk', 'Bucket'}, function(o)
                if o.class_name ~= 'Bucket' then
                    local fx, fy = fg.utils.math.random(-45, 45), fg.utils.math.random(-45, 45)
                    o.body:applyLinearImpulse(fx, fy)
                else
                    local fx, fy = fg.utils.math.random(-5, 5), fg.utils.math.random(-5, 5)
                    o.body:applyLinearImpulse(fx, fy)
                end
            end)
        end, 5)
        -- Make buckets fall down
        local buckets = fg.world.areas['Intro']:getEntitiesWhere(function() return true end, {'Bucket'})
        for _, b in ipairs(buckets) do
            self.timer:after({0.2, 0.5}, function() b:fallDown() end)
        end
    end)

    -- Player gets up
    self.timer:after(shake_after + 0.5, function()
        fg.world.areas['Intro']:createEntity('Exclamation', player.x, player.y, {parent = player, duration = 0.8, offset_x = 26, offset_y = -14})
    end)
    self.timer:after(shake_after + 0.5, function() player.head:preGetUp() end)
    self.timer:after(shake_after + 1.5, function()
        player:playAnimation('get_up', function() 
            player.movement_locked = false
            player.head:postGetUp() 
        end)
    end)
end

return Intro
