Behavior = fg.Object:extend('Behavior')

function Behavior:new()
    self.status = 'invalid'
end

function Behavior:update(dt, context)
    if self.status ~= 'running' then self:start(context) end
    self.status = self:run(dt, context)
    if self.status ~= 'running' then self:finish(self.status, context) end
    return self.status 
end
