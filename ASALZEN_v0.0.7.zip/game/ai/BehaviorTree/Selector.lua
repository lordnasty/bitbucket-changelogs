Selector = Behavior:extend('Selector')

function Selector:new(name, behaviors)
    Selector.super.new(self)
    self.name = name
    self.behaviors = behaviors 
    self.current_behavior = 1
end

function Selector:update(dt, context)
    return Selector.super.update(self, dt, context)
end

function Selector:run(dt, context)
    while true do
        local status = self.behaviors[self.current_behavior]:update(dt, context)
        if status ~= 'failure' then return status end
        self.current_behavior = self.current_behavior + 1
        if self.current_behavior == #self.behaviors + 1 then return 'failure' end
    end
end

function Selector:start(context)
    self.current_behavior = 1
end

function Selector:finish(status, context)

end
