local AttackLockVisual = fg.Class('AttackLockVisual', 'Entity')

AttackLockVisual.layer = 'Floor'

function AttackLockVisual:new(area, x, y, settings)
    AttackLockVisual.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    self.animation = self.fg.Animation(self.fg.Assets.locked_on, 64, 64, 0.03)

    self.parent = nil
    self.last_parent = nil
    self.sx, self.sy = 1, 1
end

function AttackLockVisual:update(dt)
    self.timer:update(dt)
    self.animation:update(dt)

    if self.parent then self.x, self.y = self.parent.x, self.parent.y end
    -- Exit
    if self.last_parent and not self.parent then self.x, self.y = -10000, -10000
    -- Enter
    elseif self.parent and (not self.last_parent or self.last_parent.id ~= self.parent.id)  then
        self.sx, self.sy = 3, 3 
        self.timer:tween('scale_down', 0.4, self, {sx = 1, sy = 1}, 'linear')
    end

    self.last_parent = self.parent
end

function AttackLockVisual:draw()
    local animation_flip = 0
    if self.parent then animation_flip = self.parent.animation_flip end
    love.graphics.setColor(229, 142, 189, 255)
    self.animation:draw(self.x, self.y, 0, self.sx, self.sy, 32 - animation_flip*1, 32 + 14)
    love.graphics.setColor(255, 255, 255, 255)
end

return AttackLockVisual
