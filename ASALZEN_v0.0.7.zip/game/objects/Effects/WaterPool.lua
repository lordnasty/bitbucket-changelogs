local WaterPool = fg.Class('WaterPool', 'Entity')

WaterPool.pool_enabled = 200
WaterPool.pool_overflow_rule = 'distance'

function WaterPool:new(area, x, y, settings)
    local settings = settings or {}
    WaterPool.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    local random = fg.utils.math.random
    self.color = settings.color or {143 + random(-4, 4), 157 + random(-4, 4), 177 + random(-4, 4), 255}

    self.w, self.h = settings.w or 64, settings.h or 64
    self:construct(settings)
end

function WaterPool:update(dt)
    self.timer:update(dt)
    self.fg.Spritebatches['Water'].spritebatch:add(self.water_quad, self.x, self.y, self.angle, self.sx, self.sy, self.w/2, self.h/2)
end

function WaterPool:draw()

end

function WaterPool:reset(x, y, settings)
    self.x, self.y = x, y
    self:construct(settings)
end

function WaterPool:construct(settings)
    local settings = settings or {}
    self.angle = settings.angle or 0

    self.sx = 0.1
    self.sy = 0.1
    self.water_quad = love.graphics.newQuad(math.random(0, 3)*64, 0, 64, 64, self.fg.Assets.blood_64:getWidth(), self.fg.Assets.blood_64:getHeight())
    self.timer:tween('pool_up', settings.tween_up_duration or 1, self, {sx = settings.sx or 1, sy = settings.sy or 1}, 'linear')
end

function WaterPool:save()
    return {id = self.id, x = self.x, y = self.y, angle = self.angle, sx = self.sx, sy = self.sy, w = self.w, h = self.h}
end

return WaterPool
