local DownWall = fg.Class('DownWall', 'Entity')

DownWall.layer = {'Debug'}

function DownWall:new(area, x, y, settings)
    local settings = settings or {}
    DownWall.super.new(self, area, x, y, settings)
end

function DownWall:update(dt)

end

function DownWall:draw()
    love.graphics.setColor(64, 64, 64)
    love.graphics.rectangle('line', self.x - self.w/2, self.y - self.h/2, self.w, self.h)
    love.graphics.setColor(255, 255, 255)
end

return DownWall
