local CameraLimit = fg.Class('CameraLimit', 'Entity')

function CameraLimit:new(area, x, y, settings)
    local settings = settings or {}
    CameraLimit.super.new(self, area, x, y, settings)
end

function CameraLimit:update(dt)

end

function CameraLimit:draw()

end

return CameraLimit
