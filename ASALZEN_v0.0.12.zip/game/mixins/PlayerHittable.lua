local PlayerHittable = fg.Object:extend('PlayerHittable')

function PlayerHittable:playerHittableNew(settings)
    local settings = settings or {}

    self.hit = settings.settings.hit or false
    self.flash_hit = settings.settings.flash_hit or false
end

function PlayerHittable:playerHittableUpdate(dt)

end

function PlayerHittable:playerHittableDraw()

end

function PlayerHittable:hitATK(attacker, attack_type)
    local angle_to_attacker = self.fg.Vector(attacker.x, attacker.y):angleTo(self.fg.Vector(self.x, self.y))
    self.direction = self.fg.utils.angleToDirection2(angle_to_attacker)
    self.flash_hit = true
    self.hit = true
    self.timer:after('flash_hit', 0.1, function() self.flash_hit = false end)
    self.timer:after('hit', 0.8, function() self.hit = false end)

    -- Juice
    self.sx, self.sy = self.fg.utils.math.random(1.04, 1.14), self.fg.utils.math.random(1.04, 1.14)
    local r = self.fg.utils.math.random(0.2, 0.4)
    self.timer:tween('hit_scale_tween', r, self, {sx = 1, sy = 1}, 'in-out-cubic')
    self.timer:after('hit_scale_after', r, function() self.sx = 1; self.sy = 1 end)
end

function PlayerHittable:playerHittableSave()

end

return PlayerHittable
