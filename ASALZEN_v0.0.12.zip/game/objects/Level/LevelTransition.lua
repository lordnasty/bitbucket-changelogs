local LevelTransition = fg.Class('LevelTransition', 'Entity')
LevelTransition:implement(fg.PhysicsBody)

LevelTransition.ignores = {'All'}

function LevelTransition:new(area, x, y, settings)
    local settings = settings or {}
    LevelTransition.super.new(self, area, x, y, settings)
    self:physicsBodyNew(area, x, y, settings)
    self.target_level = settings.target_level
    self.door_opened = self.fg.Assets.door_opened
end

function LevelTransition:update(dt)
    self:physicsBodyUpdate(dt)
end

function LevelTransition:draw()
    self:physicsBodyDraw(192, 128, 64)
    if self.highlighted then
        love.graphics.setLineStyle('rough')
        love.graphics.setColor(192, 32, 32)
        love.graphics.rectangle('line', self.x - self.w/2, self.y - self.h - self.h/2, self.w, self.h)
        love.graphics.setColor(255, 255, 255)
    end
end

function LevelTransition:highlightDraw()
    if self.highlighted then
        love.graphics.setLineStyle('rough')
        love.graphics.setColor(192, 32, 32)
        love.graphics.rectangle('line', self.x - self.w/2, self.y - self.h - self.h/2, self.w, self.h)
        love.graphics.setColor(255, 255, 255)
    end
end

function LevelTransition:changeLevel()
    game.levels[self.area.name]:changeLevelTo(self.target_level, 0.5)
end

function LevelTransition:save()
    local x, y = self.body:getPosition()
    return {id = self.id, x = x, y = y, w = self.w, h = self.h, body_type = 'static', target_level = self.target_level}
end

return LevelTransition
