local Instruction = fg.Class('Instruction', 'Entity')

Instruction.layer = 'UI'

function Instruction:new(area, x, y, settings)
    local settings = settings or {}
    Instruction.super.new(self, area, x, y, settings)
    self.font = self.fg.Assets.fonts.PixieKid
end

function Instruction:update(dt)
    if self.parent and self.parent.door_opener_closest_door then
        self.x, self.y = self.parent.x + self.offset_x, self.parent.y + self.offset_y
        if self.parent.dead then self.parent = nil end
    end
end

function Instruction:draw()
    if self.parent and not self.parent.door_opener_closest_door then return end
    local font = love.graphics.getFont()
    love.graphics.setFont(self.font)
    local w, h = self.font:getWidth(self.text), self.font:getHeight()
    love.graphics.print(self.text, self.x - w/2, self.y - h/2)
    love.graphics.setFont(font)
end

return Instruction
