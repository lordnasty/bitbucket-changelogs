local moveToPoint = Action:extend('moveToPoint')

function moveToPoint:new()
    moveToPoint.super.new(self, 'moveToPoint')
    self.last_position = self.fg.Vector(0, 0)
    self.stuck = false
end

function moveToPoint:update(dt, context)
    return moveToPoint.super.update(self, dt, context)
end

function moveToPoint:run(dt, context)
    if self.stuck then return 'failure' end
    if context.move_to_point_target then
        local distance = context.move_to_point_target:dist(self.fg.Vector(context.object.body:getPosition()))
        if distance < 10 then return 'success'
        elseif distance >= 10 then return 'running' end
    else return 'failure' end
end

function moveToPoint:start(context)
    if context.any_around_entity then 
        if context.any_around_entity.body then context.move_to_point_target = self.fg.Vector(context.any_around_entity.body:getPosition()) 
        else context.move_to_point_target = self.fg.Vector(context.any_around_entity.x, context.any_around_entity.y) end
    end

    context.object:arriveOn(context.move_to_point_target)
    context.object.timer:every('move_to_point_timer', 4, function()
        local current_position = self.fg.Vector(context.object.body:getPosition())
        local distance = current_position:dist(self.last_position)
        if distance < 5 then self.stuck = true end
        self.last_position = current_position
    end)
end

function moveToPoint:finish(status, context)
    context.object:arriveOff()
    context.move_to_point_target = nil
    context.object.timer:cancel('move_to_point_timer')
    self.stuck = false
end

return moveToPoint
