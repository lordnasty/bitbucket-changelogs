local CapsuleTerminal = fg.Class('CapsuleTerminal', 'Entity')

function CapsuleTerminal:new(area, x, y, settings)
    local settings = settings or {}
    CapsuleTerminal.super.new(self, area, x, y, settings)

    self.terminal_visual = self.fg.Assets.terminal
end

function CapsuleTerminal:update(dt)

end

function CapsuleTerminal:draw()
    love.graphics.draw(self.terminal_visual, self.x, self.y, 0, 1, 1, 16, 18.5)
end

return CapsuleTerminal
