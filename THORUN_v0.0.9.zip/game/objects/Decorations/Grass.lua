local Grass = fg.Class('Grass', 'Entity')

Grass.layer = 'Front_1'

function Grass:new(area, x, y, settings)
    local settings = settings or {}
    Grass.super.new(self, area, x, y, settings)
    local n = settings.n or math.random(0, 1)
    self.grass_visual = self.fg.Assets.grass
    self.grass_quad = love.graphics.newQuad(0, 32*n, 32, 32, 32, 64)
end

function Grass:update(dt)

end

function Grass:draw()
    love.graphics.draw(self.grass_visual, self.grass_quad, self.x, self.y, self.r or 0, 1, 1, 16, 16)
end

function Grass:save()
    return {id = self.id, x = self.x, y = self.y, n = self.n, r = self.r}
end

return Grass
