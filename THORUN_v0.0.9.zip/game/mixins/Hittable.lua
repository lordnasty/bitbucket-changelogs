local Hittable = fg.Object:extend('Hittable')

function Hittable:hittableNew(settings)
    local settings = settings or {}

    self.hit = settings.settings.just_hit or false
    self.dying = settings.settings.dying or false
    self.sx, self.sy = settings.settings.sx or 1, settings.settings.sy or 1
    self.r = settings.settings.r or 0

    self.hp = 3
    self.hit_r_list = {-0.2, 0.2, -0.1, 0.3, -0.35, 0.15, -0.15, 0.3} 
    self.hit_r_index = 1
end

function Hittable:hittableUpdate(dt)

end

function Hittable:hitATK(attacker, attack_type)
    local u = self.fg.utils
    local angle_to_attacker = self.fg.Vector(attacker.x, attacker.y):angleTo(self.fg.Vector(self.x, self.y))
    self.direction = self.fg.utils.angleToDirection2(angle_to_attacker)
    self.hit = true
    self.timer:after('hit', 0.3, function() self.hit = false end)

    self.hp = self.hp - 1
    if self.hp < 0 then self:die() end

    -- Juice
    self.sx, self.sy = u.math.random(1.04, 1.24), u.math.random(1.04, 1.24)
    local r = u.math.random(0.3, 0.6)
    self.timer:tween('hit_scale_tween', r, self, {sx = 1, sy = 1}, 'in-out-cubic')
    self.timer:after('hit_scale_after', r, function() self.sx = 1; self.sy = 1 end)
    self.r = self.hit_r_list[self.hit_r_index] + u.math.random(-0.1, 0.1)
    self.hit_r_index = self.hit_r_index + 1
    if self.hit_r_index > #self.hit_r_list then self.hit_r_index = 1 end
    self.timer:tween('hit_angle_tween', 6*r, self, {r = 0}, 'linear')
    for i = 1, math.random(1, 2) do self.area:createEntity('RobotBits', self.x, self.y, {r = u.math.random(-3*math.pi/4, -math.pi/4), v = u.math.random(50, 150)}) end
    self.area:createEntity('AnimatedEffect', self.x + u.math.random(-8, 8), self.y + u.math.random(-8, 8), 
                          {r = u.math.random(0, 2*math.pi), type = u.table.random({'hit_effect_1', 'hit_effect_2', 'hit_effect_3', 'hit_effect_4'})})
    self.area.world.camera:shake(0.5, 0.2)
end

function Hittable:die()
    self.dying = true
    self.dead = true
    self.area:createEntity('ExplosionEffect', self.x, self.y)
    for i = 1, math.random(2, 3) do self.area:createEntity('RobotBits', self.x, self.y, {r = self.fg.utils.math.random(-3*math.pi/4, -math.pi/4), v = self.fg.utils.math.random(100, 200)}) end
end

function Hittable:hittableSave()
    return {hit = self.hit, dying = self.dying, sx = self.sx, sy = self.sy, r = self.r}
end

return Hittable
