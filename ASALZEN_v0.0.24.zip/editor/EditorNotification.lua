local EditorNotification = fg.Object:extend('EditorNotification')

function EditorNotification:new(editor, x, y, notification_str)
    self.font = editor.font
    self.x, self.y = x, y
    self.target_y = self.y - 30
    self.text = notification_str 
    self.timer = fg.Timer()
    self.color = {255, 255, 255, 255}
    self.timer:tween('up', 0.2, self, {y = self.y - 30}, 'in-out-cubic')
    self.timer:tween('color', 5, self, {color = {0, 0, 0, 0}}, 'in-out-cubic')
    self.timer:after('death', 5, function() self.dead = true end)
end

function EditorNotification:update(dt)
    self.timer:update(dt)
end

function EditorNotification:draw()
    local r, g, b, a = unpack(self.color)
    love.graphics.setColor(r/2, g/2, b/2, a/8)
    love.graphics.rectangle('fill', self.x - 5, self.y - 5, self.font:getWidth(self.text) + 10, self.font:getHeight() + 10)
    love.graphics.setColor(r, g, b, a)
    love.graphics.print(self.text, self.x, self.y)
    love.graphics.setColor(255, 255, 255, 255)
end

function EditorNotification:pushUp(i)
    self.target_y = self.target_y - 30
    self.timer:tween('up', 0.2, self, {y = self.target_y}, 'in-out-cubic')
end

return EditorNotification
