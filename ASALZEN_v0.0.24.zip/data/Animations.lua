-- Structs
local anim_struct = function(state, image, size, delay, mode, offset)
    return {state = state, image = image, size = size, delay = delay, mode = mode, offset = offset}
end

fg.person_animations = {
    anim_struct('idle', 'male_idle', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('run', 'male_run', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('hit', 'male_hit', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('dash', 'male_dash', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('backdash', 'male_backdash', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('low_dash', 'male_low_dash', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('block', 'male_block', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('fall_down', 'male_fall_down', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('get_up', 'male_get_up', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('down_idle', 'male_down_idle', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('idle_combat', 'male_idle_combat', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('run_combat', 'male_run_combat', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('idle_punch_charge', 'male_idle_punch_charge', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('run_punch_charge', 'male_run_punch_charge', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('uppercut', 'male_uppercut', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('uppercut_front', 'male_uppercut_front', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('kick', 'male_kick', {64, 64}, 0.08, 'loop', {-32, -56}),
    anim_struct('light_punch_left', 'male_light_punch_left', {64, 64}, 0.05, 'loop', {-32, -56}),
    anim_struct('light_punch_right', 'male_light_punch_right', {64, 64}, 0.05, 'loop', {-32, -56}),
    anim_struct('strong_punch_left', 'male_strong_punch_left', {64, 64}, 0.05, 'loop', {-32, -56}),
    anim_struct('strong_punch_right', 'male_strong_punch_right', {64, 64}, 0.05, 'loop', {-32, -56}),
    anim_struct('strong_punch_left_arm', 'male_strong_punch_left_arm', {64, 64}, 0.05, 'loop', {-32, -56}),
    anim_struct('strong_punch_right_arm', 'male_strong_punch_right_arm', {64, 64}, 0.05, 'loop', {-32, -56}),
}
