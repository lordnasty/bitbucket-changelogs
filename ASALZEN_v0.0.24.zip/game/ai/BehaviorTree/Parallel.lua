Parallel = Behavior:extend('Parallel')

function Parallel:new(name, success_policy, failure_policy, behaviors)
    Parallel.super.new(self)
    self.name = name
    self.success_policy = success_policy
    self.failure_policy = failure_policy
    self.behaviors = behaviors
end

function Parallel:update(dt, context)
    return Parallel.super.update(self, dt, context)
end

function Parallel:run(dt, context)
    local success_count, failure_count = 0, 0 
    for _, behavior in ipairs(self.behaviors) do
        local status = nil
        status = behavior:update(dt, context)
            
        if status == 'success' then
            success_count = success_count + 1
            behavior:finish(status, context)
            if self.success_policy == 'one' then return 'success' end
        end

        if status == 'failure' then
            failure_count = failure_count + 1
            behavior:finish(status, context)
            if self.failure_policy == 'one' then return 'failure' end
        end
    end

    if self.failure_policy == 'all' and failure_count == #self.behaviors then return 'failure' end
    if self.success_policy == 'all' and success_count == #self.behaviors then return 'success' end
    return 'running'
end

function Parallel:start(context)
    
end

function Parallel:finish(status, context)
    for _, behavior in ipairs(self.behaviors) do
        if behavior.status == 'running' then
            behavior:finish(status, context)
        end
    end
end
