local wait = Action:extend('wait')

function wait:new(duration)
    wait.super.new(self, 'wait')

    self.wait_duration = duration
    self.done = false
end

function wait:update(dt, context)
    return wait.super.update(self, dt, context)
end

function wait:run(dt, context)
    if self.done then return 'success'
    else return 'running' end
end

function wait:start(context)
    context.object.timer:after('wait_timer', self.wait_duration, function() self.done = true end)
end

function wait:finish(status, context)
    self.done = false
end

return wait
