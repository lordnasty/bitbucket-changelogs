local separate = Action:extend('separate')

function separate:new(radius)
    separate.super.new(self, 'separate')

    self.radius = radius
end

function separate:update(dt, context)
    return separate.super.update(self, dt, context)
end

function separate:run(dt, context)
    return 'success'   
end

function separate:start(context)
    context.object:separationOn(self.radius)
end

function separate:finish(status, context)

end

return separate
