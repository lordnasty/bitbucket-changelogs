local Hittable = fg.Object:extend('Hittable')

function Hittable:hittableNew(settings)
    local settings = settings or {}

    self.hit = settings.settings.hit or false
    self.flash_hit = settings.settings.flash_hit or false
    self.dying = settings.settings.dying or false
    self.fall_down = settings.settings.fall_down or false
    self.down_idle = settings.settings.down_idle or false
    self.get_up = settings.settings.get_up or false
    self.stage_decreasing = settings.settings.stage_decreasing or false
    self.sx, self.sy = settings.settings.sx or 1, settings.settings.sy or 1
end

function Hittable:hittableUpdate(dt)

end

function Hittable:hitATK(attacker, attack_type)
    local angle_to_attacker = self.fg.Vector(attacker.x, attacker.y):angleTo(self.fg.Vector(self.x, self.y))
    self.direction = self.fg.utils.angleToDirection2(angle_to_attacker)
    self.flash_hit = true
    self.hit = true
    self.timer:after('flash_hit', 0.1, function() self.flash_hit = false end)
    self.timer:after('hit', 0.3, function() self.hit = false end)
    self.hp_seq:pop(attacker)

    -- Juice
    self.sx, self.sy = self.fg.utils.math.random(1.06, 1.18), self.fg.utils.math.random(1.06, 1.18)
    local r = self.fg.utils.math.random(0.2, 0.4)
    self.timer:tween('hit_scale_tween', r, self, {sx = 1, sy = 1}, 'in-out-cubic')
    self.timer:after('hit_scale_after', r, function() self.sx = 1; self.sy = 1 end)
end

function Hittable:decreaseStage(attacker)
    self:statsDecreaseHP(attacker)
    self.stage_decreasing = true
    self.timer:after('stage_decreasing', 4, function() 
        self.stage_decreasing = false 
        self:playAnimationFromFrame('get_up', 4)
    end)
end

function Hittable:die()
    self.dying = true
    self:playAnimation('fall_down', function() self.down_idle = true end)
end

function Hittable:hittableSave()
    local down_idle = self.down_idle
    if self.fall_down then down_idle = true; self.fall_down = false end
    return {hit = self.hit, dying = self.dying, sx = self.sx, sy = self.sy, down_idle = down_idle, fall_down = self.fall_down, get_up = self.get_up, stage_decreasing = self.stage_decreasing}
end

return Hittable
