local Broom = fg.Class('Broom', 'Entity')
Broom:implement(fg.PhysicsBody)
Broom:implement(Pseudo3D)

function Broom:new(area, x, y, settings)
    local settings = settings or {}
    settings.w = 24
    settings.h = 8
    y = y + 28
    Broom.super.new(self, area, x, y, settings)
    self:physicsBodyNew(area, x, y, settings)
    self:pseudo3DNew({z = settings.z, settings = settings})
    self.broom_quad = love.graphics.newQuad(0, 0, 32, 64, 64, 64)
    self.shadow_quad = love.graphics.newQuad(32, 0, 32, 64, 64, 64)
end

function Broom:update(dt)
    self:physicsBodyUpdate(dt)
    self:pseudo3DUpdate(dt)
end

function Broom:draw()
    self:physicsBodyDraw()
    local w, h = 32, 32
    -- Broom
    love.graphics.draw(self.fg.Assets.broom, self.broom_quad, self.x, self.y - self.z, 0, 1, 1, w/2, h/2 + 44)
end

function Broom:save()
    local pseudo_3d = self:pseudo3DSave()
    local save_data = {}
    for k, v in pairs(pseudo_3d) do save_data[k] = v end
    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y - 28
    save_data.w, save_data.h = self.w, self.h
    save_data.shape = 'Rectangle'
    return save_data
end

return Broom
