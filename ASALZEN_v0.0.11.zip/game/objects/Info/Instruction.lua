local Instruction = fg.Class('Instruction', 'Entity')

Instruction.layer = 'UI'

function Instruction:new(area, x, y, settings)
    local settings = settings or {}
    Instruction.super.new(self, area, x, y, settings)
    self.font = self.fg.Assets.fonts.PixieKid
end

function Instruction:update(dt)

end

function Instruction:draw()
    local font = love.graphics.getFont()
    love.graphics.setFont(self.font)
    local w, h = self.font:getWidth(self.text), self.font:getHeight()
    love.graphics.print(self.text, self.x - w/2, self.y - h/2)
    love.graphics.setFont(font)
end

return Instruction
