local _ = {}
local objects = {
    {name = 'Solid', type = 'Polyrect', color = {192, 64, 64}},
    -- {name = 'SolidPolygon', type = 'Polygon', color = {128, 128, 192}},
    {name = 'LevelTransition', type = 'Polyrect', color = {192, 128, 64}},
    {name = 'Script', type = 'Polyrect', color = {96, 192, 96}},
    {name = 'CameraLimit', type = 'Polyrect', color = {192, 96, 96}},
    {name = 'Link', type = 'Link', color = {244, 160, 244}},
    {name = 'Player', type = 'Object', image = 'resources/editor/player.png'},
    {name = 'Blaster', type = 'Object', image = 'resources/editor/blaster.png'},
    {name = 'SnowBoulder', type = 'Object', image = 'resources/editor/snow_boulder.png'},
    {name = 'SnowBlock1', type = 'Object', image = 'resources/editor/snow_block_1.png'},
    {name = 'SnowBlock2', type = 'Object', image = 'resources/editor/snow_block_2.png'},
    {name = 'SnowBlock3', type = 'Object', image = 'resources/editor/snow_block_3.png'},
    {name = 'CapsuleTerminal', type = 'Object', image = 'resources/editor/terminal.png'},
    {name = 'Grass1', type = 'Object', image = 'resources/editor/grass_1.png'},
    {name = 'Grass2', type = 'Object', image = 'resources/editor/grass_2.png'},
    {name = 'PlantSmall', type = 'Object', image = 'resources/editor/plant_small.png'},
    {name = 'PlantBig', type = 'Object', image = 'resources/editor/plant_big.png'},
    {name = 'StonePlant', type = 'Object', image = 'resources/editor/stone_plant.png'},
    {name = 'WallPlant1', type = 'Object', image = 'resources/editor/wall_plant_1.png'},
    {name = 'WallPlant2', type = 'Object', image = 'resources/editor/wall_plant_2.png'},
    {name = 'WallPlant3', type = 'Object', image = 'resources/editor/wall_plant_3.png'},
    {name = 'Vine1', type = 'Object', image = 'resources/editor/vine_1.png'},
    {name = 'Vine2', type = 'Object', image = 'resources/editor/vine_2.png'},
    {name = 'Vine3', type = 'Object', image = 'resources/editor/vine_3.png'},
    {name = 'Wire1', type = 'Object', image = 'resources/editor/wire_1.png'},
    {name = 'Wire2', type = 'Object', image = 'resources/editor/wire_2.png'},
}
for i, object in ipairs(objects) do _[i] = object end

return function(self)
    self.objects = {}
    for _, v in pairs(_) do table.insert(self.objects, {name = v.name, editor_type = v.type, image = v.image, color = v.color}) end
end

