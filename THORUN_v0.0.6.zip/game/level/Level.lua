 local EditorObject = require 'editor/EditorObject'
 local Level = fg.Object:extend('Level')

function Level:new(game, name, x, y)
    self.game = game
    self.name = name
    fg.world:createArea(name, x or 0, y or 0)

    local mx, my = game.tile_width, game.tile_height
    self.auto_collision_data = {}
    -- Snow tileset slopes
    self.auto_collision_data[109] = {
        default = {x0 = -16, y0 = 16, x1 = -16, y1 = -16, x2 = 16, y2 = -16, x3 = 16, y3 = 16},
        guards = {{up = 112, right = 110}, {up = 118, left = 120}},
        modifiers = {
            {x0 = -16, y0 = 16, x1 = -16, y1 = -16, x2 = 16, y2 = -13, x3 = 16, y3 = 16},
            {x0 = -16, y0 = 16, x1 = -16, y1 = -13, x2 = 16, y2 = -16, x3 = 16, y3 = 16},
        }
    }
    self.auto_collision_data[110] = {x0 = -16, y0 = 16, x1 = -16, y1 = -13, x2 = 16, y2 = 2, x3 = 16, y3 = 16}
    self.auto_collision_data[111] = {x0 = -16, y0 = 16, x1 = -16, y1 = 2, x2 = 16, y2 = 2, x3 = 16, y3 = 16}
    self.auto_collision_data[112] = {x0 = -16, y0 = 16, x1 = -16, y1 = 2, x2 = 16, y2 = 16, x3 = 16, y3 = 16}
    self.auto_collision_data[113] = {
        default = {x0 = -16, y0 = 16, x1 = -16, y1 = -16, x2 = 16, y2 = -16, x3 = 16, y3 = 16},
        guards = {{up = 112, right = 114}, {up = 118, left = 124}},
        modifiers = {
            {x0 = -16, y0 = 16, x1 = -16, y1 = -16, x2 = 16, y2 = -13, x3 = 16, y3 = 16},
            {x0 = -16, y0 = 16, x1 = -16, y1 = -13, x2 = 16, y2 = -16, x3 = 16, y3 = 16}, 
        }
    }
    self.auto_collision_data[114] = {x0 = -16, y0 = 16, x1 = -16, y1 = -16, x2 = 16, y2 = 2, x3 = 16, y3 = 16}
    self.auto_collision_data[115] = {x0 = -16, y0 = 16, x1 = -16, y1 = 2, x2 = 16, y2 = 2, x3 = 16, y3 = 16}
    self.auto_collision_data[116] = {x0 = -16, y0 = 16, x1 = -16, y1 = 2, x2 = 16, y2 = 16, x3 = 16, y3 = 16}
    self.auto_collision_data[118] = {x0 = -16, y0 = 16, x1 = -16, y1 = 16, x2 = 16, y2 = 2, x3 = 16, y3 = 16}
    self.auto_collision_data[119] = {x0 = -16, y0 = 16, x1 = -16, y1 = 2, x2 = 16, y2 = 2, x3 = 16, y3 = 16}
    self.auto_collision_data[120] = {x0 = -16, y0 = 16, x1 = -16, y1 = 2, x2 = 16, y2 = -13, x3 = 16, y3 = 16}
    self.auto_collision_data[121] = {x0 = -16, y0 = 16, x1 = -16, y1 = -13, x2 = 16, y2 = -13, x3 = 16, y3 = 16}
    self.auto_collision_data[122] = {x0 = -16, y0 = 16, x1 = -16, y1 = 16, x2 = 16, y2 = 2, x3 = 16, y3 = 16}
    self.auto_collision_data[123] = {x0 = -16, y0 = 16, x1 = -16, y1 = 2, x2 = 16, y2 = 2, x3 = 16, y3 = 16}
    self.auto_collision_data[124] = {x0 = -16, y0 = 16, x1 = -16, y1 = 2, x2 = 16, y2 = -13, x3 = 16, y3 = 16}
    self.auto_collision_data[125] = {x0 = -16, y0 = 16, x1 = -16, y1 = -13, x2 = 16, y2 = -13, x3 = 16, y3 = 16}

    local tilesets = {}
    for _, tileset in ipairs(self.game.tilesets) do table.insert(tilesets, love.graphics.newImage('resources/tilesets/' .. tileset .. '.png')) end
    local grid = {} for i = 1, 100 do grid[i] = {} for j = 1, 100 do grid[i][j] = 0 end end
    self.tilemaps = {}
    for _, layer in ipairs(self.game.layers) do
        self.tilemaps[layer] = fg.Tilemap(0, 0, self.game.tile_width, self.game.tile_height, tilesets, grid, {area = fg.world.areas[self.name]})
        fg.world:addToLayer(layer, self.tilemaps[layer])
    end

    self.last_loaded_map = nil
    self.last_editor_loaded_map = nil
end

function Level:update(dt)

end

function Level:draw()

end

function Level:activate()
    fg.world.areas[self.name]:activate()
end

function Level:deactivate()
    fg.world.areas[self.name]:deactivate()
end

function Level:postLoad()
    -- Set camera limits
    local camera_limits = fg.world.areas[self.name]:getEntitiesWhere(function() return true end, {'CameraLimit'})
    local left_top_x, left_top_y, bottom_right_x, bottom_right_y = nil, nil, nil, nil
    for _, cl in ipairs(camera_limits) do
        if cl.position == 'top-left' then left_top_x, left_top_y = cl.x, cl.y
        elseif cl.position == 'bottom-right' then bottom_right_x, bottom_right_y = cl.x, cl.y end
    end
    if left_top_x and left_top_y and bottom_right_x and bottom_right_y then 
        fg.world.camera:setBounds(left_top_x, left_top_y, bottom_right_x, bottom_right_y) 
    end
end

function Level:setBackground()
    fg.world.layers['Background_Middle']:removeObjects()
    fg.world.layers['Background_Back']:removeObjects()
end

function Level:changeLevelTo(map_name, delay)
    local transitions = {'rectangle', 'rotating rectangle', 'rectangle lr'}
    local transition = transitions[math.random(1, #transitions)]
    game:screenTransition(transition .. ' up', delay)
    fg.world:pause()
    fg.timer:after('transition_up', delay, function()
        game:changeLevelTo(map_name)
        game:screenTransition(transition .. ' down', delay)
        fg.timer:after('transition_down', delay, function()
            game.screen_transition = nil
            fg.world:unpause()
        end)
    end)
end

function Level:movePlayerToTransitionPosition(previous_area)
    -- Move player to correct position
    local player = nil
    local players = fg.world.areas[self.name]:getEntitiesWhere(function() return true end, {'Player'})
    if #players > 0 then player = players[1] end
    local transitions = fg.world.areas[fg.current_area]:getEntitiesBy('target_level', previous_area, {'LevelTransition'})
    -- Add solution for if there are multiple doors later
    local transition = nil
    if #transitions > 0 then transition = transitions[1] end
    if player then player.body:setPosition(transition.x - 64, transition.y) end
    fg.world.camera:moveTo(transition.x, transition.y)
end

function Level:saveFromGame(filename)
    -- Saves tilemaps
    local save_data = {}
    for _, l in ipairs(game.layers) do
        local tilemap = self.tilemaps[l]
        save_data[l] = {}
        save_data[l].tile_grid = fg.utils.table.copy(tilemap.tile_grid)
    end

    -- Saves objects
    save_data.objects = fg.Serial:saveArea(filename, fg.world.areas[self.name], nil, true)
    
    -- Save
    local save_string = fg.Serial.serialize(save_data)
    if not love.filesystem.write('maps/' .. filename, save_string) then
        error('Could not write ' .. filename .. ' while saving area ' .. self.name .. '.')
    end
end

function Level:saveFromEditor(additional_data, map_name)
    -- Saves tilemaps
    local save_data = {}
    for _, l in ipairs(game.layers) do
        local tilemap = self.tilemaps[l]
        save_data[l] = {}
        save_data[l].tile_grid = fg.utils.table.copy(tilemap.tile_grid)
    end

    -- Saves objects
    save_data.objects = {}
    for _, object in ipairs(additional_data) do
        table.insert(save_data.objects, object)
    end

    -- Save
    local save_string = fg.Serial.serialize(save_data)
    local file = nil
    if forwardslash then file = assert(io.open(cwd .. '/resources/maps/' .. map_name, 'w'))
    elseif backslash then file = assert(io.open(cwd .. '\\resources\\maps\\' .. map_name, 'w')) end
    file:write(save_string)
    file:close()

    self.last_editor_loaded_map = map_name
end

function Level:loadFromGame(map_name, previous_map, loading_order)
    local save_data = love.filesystem.load('maps/' .. map_name)()
    local save_data_previous = nil
    if previous_map then save_data_previous = love.filesystem.load('maps/' .. previous_map)() end
    
    -- Loads tilemaps
    for _, l in ipairs(game.layers) do
        local tilemap = self.tilemaps[l]
        for i = 1, #save_data[l].tile_grid do
            for j = 1, #save_data[l].tile_grid[i] do
                tilemap:removeTile(i, j)
            end
        end
        for i = 1, #save_data[l].tile_grid do
            for j = 1, #save_data[l].tile_grid[i] do
                tilemap:changeTile(i, j, save_data[l].tile_grid[i][j])
            end
        end
    end
    
    -- Load objects
    for _, object in ipairs(save_data.objects) do
        local settings = {}
        for k, v in pairs(object) do settings[k] = v end
        if object.class_name ~= 'Player' then
            fg.world.areas[self.name]:createEntity(object.class_name, object.x, object.y, settings)
        end
    end

    -- Load player
    if save_data_previous then  
        for _, object in ipairs(save_data_previous.objects) do
            local settings = {}
            for k, v in pairs(object) do settings[k] = v end
            if object.class_name == 'Player' then
                fg.world.areas[self.name]:createEntity(object.class_name, object.x, object.y, settings)
            end
        end
    end

    fg.world.areas[self.name]:update(0)

    -- Load scripts
    for _, object in ipairs(save_data.objects) do
        local settings = {}
        for k, v in pairs(object) do settings[k] = v end
        if object.class_name == 'Script' then
            fg.world.areas[self.name]:createEntity(object.class_name, object.x, object.y, settings)
        end
    end

    -- Post load settings
    self:postLoad()
end

function Level:loadToEditor(map_name)
    local save_data = love.filesystem.load('resources/maps/' .. map_name)()

    -- Loads tilemaps
    for _, l in ipairs(game.layers) do
        local tilemap = self.tilemaps[l]
        for i = 1, #save_data[l].tile_grid do
            for j = 1, #save_data[l].tile_grid[i] do
                tilemap:removeTile(i, j)
            end
        end
        for i = 1, #save_data[l].tile_grid do
            for j = 1, #save_data[l].tile_grid[i] do
                tilemap:changeTile(i, j, save_data[l].tile_grid[i][j])
            end
        end
    end

    -- Loads objects
    for _, object in ipairs(save_data.objects) do
        table.insert(editor.objects, EditorObject(editor, object.x, object.y, {name = object.name, type = object.type, color = object.color,
        id = object.id, image = object.image, active = true, r = object.r, properties = object.properties, w = object.w, h = object.h,
        z = object.z, target_id = object.target_id, source_id = object.source_id}))
    end

    -- Link
    for _, m in ipairs(editor.objects) do
        if m.type == 'Link' then
            for _, o in ipairs(editor.objects) do
                if o.id == m.target_id then m.target = o end
                if o.id == m.source_id then m.source = o end
            end
        end
    end

    self.last_editor_loaded_map = map_name
end

function Level:loadFromEditor(filename, previous_map)
    local save_data = love.filesystem.load('resources/maps/' .. filename)()
    local save_data_previous = nil
    if previous_map then save_data_previous = love.filesystem.load('maps/' .. previous_map)() end

    -- Loads tilemaps
    for _, l in ipairs(game.layers) do
        local tilemap = self.tilemaps[l]
        if tilemap then
            for i = 1, #save_data[l].tile_grid do
                for j = 1, #save_data[l].tile_grid[i] do
                    tilemap:removeTile(i, j)
                end
            end
            for i = 1, #save_data[l].tile_grid do
                for j = 1, #save_data[l].tile_grid[i] do
                    tilemap:changeTile(i, j, save_data[l].tile_grid[i][j])
                end
            end
            if l == 'Front_1' then
                tilemap:setCollisionData(tilemap.tile_grid)
                fg.world.areas[self.name]:generateCollisionSolids(tilemap, self.auto_collision_data)
            end
        end
    end

    -- Loads objects
    for _, object in ipairs(save_data.objects) do
        if not self.game.first_player or object.name ~= 'Player' then
            fg.world.areas[self.name]:createEntity(self:getObjectName(object.name), object.x, object.y, self:getObjectSettings(object))
        end
    end

    -- Load player
    if self.game.first_player and save_data_previous then
        for _, object in ipairs(save_data_previous.objects) do
            local settings = {}
            for k, v in pairs(object) do settings[k] = v end
            if object.class_name == 'Player' then
                fg.world.areas[self.name]:createEntity(object.class_name, object.x, object.y, settings)
            end
        end
    end

    fg.world.areas[self.name]:update(0)

    -- Load scripts
    for _, object in ipairs(save_data.objects) do
        if object.class_name == 'Script' then
            fg.world.areas[self.name]:createEntity(self:getObjectName(object.name), object.x, object.y, self:getObjectSettings(object))
        end
    end

    -- Post load settings
    self:postLoad()

    self.last_loaded_map = filename
end

function Level:getObjectSettings(object)
    if object.name == 'Player' then
        return {shape = 'BSGRectangle', w = 16, h = 28, s = 6}

    elseif object.name == 'Solid' then
        return {body_type = 'static', w = object.w, h = object.h}

    elseif object.name == 'SolidPolygon' then
        return {body_type = 'static', shape = 'polygon', vertices = object.vertices}

    elseif object.name == 'LevelTransition' then
        return {body_type = 'static', w = object.w, h = object.h, target_level = object.properties.target_level}

    elseif object.name == 'Script' then
        return {script_name = object.properties.script_name}

    elseif object.name == 'CameraLimit' then
        return {position = object.properties.position}

    -- SnowBlock
    elseif object.name == 'SnowBlock1' then
        return {block_id = 1}
    elseif object.name == 'SnowBlock2' then
        return {block_id = 2}
    elseif object.name == 'SnowBlock3' then
        return {block_id = 3}

    -- Grass
    elseif object.name == 'Grass1' then
        return {n = 0, r = object.r}
    elseif object.name == 'Grass2' then
        return {n = 1, r = object.r}

    -- Plant
    elseif object.name == 'PlantSmall' then
        return {n = 0, r = object.r}
    elseif object.name == 'PlantBig' then
        return {n = 1, r = object.r}

    -- WallPlant
    elseif object.name == 'WallPlant1' then
        return {n = 1, r = object.r}
    elseif object.name == 'WallPlant2' then
        return {n = 2, r = object.r}
    elseif object.name == 'WallPlant3' then
        return {n = 3, r = object.r}
    
    -- Vine
    elseif object.name == 'Vine1' then
        return {n = 0, r = object.r}
    elseif object.name == 'Vine2' then
        return {n = 1, r = object.r}
    elseif object.name == 'Vine3' then
        return {n = 2, r = object.r}

    -- Wire
    elseif object.name == 'Wire1' then
        return {n = 1, r = object.r}
    elseif object.name == 'Wire2' then
        return {n = 2, r = object.r}

    -- StonePlant
    elseif object.name == 'StonePlant' then
        return {r = object.r}

    end
end

function Level:getObjectName(name)
    if fg.fn.any({'Grass1', 'Grass2'}, name) then return 'Grass'
    elseif fg.fn.any({'PlantSmall', 'PlantBig'}, name) then return 'Plant'
    elseif fg.fn.any({'WallPlant1', 'WallPlant2', 'WallPlant3'}, name) then return 'WallPlant'
    elseif fg.fn.any({'Vine1', 'Vine2', 'Vine3'}, name) then return 'Vine'
    elseif fg.fn.any({'Wire1', 'Wire2'}, name) then return 'Wire'
    elseif fg.fn.any({'SnowBlock1', 'SnowBlock2', 'SnowBlock3'}, name) then return 'SnowBlock'
    else return name end
end

return Level
