local Animated = fg.Object:extend('Animated')

function Animated:animatedNew(settings)
    local settings = settings or {}

    self.animation_state = settings.settings.animation_state or 'idle'
    self.animation_flip = settings.settings.animation_flip or 1
    self.animations = {}
    for _, anim in ipairs(settings.animations) do
        self.animations[anim.state] = {animation = self.fg.Animation(self.fg.Assets[anim.image], 
                                       anim.size[1], anim.size[2], anim.delay), 
                                       x_offset = anim.offset[1] or 0, y_offset = anim.offset[2] or 0}
        self.animations[anim.state].animation:setMode(anim.mode)
    end
end

function Animated:animatedUpdate(dt)
    self.animations[self.animation_state].animation:update(dt)
    if self.direction == 'left' then self.animation_flip = -1
    elseif self.direction == 'right' then  self.animation_flip = 1 end
end

function Animated:animatedDraw()
    local animation = self.animations[self.animation_state]
    animation.animation:draw(self.x, self.y, self.r or 0, self.animation_flip*(self.sx or 1), (self.sy or 1), -animation.x_offset, -animation.y_offset)
end

function Animated:setAnimationState(state)
    for k, v in pairs(self.animations) do self[k] = false end
    if state then self[state] = true end
end

function Animated:playAnimation(animation_name, action)
    self:setAnimationState(animation_name)
    local animation = self.animations[animation_name].animation
    animation:reset()
    animation:play()
    self.timer:after(animation_name, animation.delay*animation.size, function()
        animation:reset()
        self[animation_name] = false
        if action then action() end
    end)
end

function Animated:animatedSave()
    return {animation_state = self.animation_state, animation_flip = self.animation_flip}
end

return Animated
