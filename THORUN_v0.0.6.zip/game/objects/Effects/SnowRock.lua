local SnowRock = fg.Class('SnowRock', 'Entity')
SnowRock:implement(fg.PhysicsBody)

SnowRock.layer = 'Effects'

SnowRock.ignores = {'All', except = {'Solid'}}
SnowRock.enter = {'Solid'}

function SnowRock:new(area, x, y, settings)
    local settings = settings or {}
    SnowRock.super.new(self, area, x, y, settings)
    if self.fg.fn.any({'16L1', '16R1'}, self.size_id) then settings.w, settings.h = 12, 12
    elseif self.fg.fn.any({'16L2', '16R2'}, self.size_id) then settings.w, settings.h = 10, 10
    elseif self.fg.fn.any({'8L', '8R'}, self.size_id) then settings.w, settings.h = 8, 8
    elseif self.fg.fn.any({'4L', '4R', '2L', '2R'}, self.size_id) then settings.w, settings.h = 2, 2 end
    self:physicsBodyNew(area, x, y, settings)
    self.body:setFixedRotation(false)
    local v = 0
    if self.fg.fn.any({'16L1', '16R1'}, self.size_id) then v = self.fg.utils.math.random(100, 150)
    elseif self.fg.fn.any({'16L2', '16R2'}, self.size_id) then v = self.fg.utils.math.random(75, 125)
    elseif self.fg.fn.any({'8L', '8R'}, self.size_id) then v = self.fg.utils.math.random(50, 100)
    elseif self.fg.fn.any({'4L', '4R', '2L', '2R'}, self.size_id) then v = self.fg.utils.math.random(25, 75) end
    local angle = self.fg.utils.math.random(settings.angle_min or -3*math.pi/4, settings.angle_max or -math.pi/4)
    self.body:setLinearVelocity(v*math.cos(angle), v*math.sin(angle))
    self.body:applyTorque(self.fg.utils.math.random(-8*math.pi, 8*math.pi))

    self.snow_breakable_visual = self.fg.Assets.snow_breakable
    local w, h = self.snow_breakable_visual:getWidth(), self.snow_breakable_visual:getHeight()
    self.snow_rock_16L1 = love.graphics.newQuad(48, 0, 16, 16, w, h)
    self.snow_rock_16R1 = love.graphics.newQuad(64, 0, 16, 16, w, h)
    self.snow_rock_16L2 = love.graphics.newQuad(48, 16, 16, 16, w, h)
    self.snow_rock_16R2 = love.graphics.newQuad(64, 16, 16, 16, w, h)
    self.snow_rock_8L = love.graphics.newQuad(48, 32, 16, 16, w, h)
    self.snow_rock_8R = love.graphics.newQuad(64, 32, 16, 16, w, h)
    self.snow_rock_4L = love.graphics.newQuad(32, 0, 8, 8, w, h)
    self.snow_rock_4R = love.graphics.newQuad(40, 0, 8, 8, w, h)
    self.snow_rock_2L = love.graphics.newQuad(32, 8, 8, 8, w, h)
    self.snow_rock_2R = love.graphics.newQuad(40, 8, 8, 8, w, h)
    self.snow_rock_id = 'snow_rock_' .. self.size_id
end

function SnowRock:update(dt)
    self:physicsBodyUpdate(dt)
    self.r = self.body:getAngle()
end

function SnowRock:draw()
    self:physicsBodyDraw()
    local w, h = 0, 0
    if self.fg.fn.any({'16L1', '16R1', '16L2', '16R2', '8L', '8R'}, self.size_id) then w, h = 16, 16
    elseif self.fg.fn.any({'4L', '4R', '2L', '2R'}, self.size_id) then w, h = 8, 8 end
    love.graphics.draw(self.snow_breakable_visual, self[self.snow_rock_id], self.x, self.y, self.r, self.sx, self.sy, w/2, h/2)
end

function SnowRock:onCollisionEnter(other, contact)
    if other.tag == 'Solid' then
        self.dead = true
        for i = 1, 2 do
            if self.fg.fn.any({'16L1', '16R1'}, self.size_id) then self.area:createEntity('SnowRock', self.x, self.y, {size_id = self.fg.utils.table.random({'16L2', '16R2'})})
            elseif self.fg.fn.any({'16L2', '16R2'}, self.size_id) then self.area:createEntity('SnowRock', self.x, self.y, {size_id = self.fg.utils.table.random({'8L', '8R'})})
            elseif self.fg.fn.any({'8L', '8R'}, self.size_id) then self.area:createEntity('SnowRock', self.x, self.y, {size_id = self.fg.utils.table.random({'4L', '4R'})})
            elseif self.fg.fn.any({'4L', '4R'}, self.size_id) then self.area:createEntity('SnowRock', self.x, self.y, {size_id = self.fg.utils.table.random({'2L', '2R'})}) end
        end
    end
end

function SnowRock:save()
    local save_data = {}
    save_data.size_id = self.size_id
    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y
    save_data.w, save_data.h = self.w, self.h
    save_data.shape = 'Rectangle'
    return save_data
end

return SnowRock
