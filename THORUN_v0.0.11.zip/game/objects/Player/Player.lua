local Player = fg.Class('Player', 'Entity')
Player:implement(fg.PhysicsBody)
Player:implement(Animated)
Player:implement(PersonJump)
Player:implement(PersonMovement)
Player:implement(MeleeAttack)
Player:implement(PlayerEffects)
Player:implement(Interaction)

Player.enter = {'LevelTransition', 'Solid'}

local melee_attack_keys = {
    {'j', 'lightAttack'}, {'k', 'heavyAttack'},
    {'fleft', 'lightAttack'}, {'fright', 'heavyAttack'},
    {'s', 'down'}, {'dpdown', 'down'},
}

function Player:new(area, x, y, settings)
    Player.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    self:physicsBodyNew(area, x, y, settings)
    self.fixture:setRestitution(0)
    self:personMovementNew({keys = {{'a', 'moveLeft'}, {'d', 'moveRight'}, {'dpleft', 'moveLeft'}, {'dpright', 'moveRight'}}, settings = settings})
    self:personJumpNew({keys = {{' ', 'jump'}, {'w', 'jump'}, {'fdown', 'jump'}}, settings = settings})
    self:animatedNew({animations = self.fg.player_animations, settings = settings})
    self:meleeAttackNew({keys = melee_attack_keys, settings = settings})
    self:playerEffectsNew({settings = settings})
    self:interactionNew({interactable_objects = {'CapsuleTerminal'}})

    fg.world.camera:follow(self, {lerp = 2})
end

function Player:update(dt)
    self.timer:update(dt)
    self:physicsBodyUpdate(dt)
    self:personJumpUpdate(dt)
    self:personMovementUpdate(dt)
    self:meleeAttackUpdate(dt)
    self:playerEffectsUpdate(dt)
    self:interactionUpdate(dt)

    -- Animation
    self:animatedUpdate(dt)
    local vx, vy = self.body:getLinearVelocity()
    if math.abs(vx) <= 5 and math.abs(vy) <= 5 then self.animation_state = 'idle' end
    if math.abs(vx) >= 5 or math.abs(vy) >= 5 then self.animation_state = 'run' end
    if vy <= -5 and not self.on_ground then self.animation_state = 'jump' end
    if (vy > 0 and not self.on_ground) or self.wall_sliding then self.animation_state = 'fall' end
    if self.attack_1 then self.animation_state = 'attack_1' end
    if self.attack_2 then self.animation_state = 'attack_2' end
    if self.attack_3 then self.animation_state = 'attack_3' end
end

function Player:draw()
    self:physicsBodyDraw()
    self:animatedDraw()
    self:interactionDraw()
end

function Player:onCollisionEnter(other, contact)
    if other.tag == 'LevelTransition' then
        game.levels[self.area.name]:changeLevelTo(other.object.target_level, 0.5)
    end
    self:jumpOnCollisionEnter(other, contact)
    self:meleeAttackOnCollisionEnter(other, contact)
end

function Player:save()
    local animated = self:animatedSave()
    local person_movement = self:personMovementSave()
    local person_jump = self:personJumpSave()
    local save_data = {}
    for k, v in pairs(person_movement) do save_data[k] = v end
    for k, v in pairs(person_jump) do save_data[k] = v end
    for k, v in pairs(animated) do save_data[k] = v end
    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y
    save_data.w, save_data.h = self.w, self.h
    save_data.shape = 'BSGRectangle'
    save_data.s = self.s
    return save_data
end

return Player
