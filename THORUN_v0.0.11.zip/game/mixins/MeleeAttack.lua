local MeleeAttack = fg.Object:extend('MeleeAttack')

local lock_targets = {'Blaster', 'SnowBoulder', 'SnowBlock'}

function MeleeAttack:meleeAttackNew(settings)
    local settings = settings or {}

    for _, key_action in ipairs(settings.keys) do self.fg.input:bind(key_action[1], key_action[2]) end
    self.melee_attack_closest_entity = nil
    self.melee_attack_locked = false
    self.melee_attack_hit_locked = false
    self.melee_attack_movement_locked = false
    self.melee_attack_lock_radius = settings.settings.melee_attack_lock_radius or 150
    self.melee_attack_new_p = nil
    self.attack_1 = settings.settings.attack_1 or false
    self.attack_2 = settings.settings.attack_2 or false
    self.attack_3 = settings.settings.attack_3 or false
    self.last_attack_type = nil
    self.post_attack_duration = 0.5
    self.disengage_cooldown = 3
    self.can_disengage = true
    self.disengage_timer = 0
    self.disengaging = false
end

function MeleeAttack:meleeAttackUpdate(dt)
    -- Lock logic
    local entities = self.fg.fn.select(self.area:queryAreaCircle(self.x, self.y, self.melee_attack_lock_radius, lock_targets),
    function(k, v) if v.id ~= self.id and not v.dying then return true end end)
    if #entities == 0 or (#entities == 1 and entities[1].dying) then self.melee_attack_closest_entity = nil end
    -- Sort entities based on proximity to player
    table.sort(entities, function(a, b)
        local x1, y1 = a.body:getPosition()
        local x2, y2 = b.body:getPosition()
        local d1 = math.sqrt((self.x - x1)*(self.x - x1) + (self.y - y1)*(self.y - y1))
        local d2 = math.sqrt((self.x - x2)*(self.x - x2) + (self.y - y2)*(self.y - y2))
        if d1 < d2 then return true end
    end)

    self.melee_attack_closest_entity = entities[1]

    -- Set melee attack_locked
    if self.melee_attack_locked and not self.melee_attack_closest_entity then self.melee_attack_locked = false
    elseif not self.melee_attack_locked and self.melee_attack_closest_entity then self.melee_attack_locked = true end

    -- Set camera follow
    if self.melee_attack_closest_entity then
        self.fg.world.camera:follow({x = (self.x + self.melee_attack_closest_entity.x)/2, y = (self.y + self.melee_attack_closest_entity.y)/2}, {follow_style = 'lockon', lerp = 20})
    else self.fg.world.camera:follow(self, {follow_style = 'lockon', lerp = 10}) end

    -- Attack logic
    if self.melee_attack_closest_entity then
        local attack_type = nil
        if self.fg.input:pressed('lightAttack') then attack_type = 'light' end
        if self.fg.input:pressed('heavyAttack') then attack_type = 'heavy' end

        -- If attack pressed...
        if attack_type then
            -- First attack
            if not self.melee_attack_hit_locked then
                -- Reset velocity
                self.v.x, self.v.y = 0, 0
                self.body:setLinearVelocity(self.v.x, self.v.y)
                self.melee_attack_hit_locked = true
                self.melee_attack_movement_locked = true
                -- Tween to new position
                self.melee_attack_new_p = self.fg.Vector(self.x, self.y)
                local angle = 0
                local direction = self.fg.utils.angleToDirection2(self.fg.Vector(self.x, self.y):angleTo(self.fg.Vector(self.melee_attack_closest_entity.x, self.melee_attack_closest_entity.y)))
                if direction == 'left' then angle = math.pi; self.direction = 'right' else self.direction = 'left' end
                self.timer:tween(0.06, self.melee_attack_new_p, {x = self.melee_attack_closest_entity.x + 30*math.cos(angle), y = self.melee_attack_closest_entity.y + 0.1}, 'linear')
                self.timer:after(0.08, function() 
                    self:meleeAttack(attack_type) 
                    self.melee_attack_hit_locked = false
                end)
            -- Not first attack, just attack
            else self:meleeAttack(attack_type) end
        end
    end

    -- Fix player's position if he has started attack on enemy
    if self.melee_attack_hit_locked then self.body:setPosition(self.melee_attack_new_p.x, self.melee_attack_new_p.y) end

    -- Gravity
    if self.melee_attack_movement_locked then self.body:setGravityScale(0) end

    -- Disengage logic
    self.disengage_timer = self.disengage_timer + dt
    if self.disengage_timer >= self.disengage_cooldown then self.disengage_timer = 0; self.can_disengage = true end
    if self.fg.input:pressed('down') and self.can_disengage then
        self:setAnimationState()
        self.timer:cancel('post_attack_duration')
        self.body:applyLinearImpulse(0, 1000)
        self.melee_attack_movement_locked = true
        self.disengage_timer = 0
        self.can_disengage = false
        self.disengaging = true
    end
end

function MeleeAttack:meleeAttackDraw()

end

function MeleeAttack:meleeAttack()
    local object = self.melee_attack_closest_entity
    if not object then return end
    local random = self.fg.utils.math.random
    local dx, dy = object.x - self.x, object.y - self.y
    if dx < 0 then dx = -1 else dx = 1 end
    if dy < 0 then dy = -1 else dy = 1 end

    -- Animation
    if attack_type == 'light' then
        local attacks = {'light_attack_1', 'light_attack_2', 'light_attack_3', 'light_attack_4', 'light_attack_5'}
        attack_type = attacks[math.random(1, #attacks)]
        while attack_type == self.last_attack_type do attack_type = attacks[math.random(1, #attacks)] end
        self.last_attack_type = attack_type
        self:setAnimationState(attack_type)
        self.timer:after(attack_type, self.post_attack_duration, function() self[attack_type] = false end)
    else self:playAnimation('heavy_attack') end

    -- Lock, attack
    self.melee_attack_closest_entity:hitATK(self, attack_type) 
    if self.melee_attack_closest_entity.dying or self.melee_attack_closest_entity.dead then
        self.body:applyLinearImpulse(0, -55)
        self.melee_attack_movement_locked = false
        self[attack_type] = false
    end
    self.timer:after('post_attack_duration', self.post_attack_duration, function() 
        self.body:applyLinearImpulse(0, -55)
        self.melee_attack_movement_locked = false
    end)

    -- Juice
    self.sx, self.sy = self.fg.utils.math.random(1.02, 1.1), self.fg.utils.math.random(1.02, 1.1)
    local r = self.fg.utils.math.random(0.1, 0.6)
    self.timer:tween('hit_scale_tween', r, self, {sx = 1, sy = 1}, 'in-out-cubic')
    self.timer:after('hit_scale_after', r, function() self.sx = 1; self.sy = 1 end)
end

function MeleeAttack:meleeAttackOnCollisionEnter(other, contact)
    if other.tag == 'Solid' then
        -- Disengage logic
        if self.disengaging then
            if self.fg.input:down('moveLeft') then
                self.push_v.x = -300
                self.timer:after('disengage_left', 0.3, function() 
                    self.push_v.x = 0 
                    self.melee_attack_movement_locked = false
                    self.disengaging = false
                end)
            elseif self.fg.input:down('moveRight') then
                self.push_v.x = 300
                self.timer:after('disengage_right', 0.3, function() 
                    self.push_v.x = 0 
                    self.melee_attack_movement_locked = false
                    self.disengaging = false
                end)
            else
                self.disengaging = false
                self.melee_attack_movement_locked = false
            end
        end
    end
end

function MeleeAttack:meleeAttackSave()
    return {melee_attack_lock_radius = self.melee_attack_lock_radius, light_attack = self.light_attack, heavy_attack = self.heavy_attack,
            light_attack_1 = self.light_attack_1, light_attack_2 = self.light_attack_2, light_attack_3 = self.light_attack_3, 
            light_attack_4 = self.light_attack_4, light_attack_5 = self.light_attack_5, last_attack_type = self.last_attack_type,
            post_attack_duration = self.post_attack_duration, disengage_cooldown = self.disengage_cooldown}
end

return MeleeAttack
