local AttentionCircle = fg.Class('AttentionCircle', 'Entity')

AttentionCircle.layer = 'Effects'

function AttentionCircle:new(area, x, y, settings)
    local settings = settings or {}
    AttentionCircle.super.new(self, area, x, y, settings)

    self.timer = self.fg.Timer()
    self.r = 0
    self.alpha = 255
    self.timer:tween('radius', 0.35, self, {r = 25}, 'in-out-cubic')
    self.timer:tween('alpha', 0.35, self, {alpha = 0}, 'linear', function() self.dead = true end)
end

function AttentionCircle:update(dt)
    self.timer:update(dt)
end

function AttentionCircle:draw()
    love.graphics.setColor(255, 255, 255, 255)
    love.graphics.circle('line', self.x, self.y, self.r)
end

return AttentionCircle
