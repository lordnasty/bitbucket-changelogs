local Table = fg.Class('Table', 'Entity')
Table:implement(fg.PhysicsBody)
Table:implement(Pseudo3D)

function Table:new(area, x, y, settings)
    local settings = settings or {}
    self.direction = settings.direction or 'horizontal'
    settings.body_type = 'static'
    Table.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    if self.direction == 'vertical' then
        settings.w, settings.h = 32, 48
        self.sort_y = -24
        self.table_quad = love.graphics.newQuad(0, 0, 32, 64, 64, 64)
        self.table_shadow = love.graphics.newQuad(32, 0, 32, 64, 64, 64)
        self.table_visual = self.fg.Assets.table_vertical
    elseif self.direction == 'horizontal' then
        settings.w, settings.h = 64, 20
        self.sort_y = -10
        self.table_quad = love.graphics.newQuad(0, 0, 64, 32, 128, 32)
        self.table_shadow = love.graphics.newQuad(64, 0, 64, 32, 128, 32)
        self.table_visual = self.fg.Assets.table_horizontal
    end
    self:physicsBodyNew(area, x, y, settings)
    self:pseudo3DNew({height_z = 10, stand = true, stand_z = 10, settings = settings})
end

function Table:update(dt)
    self.timer:update(dt)
    self:physicsBodyUpdate(dt)
    self:pseudo3DUpdate(dt)
end

function Table:draw()
    local w, h = 0, 0
    if self.direction == 'vertical' then w, h = 32, 64
    elseif self.direction == 'horizontal' then w, h = 64, 32 end
    -- Shadow
    love.graphics.setColor(255, 255, 255, 128)
    love.graphics.draw(self.table_visual, self.table_shadow, math.floor(self.x - w/2), math.floor(self.y - h/2 - 4))
    love.graphics.setColor(255, 255, 255, 255)
    -- Table
    love.graphics.draw(self.table_visual, self.table_quad, math.floor(self.x - w/2), math.floor(self.y - h/2 - 4))
    self:physicsBodyDraw()
    self:pseudo3DDraw()
end

function Table:highlightDraw()
    local w, h = 0, 0
    if self.direction == 'vertical' then w, h = 32, 64
    elseif self.direction == 'horizontal' then w, h = 64, 32 end
    love.graphics.draw(self.table_visual, self.table_quad, self.x - w/2, self.y - h/2 - 4)
end

function Table:save()
    local pseudo_3d = self:pseudo3DSave()
    local save_data = {}
    for k, v in pairs(pseudo_3d) do save_data[k] = v end
    save_data.direction = self.direction
    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y
    save_data.w, save_data.h = self.w, self.h
    save_data.shape = 'Rectangle'
    return save_data
end

return Table
