v0.1.0

## CHANGELOG

### v0.1.0

>**Fixes most issues brought up since the first release**

[**afafc9d**](https://github.com/adonaac/popo/commit/afafc9d0c5cb23d03340176f6f111616cf6b0a10) (**2015-03-10 07:08:38**)

#### Additions

* Added options for changing fonts mid text (bold, italic, ...) - [24e6936](https://github.com/adonaac/popo/commit/24e69368a9ad1cb8e869b58e76a91b77295ba4fb) (2015-03-10 04:56:49)
* Added align right, center and justify - [88cd9dc](https://github.com/adonaac/popo/commit/88cd9dca1305d922c9e4cb5aa3cd6089b1ebed81) (2015-03-10 06:57:06)

#### Fixes

* Fixed some wrapping alignment issues - [6c7352d](https://github.com/adonaac/popo/commit/6c7352dc16259af5f535cbeea0e2479bea99186c) (2015-03-10 00:44:04)
* Fixed blurred character drawing - [6c7352d](https://github.com/adonaac/popo/commit/6c7352dc16259af5f535cbeea0e2479bea99186c) (2015-03-10 00:44:04)

#### Updates

* Changed wrapping to only wrap on spaces between words - [b2f6ce8](https://github.com/adonaac/popo/commit/b2f6ce825b1e3c65b0afbc17b121d17daec4af98) (2015-03-10 02:39:45)

---

### v0.0.3

#### Additions

* Added align right, center and justify - [88cd9dc](https://github.com/adonaac/popo/commit/88cd9dca1305d922c9e4cb5aa3cd6089b1ebed81) (2015-03-10 06:57:06)

---

### v0.0.2

#### Additions

* Added options for changing fonts mid text (bold, italic, ...) - [24e6936](https://github.com/adonaac/popo/commit/24e69368a9ad1cb8e869b58e76a91b77295ba4fb) (2015-03-10 04:56:49)

---

### v0.0.1


#### Fixes

* Fixed some wrapping alignment issues - [6c7352d](https://github.com/adonaac/popo/commit/6c7352dc16259af5f535cbeea0e2479bea99186c) (2015-03-10 00:44:04)
* Fixed blurred character drawing - [6c7352d](https://github.com/adonaac/popo/commit/6c7352dc16259af5f535cbeea0e2479bea99186c) (2015-03-10 00:44:04)

#### Updates

* Changed wrapping to only wrap on spaces between words - [b2f6ce8](https://github.com/adonaac/popo/commit/b2f6ce825b1e3c65b0afbc17b121d17daec4af98) (2015-03-10 02:39:45)

---

