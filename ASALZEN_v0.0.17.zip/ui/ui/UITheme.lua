local Theme = {}

local makeStar = function(x, y, outer_radius, inner_radius)
    local vertices = {}
    for i = 1, 10 do
        local radius
        if i % 2 == 0 then radius = outer_radius else radius = inner_radius end
        table.insert(vertices, x + radius*math.cos(math.pi/2 - math.pi/10 + (i-1)*math.pi/5))
        table.insert(vertices, y + radius*math.sin(math.pi/2 - math.pi/10 + (i-1)*math.pi/5))
    end
    return vertices
end

Theme.Button = {}
Theme.Button.new = function(self)
    self.timer = fg.Timer()
    self.star_r = 0
    self.star_ar = 0
end

Theme.Button.update = function(self, dt)
    self.timer:update(dt)
    if self.selected_enter then
        self.timer:tween('star_r', 0.5, self, {star_ar = fg.utils.math.random(2*math.pi, 3*math.pi)}, 'in-out-cubic')
    elseif self.selected_exit then
        self.timer:tween('star_r', 1, self, {star_ar = 0}, 'in-out-cubic')
    end
    self.star_r = self.star_r + self.star_ar*dt
end

Theme.Button.draw = function(self)
    fg.utils.graphics.pushRotate(self.x + self.w/2, self.y + self.h/2, -math.pi/24)
    love.graphics.setColor(unpack(UI.colors[self.color]))
    love.graphics.rectangle('fill', self.x + 5*fg.screen_scale, self.y + 5*fg.screen_scale, self.w, self.h)

    love.graphics.setColor(unpack(UI.colors.bg))
    love.graphics.rectangle('fill', self.x, self.y, self.w, self.h)

    love.graphics.setColor(unpack(UI.colors[self.color]))
    love.graphics.setFont(self.font)
    love.graphics.print(self.text, self.x + self.w - 35*fg.screen_scale - self.fs*self.font:getWidth(self.text), self.y + self.h/2, 0, self.fs, self.fs, 0, self.font:getHeight()/2)
    love.graphics.setColor(unpack(UI.colors[self.color]))

    fg.utils.graphics.pushRotate(self.x + self.w - 18*fg.screen_scale, self.y + self.h/2, self.star_r)
    love.graphics.polygon('fill', unpack(makeStar(self.x + self.w - 18*fg.screen_scale, self.y + self.h/2, 10*fg.screen_scale, 5*fg.screen_scale)))
    love.graphics.pop()

    love.graphics.pop()
end

return Theme
