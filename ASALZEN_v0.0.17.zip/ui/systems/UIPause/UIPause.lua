local UIPause = fg.Object:extend('UIPause')
local UIButton = require 'ui/ui/UIButton'

function UIPause:UIPauseNew(settings)
    local settings = settings or {}
    fg.input:bind('escape', 'pause')
    fg.input:bind('start', 'pause')
    fg.input:bind('up', 'ui_pause_up')
    fg.input:bind('down', 'ui_pause_down')
    fg.input:bind('w', 'ui_pause_up')
    fg.input:bind('s', 'ui_pause_down')
    fg.input:bind('dpup', 'ui_pause_up')
    fg.input:bind('dpdown', 'ui_pause_down')
    fg.input:bind('lefty', 'ui_pause_vertical')

    self.paused = false
    self.pausing = false
    self.selection_list = {'status', 'party', 'item', 'system', 'exit'}
    self.selected_index = 1
    self.select_timer = 0
    self.can_select = true

    self.right_bg_tweening = false
    self.right_bg = {x = 600*fg.screen_scale, y = -400*fg.screen_scale, w = 1000*fg.screen_scale, h = 1000*fg.screen_scale}

    self.left_bg_tweening = false
    self.left_bg = {x = -450*fg.screen_scale, y = -50*fg.screen_scale, w = 375*fg.screen_scale, h = 600*fg.screen_scale}

    self.shadow_shader = love.graphics.newShader('resources/shaders/default.vert', 'resources/shaders/flat_colors.frag')
    self.portrait_s = {x = fg.screen_width, y = 0}

    self.status_b_selected = false
    self.status_b_tweening = false
    self.status_b = UIButton(-500*fg.screen_scale, 80*fg.screen_scale, 100*fg.screen_scale, 40*fg.screen_scale, {text = 'status', font = fg.Fonts.helsinki, color = 'blue'})

    self.party_b_selected = false
    self.party_b_tweening = false
    self.party_b = UIButton(-500*fg.screen_scale, 140*fg.screen_scale, 100*fg.screen_scale, 40*fg.screen_scale, {text = 'party', font = fg.Fonts.helsinki, color = 'green'})

    self.item_b_selected = false
    self.item_b_tweening = false
    self.item_b = UIButton(-500*fg.screen_scale, 200*fg.screen_scale, 100*fg.screen_scale, 40*fg.screen_scale, {text = 'item', font = fg.Fonts.helsinki, color = 'violet'})

    self.system_b_selected = false
    self.system_b_tweening = false
    self.system_b = UIButton(-500*fg.screen_scale, 260*fg.screen_scale, 100*fg.screen_scale, 40*fg.screen_scale, {text = 'system', font = fg.Fonts.helsinki, color = 'pink'})

    self.exit_b_selected = false
    self.exit_b_tweening = false
    self.exit_b = UIButton(-500*fg.screen_scale, 320*fg.screen_scale, 100*fg.screen_scale, 40*fg.screen_scale, {text = 'exit', font = fg.Fonts.helsinki, color = 'red'})
end

function UIPause:UIPauseUpdate(dt)
    if fg.input:pressed('pause') and not self.pausing then
        if self.paused then self:unpause()
        elseif not self.paused then self:pause() end
    end

    if self.paused then
        if fg.input:down('ui_pause_up') and self.select_timer > 0.15 then 
            self:selectPrevious() 
            self.select_timer = 0
        end

        if fg.input:down('ui_pause_down') and self.select_timer > 0.15 then 
            self:selectNext() 
            self.select_timer = 0
        end

        local y = fg.input:down('ui_pause_vertical')
        if y then
            if y <= -0.5 and self.select_timer > 0.15 then 
                self:selectPrevious() 
                self.select_timer = 0
            end 
            if y >= 0.5 and self.select_timer > 0.15 then 
                self:selectNext() 
                self.select_timer = 0
            end 
        end

        self.select_timer = self.select_timer + dt
        self:setSelection()
    end

    self.status_b:update(dt)
    if not self.status_b_selected then self.status_b.button.y = 80*fg.screen_height/fg.min_height end
    self.status_b.button.h = 40*fg.screen_height/fg.min_height
    if self.status_b.button.selected_enter then
        self.status_b_selected = true
        self.timer:tween('status_b_select_tween', 0.2, self.status_b.button, {x = self.status_b.button.x + 50*fg.screen_scale*math.cos(math.pi/24), 
                         y = self.status_b.button.y - 50*fg.screen_scale*math.sin(math.pi/24)}, 'in-out-cubic')
    end
    if self.status_b.button.selected_exit then
        self.timer:tween('status_b_select_tween', 0.2, self.status_b.button, {x = self.status_b.button.x - 50*fg.screen_scale*math.cos(math.pi/24),
                         y = self.status_b.button.y + 50*fg.screen_scale*math.sin(math.pi/24)}, 'in-out-cubic', function() self.status_b_selected = false end)
    end

    self.party_b:update(dt)
    if not self.party_b_selected then self.party_b.button.y = 140*fg.screen_height/fg.min_height end
    self.party_b.button.h = 40*fg.screen_height/fg.min_height
    if self.party_b.button.selected_enter then
        self.party_b_selected = true
        self.timer:tween('party_b_select_tween', 0.2, self.party_b.button, {x = self.party_b.button.x + 70*fg.screen_scale*math.cos(math.pi/24), 
                         y = self.party_b.button.y - 70*fg.screen_scale*math.sin(math.pi/24)}, 'in-out-cubic')
    end
    if self.party_b.button.selected_exit then
        self.timer:tween('party_b_select_tween', 0.2, self.party_b.button, {x = self.party_b.button.x - 70*fg.screen_scale*math.cos(math.pi/24),
                         y = self.party_b.button.y + 70*fg.screen_scale*math.sin(math.pi/24)}, 'in-out-cubic', function() self.party_b_selected = false end)
    end

    self.item_b:update(dt)
    if not self.item_b_selected then self.item_b.button.y = 200*fg.screen_height/fg.min_height end
    self.item_b.button.h = 40*fg.screen_height/fg.min_height
    if self.item_b.button.selected_enter then
        self.item_b_selected = true
        self.timer:tween('item_b_select_tween', 0.2, self.item_b.button, {x = self.item_b.button.x + 95*fg.screen_scale*math.cos(math.pi/24), 
                         y = self.item_b.button.y - 95*fg.screen_scale*math.sin(math.pi/24)}, 'in-out-cubic')
    end
    if self.item_b.button.selected_exit then
        self.timer:tween('item_b_select_tween', 0.2, self.item_b.button, {x = self.item_b.button.x - 95*fg.screen_scale*math.cos(math.pi/24),
                         y = self.item_b.button.y + 95*fg.screen_scale*math.sin(math.pi/24)}, 'in-out-cubic', function() self.item_b_selected = false end)
    end

    self.system_b:update(dt)
    if not self.system_b_selected then self.system_b.button.y = 260*fg.screen_height/fg.min_height end
    self.system_b.button.h = 40*fg.screen_height/fg.min_height
    if self.system_b.button.selected_enter then
        self.system_b_selected = true
        self.timer:tween('system_b_select_tween', 0.2, self.system_b.button, {x = self.system_b.button.x + 80*fg.screen_scale*math.cos(math.pi/24), 
                         y = self.system_b.button.y - 80*fg.screen_scale*math.sin(math.pi/24)}, 'in-out-cubic')
    end
    if self.system_b.button.selected_exit then
        self.timer:tween('system_b_select_tween', 0.2, self.system_b.button, {x = self.system_b.button.x - 80*fg.screen_scale*math.cos(math.pi/24),
                         y = self.system_b.button.y + 80*fg.screen_scale*math.sin(math.pi/24)}, 'in-out-cubic', function() self.system_b_selected = false end)
    end

    self.exit_b:update(dt)
    if not self.exit_b_selected then self.exit_b.button.y = 320*fg.screen_height/fg.min_height end
    self.exit_b.button.h = 40*fg.screen_height/fg.min_height
    if self.exit_b.button.selected_enter then
        self.exit_b_selected = true
        self.timer:tween('exit_b_select_tween', 0.2, self.exit_b.button, {x = self.exit_b.button.x + 115*fg.screen_scale*math.cos(math.pi/24), 
                         y = self.exit_b.button.y - 115*fg.screen_scale*math.sin(math.pi/24)}, 'in-out-cubic')
    end
    if self.exit_b.button.selected_exit then
        self.timer:tween('exit_b_select_tween', 0.2, self.exit_b.button, {x = self.exit_b.button.x - 115*fg.screen_scale*math.cos(math.pi/24),
                         y = self.exit_b.button.y + 115*fg.screen_scale*math.sin(math.pi/24)}, 'in-out-cubic', function() self.exit_b_selected = false end)
    end

    if not self.status_b_tweening and not self.status_b_selected then
        if self.paused then self.status_b.button.x = -200*fg.screen_scale
        else self.status_b.button.x = -500*fg.screen_scale end
    end

    if not self.party_b_tweening and not self.party_b_selected then
        if self.paused then self.party_b.button.x = -200*fg.screen_scale
        else self.party_b.button.x = -500*fg.screen_scale end
    end
    
    if not self.item_b_tweening and not self.item_b_selected then
        if self.paused then self.item_b.button.x = -200*fg.screen_scale
        else self.item_b.button.x = -500*fg.screen_scale end
    end

    if not self.system_b_tweening and not self.system_b_selected then
        if self.paused then self.system_b.button.x = -200*fg.screen_scale
        else self.system_b.button.x = -500*fg.screen_scale end
    end

    if not self.exit_b_tweening and not self.exit_b_selected then
        if self.paused then self.exit_b.button.x = -200*fg.screen_scale
        else self.exit_b.button.x = -500*fg.screen_scale end
    end

    if not self.portrait_tweening then
        local sy = 1
        if self.portrait then sy = fg.screen_height/self.portrait:getHeight() end
        if self.paused then self.portrait_s = {x = fg.screen_width - 600*sy, y = 0}
        else self.portrait_s = {x = fg.screen_width, y = 0} end
    end

    if not self.left_bg_tweening then
        if self.paused then self.left_bg = {x = -125*fg.screen_scale, y = -50*fg.screen_scale, w = 375*fg.screen_scale, h = 600*fg.screen_scale}
        else self.left_bg = {x = -450*fg.screen_scale, y = -50*fg.screen_scale, w = 375*fg.screen_scale, h = 600*fg.screen_scale} end
    end

    if not self.right_bg_tweening then
        if self.paused then self.right_bg = {x = -100*fg.screen_scale, y = -400*fg.screen_scale, w = 1000*fg.screen_scale, h = 1000*fg.screen_scale}
        else self.right_bg = {x = 600*fg.screen_scale, y = 0, w = 1000*fg.screen_scale, h = 1000*fg.screen_scale} end
    end
end

function UIPause:UIPauseDraw()
    if self.paused or self.pausing then
        love.graphics.setColor(unpack(UI.colors.bg))
        fg.utils.graphics.pushRotate(self.right_bg.x + self.right_bg.w/2, self.right_bg.y + self.right_bg.h/2, math.pi/4 + math.pi/12)
        love.graphics.rectangle("fill", self.right_bg.x, self.right_bg.y, self.right_bg.w, self.right_bg.h)
        love.graphics.pop()

        love.graphics.setColor(unpack(UI.colors.yellow))
        fg.utils.graphics.pushRotate(self.left_bg.x + self.left_bg.w/2, self.left_bg.y + self.left_bg.h/2, -math.pi/24)
        love.graphics.rectangle("fill", self.left_bg.x, self.left_bg.y, self.left_bg.w, self.left_bg.h)
        love.graphics.pop()

        local sy = fg.screen_height/self.portrait:getHeight()

        love.graphics.setShader(self.shadow_shader)
        love.graphics.setColor(unpack(UI.colors.yellow))
        love.graphics.draw(self.portrait, self.portrait_s.x, self.portrait_s.y, 0, 1.1*sy, 1.1*sy, 75, 75)
        love.graphics.setShader()

        love.graphics.setColor(255, 255, 255, 255)
        love.graphics.draw(self.portrait, self.portrait_s.x, self.portrait_s.y, 0, sy, sy)

        self.status_b:draw()
        self.party_b:draw()
        self.item_b:draw()
        self.system_b:draw()
        self.exit_b:draw()
    end

    love.graphics.setColor(255, 255, 255, 255)
end

function UIPause:postAssetLoad()
    self.portrait = fg.Assets.sak0
    self.portrait:setFilter('linear', 'linear')
    self.portrait:setMipmapFilter('linear', 8)
end

function UIPause:setSelection()
    local selected_button = self.selection_list[self.selected_index]
    for _, s in ipairs(self.selection_list) do
        if s ~= selected_button then self[s .. '_b'].button.selected = false 
        else self[s .. '_b'].button.selected = true end
    end
end

function UIPause:selectNext()
    self.selected_index = self.selected_index + 1
    if self.selected_index > #self.selection_list then self.selected_index = 1 end
end

function UIPause:selectPrevious()
    self.selected_index = self.selected_index - 1
    if self.selected_index < 1 then self.selected_index = #self.selection_list end
end

function UIPause:pause()
    self.pausing = true

    self.right_bg_tweening = true
    self.timer:tween('right_bg_tween', 0.15, self.right_bg, {x = -100*fg.screen_scale, y = -400*fg.screen_scale}, 'linear')

    self.timer:after(0.1, function()
        self.left_bg_tweening = true
        self.timer:tween('left_bg_tween', 0.15, self.left_bg, {x = -125*fg.screen_scale}, 'in-out-cubic') 

        self.timer:after(0.1, function()
            self.portrait_tweening = true
            local sy = fg.screen_height/self.portrait:getHeight()
            self.timer:tween('portrait_tween', 0.15, self.portrait_s, {x = fg.screen_width - 600*sy}, 'in-out-cubic')

            self.timer:after(0.1, function()
                self.status_b_tweening = true
                self.timer:tween('status_b_tween', 0.15, self.status_b.button, {x = -200*fg.screen_scale}, 'in-out-cubic')

                self.timer:after(0.03, function()
                    self.party_b_tweening = true
                    self.timer:tween('party_b_tween', 0.15, self.party_b.button, {x = -200*fg.screen_scale}, 'in-out-cubic')

                    self.timer:after(0.03, function()
                        self.item_b_tweening = true
                        self.timer:tween('item_b_tween', 0.15, self.item_b.button, {x = -200*fg.screen_scale}, 'in-out-cubic')

                        self.timer:after(0.03, function()
                            self.system_b_tweening = true
                            self.timer:tween('system_b_tween', 0.15, self.system_b.button, {x = -200*fg.screen_scale}, 'in-out-cubic')

                            self.timer:after(0.03, function()
                                self.exit_b_tweening = true
                                self.timer:tween('exit_b_tween', 0.15, self.exit_b.button, {x = -200*fg.screen_scale}, 'in-out-cubic', function()
                                    self.item_b_tweening = false
                                    self.system_b_tweening = false
                                    self.exit_b_tweening = false
                                    self.party_b_tweening = false
                                    self.status_b_tweening = false
                                    self.right_bg_tweening = false
                                    self.left_bg_tweening = false 
                                    self.portrait_tweening = false
                                    self.paused = true
                                    self.pausing = false
                                end)
                            end)
                        end)
                    end)
                end)
            end)
        end)
    end)
end

function UIPause:unpause()
    self.pausing = true

    self.exit_b_tweening = true
    self.timer:tween('exit_b_tween', 0.15, self.exit_b.button, {x = -500*fg.screen_scale}, 'in-out-cubic')

    self.timer:after(0.03, function()
        self.system_b_tweening = true
        self.timer:tween('system_b_tween', 0.15, self.system_b.button, {x = -500*fg.screen_scale}, 'in-out-cubic')

        self.timer:after(0.03, function()
            self.item_b_tweening = true
            self.timer:tween('item_b_tween', 0.15, self.item_b.button, {x = -500*fg.screen_scale}, 'in-out-cubic')

            self.timer:after(0.03, function()
                self.party_b_tweening = true
                self.timer:tween('party_b_tween', 0.15, self.party_b.button, {x = -500*fg.screen_scale}, 'in-out-cubic')

                self.timer:after(0.03, function()
                    self.status_b_tweening = true
                    self.timer:tween('status_b_tween', 0.15, self.status_b.button, {x = -500*fg.screen_scale}, 'in-out-cubic')

                    self.timer:after(0.1, function()
                        self.portrait_tweening = true
                        self.timer:tween('portrait_tween', 0.15, self.portrait_s, {x = fg.screen_width}, 'in-out-cubic')

                        self.timer:after(0.1, function()
                            self.left_bg_tweening = true
                            self.timer:tween('left_bg_tween', 0.15, self.left_bg, {x = -450*fg.screen_scale}, 'in-out-cubic')

                            self.timer:after(0.1, function()
                                self.right_bg_tweening = true
                                self.timer:tween('right_bg_tween', 0.15, self.right_bg, {x = 600*fg.screen_scale, y = 0}, 'linear', function() 
                                    self.item_b_tweening = false
                                    self.system_b_tweening = false
                                    self.exit_b_tweening = false
                                    self.party_b_tweening = false
                                    self.status_b_tweening = false
                                    self.portrait_tweening = false
                                    self.left_bg_tweening = false 
                                    self.right_bg_tweening = false 
                                    self.paused = false
                                    self.pausing = false
                                end)
                            end)
                        end)
                    end)
                end)
            end)
        end)
    end)
end

return UIPause
