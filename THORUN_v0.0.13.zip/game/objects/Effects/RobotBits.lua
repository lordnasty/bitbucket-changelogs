local RobotBits = fg.Class('RobotBits', 'Entity')
RobotBits:implement(fg.PhysicsBody)

RobotBits.ignores = {'All', except = {'Solid'}}

function RobotBits:new(area, x, y, settings)
    local settings = settings or {}
    RobotBits.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    settings.w, settings.h = 4, 6
    self:physicsBodyNew(area, x, y, settings)
    self.r = settings.r or 0
    self.body:setFixedRotation(false)
    self.body:setGravityScale(0.7)
    self.fixture:setRestitution(0.7)
    self.body:setLinearVelocity(self.v*math.cos(self.r), self.v*math.sin(self.r))
    self.body:applyTorque(self.fg.utils.math.random(-8*math.pi, 8*math.pi))

    self.robot_bits_visual = self.fg.Assets.robot_bits
    self.robot_bits_quad = love.graphics.newQuad(13*math.random(0, 3), 0, 13, 13, self.robot_bits_visual:getWidth(), self.robot_bits_visual:getHeight())
    self.w, self.h = 13, 13
    self.alpha = 255
    self.timer:after(1.3, function()
        self.timer:tween(0.3, self, {alpha = 0}, 'in-out-cubic')
        self.timer:after(0.3, function() self.dead = true end)
    end)
end

function RobotBits:update(dt)
    self.timer:update(dt)
    self:physicsBodyUpdate(dt)
    self.r = self.body:getAngle()
end

function RobotBits:draw()
    love.graphics.setColor(255, 255, 255, self.alpha)
    love.graphics.draw(self.robot_bits_visual, self.robot_bits_quad, self.x, self.y, self.r, self.sx or 1, self.sy or 1, self.w/2, self.h/2)
    self:physicsBodyDraw()
    love.graphics.setColor(255, 255, 255, 255)
end

return RobotBits
