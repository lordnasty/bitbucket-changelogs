local StartArea = fg.Object:extend('StartArea')

function StartArea:new(data)
    if data then for k, v in pairs(data) do self[k] = v end end
end

function StartArea:update(dt)

end

function StartArea:init()
    SH.setSnowBackground('StartArea')

end

return StartArea
