local ScriptHelper = {}

ScriptHelper.getPlayer = function()
    if game.player then return game.player
    else 
        local entities = fg.world.areas[fg.current_area]:getEntitiesWhere(function() return true end, {'Player'})
        local player = entities[1]
        if player then return player
        else error("Player not found") end
    end
end

ScriptHelper.setSnowBackground = function(level_name)

end

return ScriptHelper
