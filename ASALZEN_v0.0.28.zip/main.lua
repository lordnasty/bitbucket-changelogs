cwd = arg[1]
if cwd == '--console' then cwd = arg[2] end
forwardslash = cwd:find("/[^/]*$")
backslash = cwd:find("\\[^\\]*$")
if cwd:find('.love') then 
    if forwardslash then cwd = cwd:sub(1, forwardslash-1) end
    if backslash then cwd = cwd:sub(1, backslash-1) end
end
if backslash then cwd = cwd:gsub('\\', '\\\\') end

love.filesystem.createDirectory('maps')

function count_all(f)
	local seen = {}
	local count_table
	count_table = function(t)
		if seen[t] then return end
		f(t)
		seen[t] = true
		for k,v in pairs(t) do
			if type(v) == "table" then
				count_table(v)
			elseif type(v) == "userdata" then
				f(v)
			end
		end
	end
	count_table(_G)
end

function type_count()
	local counts = {}
	local enumerate = function (o)
		local t = type_name(o)
		counts[t] = (counts[t] or 0) + 1
	end
	count_all(enumerate)
	return counts
end

global_type_table = nil
function type_name(o)
	if global_type_table == nil then
		global_type_table = {}
		for k,v in pairs(_G) do
			global_type_table[v] = k
		end
		global_type_table[0] = "table"
	end
	return global_type_table[getmetatable(o) or 0] or "Unknown"
end

require 'fuccboi/fuccboi'
local Game = require 'Game'
local Editor = require 'editor/Editor'
UI = require 'UI'

function love.load()
    fg.init()

    ui = UI()
    game = Game()
    last_pressed = nil

    editor_input = fg.Input()
    editor = Editor()

    -- collectgarbage("stop")
    fg.input:bind('kp1', function()
        print("Before collection: " .. collectgarbage("count")/1024)
        collectgarbage()
        print("After collection: " .. collectgarbage("count")/1024)
        print("Object count: ")
        local counts = type_count()
        for k, v in pairs(counts) do
            print(k, v)
        end
        print("-------------------------------------")
    end)
end

function love.update(dt)
    fg.update(dt)
    editor:update(dt)
    editor_input:update(dt)
    game:update(dt)
    ui:update(dt)
end

function love.draw()
    fg.draw()
    editor:draw()
    game:draw()
end

function love.keypressed(key)
    last_pressed = 'Keyboard' 
    fg.keypressed(key)
    editor_input:keypressed(key)
end

function love.keyreleased(key)
    fg.keyreleased(key)   
    editor_input:keyreleased(key)
end

function love.mousepressed(x, y, button)
    fg.mousepressed(button) 
    editor_input:mousepressed(button)
end

function love.mousereleased(x, y, button)
    fg.mousereleased(button) 
    editor_input:mousereleased(button)
end

function love.gamepadpressed(joystick, button)
    last_pressed = 'Gamepad'
    fg.gamepadpressed(joystick, button)
    editor_input:gamepadpressed(joystick, button)
end

function love.gamepadreleased(joystick, button)
    fg.gamepadreleased(joystick, button)
    editor_input:gamepadreleased(joystick, button)
end

function love.gamepadaxis(joystick, axis, newvalue)
    if (axis == 'leftx' or axis == 'lefty' or axis == 'triggerleft' or axis == 'triggerright') and math.abs(newvalue) >= 0.5 then last_pressed = 'Gamepad' end
    fg.gamepadaxis(joystick, axis, newvalue)
    editor_input:gamepadaxis(joystick, axis, button)
end

function love.textinput(text)
    fg.textinput(text)
end

function love.resize(w, h)
    fg.resize(w, h)
end

function love.run()
    math.randomseed(os.time())
    math.random() math.random()
    if love.math then love.math.setRandomSeed(os.time()) end
    if love.event then love.event.pump() end
    if love.load then love.load(arg) end
    if love.timer then love.timer.step() end
    fg.run()
end

function love.quit()
    local function recursivelyDelete(item) 
        if love.filesystem.isDirectory(item) then
            for _, child in ipairs(love.filesystem.getDirectoryItems(item)) do
                recursivelyDelete(item .. '/' .. child)
                love.filesystem.remove(item .. '/' .. child)
            end
        elseif love.filesystem.isFile(item) then
            love.filesystem.remove(item)
        end
        love.filesystem.remove(item)
    end
    recursivelyDelete('maps')
end
