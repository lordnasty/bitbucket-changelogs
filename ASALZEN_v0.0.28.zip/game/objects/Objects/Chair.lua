local Chair = fg.Class('Chair', 'Entity')
Chair:implement(fg.PhysicsBody)
Chair:implement(Pseudo3D)

function Chair:new(area, x, y, settings)
    local settings = settings or {}
    self.direction = settings.direction or 'right'
    Chair.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    self.chair_visual = self.fg.Assets.chair
    settings.w, settings.h = 18, 12
    self.chair_shadow = love.graphics.newQuad(128, 0, 32, 64, 160, 64)
    if self.direction == 'right' then
        self.chair_quad = love.graphics.newQuad(0, 0, 32, 64, 160, 64)
    elseif self.direction == 'up' then
        self.chair_quad = love.graphics.newQuad(32, 0, 32, 64, 160, 64)
    elseif self.direction == 'left' then
        self.chair_quad = love.graphics.newQuad(64, 0, 32, 64, 160, 64)
    elseif self.direction == 'down' then
        self.chair_quad = love.graphics.newQuad(96, 0, 32, 64, 160, 64)
    end
    self:physicsBodyNew(area, x, y, settings)
    self:pseudo3DNew({height_z = 20, settings = settings})
end

function Chair:update(dt)
    self.timer:update(dt)
    self:physicsBodyUpdate(dt)
    self:pseudo3DUpdate(dt)
end

function Chair:draw()
    local w, h = 32, 64
    -- Shadow
    love.graphics.setColor(255, 255, 255, 128)
    love.graphics.draw(self.chair_visual, self.chair_shadow, math.floor(self.x - w/2), math.floor(self.y - h + 8))
    love.graphics.setColor(255, 255, 255, 255)
    -- Chair
    love.graphics.draw(self.chair_visual, self.chair_quad, math.floor(self.x - w/2), math.floor(self.y - h + 8))
    self:physicsBodyDraw()
    self:pseudo3DDraw()
end

function Chair:highlightDraw()
    local w, h = 32, 64
    love.graphics.draw(self.chair_visual, self.chair_quad, self.x - w/2, self.y - h + 8)
end

function Chair:save()
    local pseudo_3d = self:pseudo3DSave()
    local save_data = {}
    for k, v in pairs(pseudo_3d) do save_data[k] = v end
    save_data.direction = self.direction
    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y
    save_data.w, save_data.h = self.w, self.h
    save_data.shape = 'Rectangle'
    return save_data
end

return Chair
