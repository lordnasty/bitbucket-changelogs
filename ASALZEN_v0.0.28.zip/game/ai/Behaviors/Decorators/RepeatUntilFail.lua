local RepeatUntilFail = Decorator:extend('RepeatUntilFail')

function RepeatUntilFail:new(behavior)
    RepeatUntilFail.super.new(self, 'RepeatUntilFail', behavior)
end

function RepeatUntilFail:update(dt, context)
    return RepeatUntilFail.super.update(self, dt, context)
end

function RepeatUntilFail:run(dt, context)
    local status = self.behavior:update(dt, context)
    if status ~= 'failure' then return 'running'
    else return 'success' end
end

function RepeatUntilFail:start(context)

end

function RepeatUntilFail:finish(status, context)

end

return RepeatUntilFail
