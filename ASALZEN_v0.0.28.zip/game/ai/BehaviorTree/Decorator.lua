Decorator = Behavior:extend('Decorator')

function Decorator:new(name, behavior)
    Decorator.super.new(self)
    self.name = name
    self.behavior = behavior or {}
    self.fg = fg
end

function Decorator:update(dt, context)
    return Decorator.super.update(self, dt, context)
end
