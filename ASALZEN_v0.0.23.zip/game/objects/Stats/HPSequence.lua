local HPSequence = fg.Class('HPSequence', 'Entity')

HPSequence.layer = 'Floor'
HPSequence.dont_save = true

function HPSequence:new(area, x, y, settings)
    local settings = settings or {}
    HPSequence.super.new(self, area, x, y, settings)

    self.visual = self.fg.Assets.triangle
    self.sequence = settings.settings.sequence or {}
    self.n = settings.settings.n or math.random(1, 4)
    if #self.sequence <= 0 then
        for i = 1, self.n or 4 do
            table.insert(self.sequence, self.fg.utils.table.random({'l', 'r'}))
        end
    end
    self.max_hp = self.n
end

function HPSequence:update(dt)

end

function HPSequence:draw()
    if self.parent.down_idle or self.parent.fall_down then return end
    local n = #self.sequence
    local w, h = self.visual:getWidth(), self.visual:getHeight()
    local x, y = self.parent.x + 18, self.parent.y - (n-1)*h/2
    local j = 1
    for i = #self.sequence, 1, -1 do
        if self.sequence[i] == 'l' then
            love.graphics.setColor(189, 90, 90, 255)
            love.graphics.draw(self.visual, x, y + (j-1)*h*0.6, math.pi, 0.6, 0.6, w/2, h/2)
        elseif self.sequence[i] == 'r' then
            love.graphics.setColor(90, 122, 189, 255)
            love.graphics.draw(self.visual, x, y + (j-1)*h*0.6, 0, 0.6, 0.6, w/2, h/2)
        end
        j = j + 1
    end
    love.graphics.setColor(255, 255, 255, 255)
    love.graphics.setShader()
end

function HPSequence:hitOrMiss(attack_type)
    if attack_type == 'left' then attack_type = 'l' else attack_type = 'r' end
    for i = 1, #self.sequence do
        if self.sequence[i] ~= 'gl' and self.sequence[i] ~= 'gr' then return self.sequence[i] == attack_type end
    end
end

function HPSequence:getHP()
    for i = #self.sequence, 1, -1 do 
        if self.sequence[i] == 'gl' or self.sequence[i] == 'gr' then return #self.sequence - i end
    end
    return #self.sequence
end

function HPSequence:pop()
    for i = 1, #self.sequence do
        if self.sequence[i] ~= 'gr' and self.sequence[i] ~= 'gl' then
            local returned = self.sequence[i]
            if returned == 'l' then self.sequence[i] = 'gl'
            elseif returned == 'r' then self.sequence[i] = 'gr' end
            if i == #self.sequence then self.parent:die() end
            return returned
        end
    end
end

function HPSequence:changeHP(n)
    self.max_hp = n
    self.sequence = {}
    for i = 1, n do table.insert(self.sequence, self.fg.utils.table.random({'l', 'r'})) end
end

function HPSequence:changeSequence(seq)
    self.max_hp = #seq
    self.sequence = seq
end

function HPSequence:save()
    return {id = self.id, x = self.x, y = self.y, n = self.n, sequence = self.sequence}
end

return HPSequence
