local MainCorridor3 = fg.Object:extend('MainCorridor3')

function MainCorridor3:new(data)
    if data then for k, v in pairs(data) do self[k] = v end end
    self.timer = fg.Timer()
    self.name = 'MainCorridor3'
end

function MainCorridor3:update(dt)
    self.timer:update(dt)
end

function MainCorridor3:initPost()
    if self.ran_once then return end
    self.ran_once = true

    local player = SH.getPlayer()
    player.movement_locked = true
    player.attack_locked = true
    player.action_locked = true

    local enemy = fg.world.areas['MainCorridor3']:getEntitiesWhere(function() return true end, {'PersonAI'})[1]
    enemy.hp:changeSequence({'l'})

    self.timer:after(0.7, function()
        local x, y = player.body:getPosition()
        player:moveTo(x + 25, y - 25)

        enemy:alert(player)
        enemy.head:changeMouth(9)

        self.timer:after(1, function()
            ui:transitionTo('dialogue', {
                script = self,

                texts = {
                    "[OH MY GOD!!! ](textbox; shake)[I forgot to lock the door!!! Holy shit!!!](textbox)",
                    "[It took 50 guys and 5 hours of fighting to put him in there... and now he's just escaping and it's my fault!](textbox)",
                    "[THIS IS MY END!!! ](textbox; shake)[They're gonna beat the h*ck out of me!!!](textbox)",
                    "[...calm down and think. All you have to do is convince him to go back inside;;](textbox)",
                    "[H-hey, could you p-please go back inside t-that room...?](textbox)",
                }, 
                
                names = {
                    'Some guy',
                    'Some guy',
                    'Some guy',
                    'Some guy',
                    'Some guy',
                },

                triggers = {
                    function() 
                        local x, y = fg.world.camera:getCameraCoords(enemy.x - 4, enemy.y - 16)
                        fg.world.focus_point = {x = x/fg.screen_width, y = 1-(y/fg.screen_height)} 
                        self.timer:tween(0.5, fg.world, {focus_point_radius = 0.15}, 'in-out-cubic')
                        self.timer:tween(0.5, fg.world, {focus_point_amount = 1}, 'in-out-cubic')
                    end,
                    nil,
                    function() 
                        if enemy.head.eye_index ~= 3 and enemy.head.eye_index ~= 5 then 
                            enemy.head:restoreEyes(); enemy.head:changeEyes(7) 
                        end
                    end,
                    function() enemy.head:restoreMouth(); enemy.head:changeMouth(5) end,
                    function() 
                        ui.diag_text = nil
                        enemy.head:restoreEyes()
                        enemy.head:restoreMouth()
                        self.timer:tween(1, fg.world, {focus_point_radius = 2}, 'in-out-cubic')
                        self.timer:tween(1, fg.world, {focus_point_amount = 0}, 'in-out-cubic')
                        self.timer:after(1.2, function() 
                            fg.world.focus_point = nil 
                            local x, y = enemy.body:getPosition()
                            enemy:moveTo(enemy.x - 50, enemy.y + 25)
                        end)
                        return 'wait', {4, function() enemy:talk(); enemy:arriveOff() end}, 'post_trigger', {function() enemy:stopTalking() end}
                    end
                }
            })
        end)
    end)
end

function MainCorridor3:postDialogue()
    local player = SH.getPlayer()
    player.movement_locked = false
    player.attack_locked = false

    ui:createEntity('InteractPopup', 0, 0, {text = 'ATTACK LEFT', font_size = 20, action = 'leftAttack', press_action = function(self) 
        self.dead = true 
        player.action_locked = false
    end})
end

function MainCorridor3:save()
    return {ran_once = self.ran_once}
end

return MainCorridor3
