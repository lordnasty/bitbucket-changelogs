local LightAttack1 = fg.Object:extend('LightAttack1')

function LightAttack1:new(settings)
    local settings = settings or {}
    for k, v in pairs(settings) do self[k] = v end
    self.type = 'Attack'
    self.hit_counter = 1
    self.attacking = false
end

function LightAttack1:update(dt)

end

function LightAttack1:interrupt()
    self.parent:setAnimationDelay('strong_punch_left_anticipation', 0.08)
    self.parent:setAnimationDelay('strong_punch_left_anticipation_arm', 0.08)
    self.parent.timer:cancel('strong_punch_left_anticipation_12')
    self.parent.movement_locked = false
    self.attacking = false
end

function LightAttack1:pressed()
    if self.attacking then return end
    if self.hit_counter == 1 then self.parent:interruptAttack() end
    self.attacking = true

    local attack_type = nil
    self.parent.movement_locked = true
    if self.hit_counter == 1 then
        self.parent.timer:after('LightAttack1_hit_counter', 5*0.08, function() self.hit_counter = 1 end)
        attack_type = fg.utils.table.random({'light_punch_left', 'light_punch_right'})
        self.parent:playAnim(attack_type, {
            {1, function()
                local d = self.parent.animation_flip
                self.parent.area:createEntity('MeleeArea', self.parent.x + 16*d, self.parent.y, {attack = self, source = self.parent, w = 16, h = 12})
            end},
            {0, function() 
                self.attacking = false
                self.parent.movement_locked = false 
            end}
        })
        self.hit_counter = self.hit_counter + 1

    elseif self.hit_counter == 2 then
        self.parent.timer:after('LightAttack1_hit_counter', 15*0.06, function() self.hit_counter = 1 end)
        self.parent:setAnimationDelay('strong_punch_left_anticipation', 0.06)
        self.parent:setAnimationDelay('strong_punch_left_anticipation_arm', 0.06)
        self.parent:playAnim('strong_punch_left_anticipation', {
            {4, function()
                local d = self.parent.animation_flip
                self.parent:push(d*200, 0)
                self.parent.area:createEntity('MeleeArea', self.parent.x + 20*d, self.parent.y, {attack = self, source = self.parent, w = 24, h = 12})
            end},
            {6, function() self.attacking = false end},
            {12, function() 
                self.parent.movement_locked = false 
                self.parent:setAnimationDelay('strong_punch_left_anticipation', 0.08)
                self.parent:setAnimationDelay('strong_punch_left_anticipation_arm', 0.08)
            end}
        })
        self.hit_counter = self.hit_counter + 1

    elseif self.hit_counter == 3 then
        self.parent.timer:cancel('LightAttack1_hit_counter')
        self.parent.timer:cancel('strong_punch_left_anticipation_12')
        self.parent:setAnimationDelay('strong_punch_left_anticipation', 0.08)
        self.parent:setAnimationDelay('strong_punch_left_anticipation_arm', 0.08)
        self.parent:playAnim('strong_punch_right_anticipation', {
            {4.5, function() 
                local d = self.parent.animation_flip
                self.parent:push(d*400, 0)
                self.parent.area:createEntity('MeleeArea', self.parent.x + 24*d, self.parent.y, {attack = self, source = self.parent, w = 32, h = 12})
            end},
            {12, function() 
                self.attacking = false
                self.parent.movement_locked = false 
            end},
        })
        self.hit_counter = 1
    end
end

function LightAttack1:down(dt)

end

function LightAttack1:released()

end

return LightAttack1
