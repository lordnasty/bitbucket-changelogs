local NPC = fg.Class('NPC', 'Person')
NPC:implement(Steerable)

NPC.ignores = {'Table'}

function NPC:new(area, x, y, settings)
    local settings = settings or {}
    NPC.super.new(self, area, x, y, settings)

    self:steerableNew({settings = settings})
end

function NPC:update(dt)
    NPC.super.update(self, dt)

    self:steerableUpdate(dt)
end

function NPC:draw()
    NPC.super.draw(self)
end

function NPC:save()
    local save_data = NPC.super.save(self)
    local steerable = self:steerableSave()
    for k, v in pairs(steerable) do save_data[k] = v end
    return save_data
end

return NPC
