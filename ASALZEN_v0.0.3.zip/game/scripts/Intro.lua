local Intro = fg.Object:extend('Intro')

function Intro:new(data)
    if data then for k, v in pairs(data) do self[k] = v end end
end

function Intro:update(dt)

end

function Intro:init()
    game:screenTransition('rectangle up', 0)
    game:screenTransition('rectangle lr down', 1.5)

    --[[
    local player = SH.getPlayer()
    player:setAnimationState('down_idle')
    player.movement_locked = true
    ]]--
end

return Intro
