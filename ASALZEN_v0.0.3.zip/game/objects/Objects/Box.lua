local Box = fg.Class('Box', 'Entity')
Box:implement(fg.PhysicsBody)
Box:implement(Pseudo3D)

function Box:new(area, x, y, settings)
    local settings = settings or {}
    settings.w = 24
    settings.h = 12
    Box.super.new(self, area, x, y, settings)
    self.timer = self.fg.Timer()
    self:physicsBodyNew(area, x, y, settings)
    self:pseudo3DNew({z = 40, height_z = 10, settings = settings})

    self.box_quad = love.graphics.newQuad(math.random(0, 3)*24, 0, 24, 23, 120, 23)
    self.shadow_quad = love.graphics.newQuad(4*24, 0,24, 32, 120, 23)
end

function Box:update(dt)
    self.timer:update(dt)
    self:physicsBodyUpdate(dt)
    self:pseudo3DUpdate(dt)
end

function Box:draw()
    self:physicsBodyDraw()
    local w, h = 24, 23
    -- Shadow
    love.graphics.setColor(255, 255, 255, 92)
    love.graphics.draw(self.fg.Assets.box, self.shadow_quad, self.x, self.y - self.z_xy + 3, 0, math.max(1.1 - self.z/100, 0.1), math.max(1.1 - self.z/100, 0.1), w/2, h/2 + 12)
    love.graphics.setColor(255, 255, 255, 255)
    -- Box
    love.graphics.draw(self.fg.Assets.box, self.box_quad, self.x, self.y - self.z, 0, 1, 1, w/2, h/2 + 6)
    self:pseudo3DDraw()
end

function Box:highlightDraw()
    local w, h = 24, 23
    love.graphics.draw(self.fg.Assets.box, self.box_quad, self.x, self.y - self.z, 0, 1, 1, w/2, h/2 + 6)
end

function Box:save()
    local pseudo_3d = self:pseudo3DSave()
    local save_data = {}
    for k, v in pairs(pseudo_3d) do save_data[k] = v end
    local x, y = self.body:getPosition()
    save_data.id = self.id
    save_data.x, save_data.y = x, y
    save_data.w, save_data.h = self.w, self.h
    save_data.shape = 'Rectangle'
    return save_data
end

function Box:preSolve(other, contact)
    self:pseudo3DPreSolve(other, contact)
end

return Box
